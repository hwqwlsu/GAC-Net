"""评估入口：逐类别报告 CD-L1/CD-L2（×1e4）与 F-Score。

用法：
    python evaluate.py --ckpt experiments/smoke/best_model.pth
    python evaluate.py --ckpt experiments/gacnet_shapenet55/best_model.pth \
        --override '{"dataset":"shapenet55","data_root":"data/shapenet55"}'
"""
import argparse
import json
import os
from collections import defaultdict

import torch
from torch.utils.data import DataLoader

from pcic.data import build_dataset, SHAPENET_CATEGORIES, SYNTH_CATEGORIES
from pcic.models import GACNet
from pcic.metrics import evaluate_sample


def move(batch, device):
    return {k: (v.to(device) if torch.is_tensor(v) else v) for k, v in batch.items()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--ckpt", required=True)
    parser.add_argument("--override", default=None)
    args = parser.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    ckpt = torch.load(args.ckpt, map_location=device, weights_only=False)
    cfg = ckpt["config"]
    if args.override:
        cfg.update(json.loads(args.override))

    split = "test" if cfg["dataset"] == "synthetic" else "test"
    dataset = build_dataset(cfg, split)
    loader = DataLoader(dataset, batch_size=1, shuffle=False,
                        num_workers=cfg.get("num_workers", 0))
    names = SYNTH_CATEGORIES if cfg["dataset"] == "synthetic" else SHAPENET_CATEGORIES

    model = GACNet(**cfg["model"]).to(device)
    model.load_state_dict(ckpt["model"])
    model.eval()

    per_cat = defaultdict(list)
    with torch.no_grad():
        for batch in loader:
            batch = move(batch, device)
            out = model(batch)
            m = evaluate_sample(out["fine"][0], batch["complete"][0])
            per_cat[int(batch["category"][0])].append(m)

    report = {}
    all_metrics = defaultdict(list)
    for cat_id, rows in sorted(per_cat.items()):
        name = names[cat_id] if cat_id < len(names) else str(cat_id)
        report[name] = {k: round(sum(r[k] for r in rows) / len(rows), 4)
                        for k in rows[0]}
        for k, v in report[name].items():
            all_metrics[k].append(v)
    report["overall"] = {k: round(sum(v) / len(v), 4) for k, v in all_metrics.items()}

    print(json.dumps(report, indent=2, ensure_ascii=False))
    out_path = os.path.join(os.path.dirname(os.path.abspath(args.ckpt)),
                            "test_metrics.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    print(f"[saved] {out_path}")


if __name__ == "__main__":
    main()
