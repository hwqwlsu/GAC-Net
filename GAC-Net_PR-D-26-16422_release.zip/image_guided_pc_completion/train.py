"""训练入口。

用法：
    python train.py --config configs/smoke.json
    python train.py --config configs/default.json
"""
import argparse
import json
import os
import time

import torch
from torch.utils.data import DataLoader

from pcic.data import build_dataset
from pcic.models import GACNet
from pcic.losses import completion_loss
from pcic.metrics import chamfer_metrics
from pcic.utils import seed_everything, load_config, count_parameters, CsvLogger


def move(batch, device):
    out = {}
    for k, v in batch.items():
        out[k] = v.to(device) if torch.is_tensor(v) else v
    return out


def validate(model, loader, device):
    model.eval()
    cd1_sum, cd2_sum, n = 0.0, 0.0, 0
    with torch.no_grad():
        for batch in loader:
            batch = move(batch, device)
            out = model(batch)
            cd1, cd2 = chamfer_metrics(out["fine"], batch["complete"])
            bs = batch["complete"].shape[0]
            cd1_sum += cd1 * bs
            cd2_sum += cd2 * bs
            n += bs
    return cd1_sum / n, cd2_sum / n


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--override", default=None, help='JSON 字符串覆盖配置')
    args = parser.parse_args()

    cfg = load_config(args.config)
    if args.override:
        cfg.update(json.loads(args.override))
    seed_everything(cfg["seed"])
    os.makedirs(cfg["out_dir"], exist_ok=True)
    with open(os.path.join(cfg["out_dir"], "config.json"), "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)

    device = "cuda" if torch.cuda.is_available() else "cpu"
    train_set = build_dataset(cfg, "train")
    val_split = "test" if cfg["dataset"] == "synthetic" else "val"
    val_set = build_dataset(cfg, val_split)
    train_loader = DataLoader(train_set, batch_size=cfg["batch_size"], shuffle=True,
                              num_workers=cfg["num_workers"], drop_last=True,
                              pin_memory=device == "cuda")
    val_loader = DataLoader(val_set, batch_size=cfg["batch_size"], shuffle=False,
                            num_workers=cfg["num_workers"], pin_memory=device == "cuda")

    model = GACNet(**cfg["model"]).to(device)
    print(f"[model] 可训练参数量: {count_parameters(model) / 1e6:.2f}M  device={device}")

    opt = torch.optim.AdamW(model.parameters(), lr=cfg["lr"],
                            weight_decay=cfg["weight_decay"])
    warmup = cfg["warmup_epochs"]
    def lr_lambda(epoch):
        if epoch < warmup:
            return (epoch + 1) / warmup
        import math
        progress = (epoch - warmup) / max(cfg["epochs"] - warmup, 1)
        return 0.5 * (1 + math.cos(math.pi * progress))
    sched = torch.optim.lr_scheduler.LambdaLR(opt, lr_lambda)
    scaler = torch.amp.GradScaler("cuda", enabled=cfg["amp"] and device == "cuda")

    logger = CsvLogger(os.path.join(cfg["out_dir"], "train_log.csv"),
                       ["epoch", "lr", "loss", "cd_l1_val", "cd_l2_val", "time_sec"])
    best_cd = float("inf")

    for epoch in range(cfg["epochs"]):
        model.train()
        t0 = time.time()
        running, steps = 0.0, 0
        for batch in train_loader:
            batch = move(batch, device)
            opt.zero_grad(set_to_none=True)
            with torch.amp.autocast("cuda", enabled=cfg["amp"] and device == "cuda"):
                out = model(batch)
                loss, logs = completion_loss(out, batch, cfg["loss"])
            scaler.scale(loss).backward()
            scaler.unscale_(opt)
            torch.nn.utils.clip_grad_norm_(model.parameters(), cfg["grad_clip"])
            scaler.step(opt)
            scaler.update()
            running += float(loss.detach())
            steps += 1
        sched.step()
        train_loss = running / max(steps, 1)

        cd1_val = cd2_val = -1.0
        if (epoch + 1) % cfg["val_every"] == 0 or epoch == cfg["epochs"] - 1:
            cd1_val, cd2_val = validate(model, val_loader, device)
            if cd1_val < best_cd:
                best_cd = cd1_val
                torch.save({"model": model.state_dict(), "config": cfg},
                           os.path.join(cfg["out_dir"], "best_model.pth"))
        torch.save({"model": model.state_dict(), "config": cfg, "epoch": epoch},
                   os.path.join(cfg["out_dir"], "last_model.pth"))
        dt = time.time() - t0
        logger.log({"epoch": epoch + 1, "lr": sched.get_last_lr()[0],
                    "loss": round(train_loss, 6),
                    "cd_l1_val": round(cd1_val * 1e4, 4),
                    "cd_l2_val": round(cd2_val * 1e4, 4),
                    "time_sec": round(dt, 1)})
        print(f"epoch {epoch+1:3d}/{cfg['epochs']} loss={train_loss:.5f} "
              f"CD1_val={cd1_val*1e4:.2f} CD2_val={cd2_val*1e4:.2f} "
              f"lr={sched.get_last_lr()[0]:.2e} {dt:.1f}s")

    print(f"[done] 最佳验证 CD-L1(x1e4) = {best_cd*1e4:.3f}，权重在 {cfg['out_dir']}")


if __name__ == "__main__":
    main()
