"""ShapeNet55 / PCN 真实数据加载器。

期望目录结构（准备方式见 README.md）：

    data_root/
      pcd/
        train/partial/<synset>/<model>__v<view>.npy
        train/complete/<synset>/<model>.npy
        val/...  test/...
      renders/<synset>_<model>__v<view>.png   # 与 partial 同视角对齐
      cams/<synset>_<model>__v<view>.json     # {"K":[...], "w2c":[...]}
      depth/<synset>_<model>__v<view>.npy     # 可选，视角深度监督
      splits/train.txt ...                    # 可选：逐行一个 <rel>

tools/render_shapenet.py 产出的渲染数据已归一化（点云与相机在同一规范坐标），
需设置 pre_normalized=True，加载时不再二次归一化。
若没有 renders 目录，设置 point_only=True 可只跑点云（图像置零、关闭视角损失），
用于纯点云 baseline 复现；图像引导实验必须提供渲染图。
"""
import json
import os
import re

import numpy as np
import torch
from torch.utils.data import Dataset

# PCN 基准 8 类 synset → 名称
SYNSETS = {
    "02691156": "airplane", "02933112": "cabinet", "02958343": "car",
    "03001627": "chair", "03636649": "lamp", "04256520": "sofa",
    "04379243": "table", "04530566": "watercraft",
}
CATEGORY_NAMES = list(SYNSETS.values()) + ["other"]


def load_points(path):
    if path.endswith(".npy"):
        pts = np.load(path).astype(np.float32)
    else:
        with open(path, "r", errors="ignore") as f:
            lines = f.readlines()
        start = 0
        for i, line in enumerate(lines):
            if line.strip().startswith("DATA"):
                start = i + 1
                break
        pts = np.array(
            [[float(x) for x in ln.split()[:3]] for ln in lines[start:]
             if ln.strip()], dtype=np.float32)
    return pts


def list_split(root, split):
    split_file = os.path.join(root, "splits", f"{split}.txt")
    if os.path.exists(split_file):
        with open(split_file, "r", encoding="utf-8") as f:
            return [ln.strip() for ln in f if ln.strip()]
    part_dir = os.path.join(root, "pcd", split, "partial")
    rels = []
    for dirpath, _, files in os.walk(part_dir):
        for fn in files:
            if fn.endswith((".pcd", ".npy")):
                rels.append(os.path.relpath(
                    os.path.join(dirpath, fn), part_dir))
    return sorted(rels)


def normalize_pc(pts):
    pts = pts - pts.mean(0)
    scale = np.abs(pts).max()
    return pts / max(scale, 1e-6) * 0.45


def _strip_view(stem):
    """去掉文件名末尾的 __v<digits> 视角后缀。"""
    m = re.match(r"^(.*)__v\d+$", stem)
    return m.group(1) if m else stem


class ShapeNetCompletion(Dataset):
    def __init__(self, root, split="train", n_partial=2048,
                 n_complete=16384, point_only=False, view_id=0,
                 pre_normalized=False):
        self.root = root
        self.split = split
        self.n_partial = n_partial
        self.n_complete = n_complete
        self.point_only = point_only
        self.view_id = view_id
        self.pre_normalized = pre_normalized
        self.rels = list_split(root, split)
        if len(self.rels) == 0:
            raise RuntimeError(
                f"在 {root} 下没有找到 {split} 点云，请按 README 准备数据。")

    def __len__(self):
        return len(self.rels)

    def _find_asset(self, subdir, stem, ext, per_sample=True):
        """逐样本资产优先（渲染管线产物），其次 <stem>__<view_id> 约定。"""
        names = [f"{stem}.{ext}"] if per_sample else []
        names.append(f"{stem}__{self.view_id}.{ext}")
        for name in names:
            p = os.path.join(self.root, subdir, name)
            if os.path.exists(p):
                return p
        return None

    def _load_image(self, stem):
        try:
            from PIL import Image
        except ImportError as e:
            raise ImportError("加载真实渲染图需要 Pillow：pip install pillow") from e
        path = self._find_asset("renders", stem, "png")
        if path is None:
            if self.point_only:
                return None
            raise FileNotFoundError(f"缺少渲染图: renders/{stem}*.png")
        img = Image.open(path).convert("RGB")
        return np.asarray(img, dtype=np.float32) / 255.0

    def _load_cam(self, stem):
        path = self._find_asset("cams", stem, "json")
        if path is None:
            return None, None
        with open(path, "r", encoding="utf-8") as f:
            cam = json.load(f)
        return np.array(cam["K"], dtype=np.float32), np.array(cam["w2c"], dtype=np.float32)

    def _load_depth(self, stem, H, W):
        path = self._find_asset("depth", stem, "npy")
        if path is None:
            return np.zeros((H, W), dtype=np.float32)
        d = np.load(path).astype(np.float32)
        if d.shape != (H, W):
            return np.zeros((H, W), dtype=np.float32)
        return d

    def __getitem__(self, idx):
        rel = self.rels[idx]
        rel_noext = rel[:-4] if rel.endswith((".pcd", ".npy")) else rel
        part_path = os.path.join(self.root, "pcd", self.split, "partial", rel)

        # complete 与视角无关：去掉 __v<view>，并允许扩展名不一致
        comp_stem = _strip_view(rel_noext)
        comp_path = None
        for cand in (comp_stem + ".npy", comp_stem + ".pcd",
                     rel_noext + ".npy", rel_noext + ".pcd"):
            p = os.path.join(self.root, "pcd", self.split, "complete", cand)
            if os.path.exists(p):
                comp_path = p
                break
        if comp_path is None:
            raise FileNotFoundError(
                f"找不到 complete 点云: pcd/{self.split}/complete/{comp_stem}.*")

        partial = load_points(part_path)
        complete = load_points(comp_path)
        if not self.pre_normalized:
            partial = normalize_pc(partial)
            complete = normalize_pc(complete)

        rng = np.random.RandomState(None if self.split == "train" else idx)
        if len(partial) >= self.n_partial:
            partial = partial[rng.choice(len(partial), self.n_partial, replace=False)]
        else:
            pad = rng.choice(len(partial), self.n_partial - len(partial))
            partial = np.concatenate([partial, partial[pad]], 0)
        if len(complete) >= self.n_complete:
            complete = complete[rng.choice(len(complete), self.n_complete, replace=False)]
        else:
            pad = rng.choice(len(complete), self.n_complete - len(complete))
            complete = np.concatenate([complete, complete[pad]], 0)

        stem = rel_noext.replace("\\", "_").replace("/", "_")
        rgb = self._load_image(stem)
        if rgb is None:
            H = W = 112
            image = np.zeros((3, H, W), dtype=np.float32)
            mask = np.zeros((H, W), dtype=np.float32)
            depth = np.zeros((H, W), dtype=np.float32)
            # point-only：K/w2c 全 0，网络与视角损失据此关闭几何相关项
            K = np.zeros((3, 3), dtype=np.float32)
            w2c = np.zeros((4, 4), dtype=np.float32)
        else:
            H, W = rgb.shape[:2]
            K, w2c = self._load_cam(stem)
            if K is None:
                K, w2c = np.eye(3, dtype=np.float32), np.eye(4, dtype=np.float32)
            image = torch.from_numpy(rgb).permute(2, 0, 1).float()
            # 渲染背景为黑色；阈值 0.02 提取物体轮廓
            mask = (rgb.mean(-1) > 0.02).astype(np.float32)
            depth = self._load_depth(stem, H, W)

        syn = re.split(r"[\\/]", rel_noext)[0]
        syn_list = list(SYNSETS)
        category = syn_list.index(syn) if syn in syn_list else len(syn_list)

        return {
            "partial": torch.from_numpy(partial).float(),
            "complete": torch.from_numpy(complete).float(),
            "image": image if torch.is_tensor(image) else torch.from_numpy(image),
            "mask": torch.from_numpy(mask),
            "depth": torch.from_numpy(depth),
            "K": torch.from_numpy(K),
            "w2c": torch.from_numpy(w2c),
            "category": category,
            "id": rel_noext,
        }
