"""合成数据后端：参数化三角网格 + numpy 点投影 z-buffer 渲染。

用途：
  1) 不下载任何数据集即可端到端验证训练/评估代码的正确性；
  2) 论文实验请使用 data/shapenet.py 的 ShapeNet55/PCN 真实数据，
     合成数据不得作为论文结果来源。
"""
import numpy as np
import torch
from torch.utils.data import Dataset

CATEGORIES = ["box", "chair", "table", "sofa", "airplane", "car"]
ALBEDO = {
    "box": 0.72, "chair": 0.62, "table": 0.58, "sofa": 0.55,
    "airplane": 0.68, "car": 0.50,
}


def _box(center, size):
    """单位立方体 8 顶点 + 12 三角面，平移/缩放到指定 center/size。"""
    cx, cy, cz = center
    sx, sy, sz = size
    x = np.array([[0, 0, 0], [1, 0, 0], [1, 1, 0], [0, 1, 0],
                  [0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1]], dtype=np.float32)
    x = (x - 0.5) * np.array([sx, sy, sz], dtype=np.float32) + np.array(center, dtype=np.float32)
    f = np.array([
        [0, 1, 2], [0, 2, 3], [4, 5, 6], [4, 6, 7],
        [0, 1, 5], [0, 5, 4], [2, 3, 7], [2, 7, 6],
        [1, 2, 6], [1, 6, 5], [0, 3, 7], [0, 7, 4]], dtype=np.int64)
    return x, f


def _merge(meshes):
    vs, fs = [], []
    offset = 0
    for v, f in meshes:
        vs.append(v)
        fs.append(f + offset)
        offset += len(v)
    return np.concatenate(vs), np.concatenate(fs)


def build_mesh(category, rng):
    if category == "box":
        sx, sy, sz = rng.uniform(0.3, 0.9, size=3)
        return _merge([_box((0, 0, 0), (sx, sy, sz))])

    if category in ("chair", "sofa"):
        seat_w = rng.uniform(0.45, 0.6)
        seat_d = rng.uniform(0.4, 0.55)
        seat_h = rng.uniform(0.25, 0.35)
        parts = [_box((0, 0, seat_h / 2), (seat_w, seat_d, seat_h))]
        # 四条腿
        if category == "chair":
            leg_h = rng.uniform(0.35, 0.5)
            for dx in (-1, 1):
                for dy in (-1, 1):
                    parts.append(_box((dx * seat_w / 2 * 0.85,
                                       dy * seat_d / 2 * 0.85,
                                       -leg_h / 2 + seat_h),
                                      (0.06, 0.06, leg_h)))
            back_h = rng.uniform(0.4, 0.6)
            parts.append(_box((0, -seat_d / 2, seat_h + back_h / 2),
                              (seat_w, 0.06, back_h)))
        else:
            base_h = 0.2
            parts = [_box((0, 0, base_h / 2), (seat_w, seat_d, base_h))]
            parts.append(_box((0, -seat_d / 2, base_h + 0.25),
                              (seat_w, 0.1, 0.5)))
            parts.append(_box((-seat_w / 2, 0, base_h + 0.15),
                              (0.1, seat_d, 0.3)))
            parts.append(_box((seat_w / 2, 0, base_h + 0.15),
                              (0.1, seat_d, 0.3)))
        return _merge(parts)

    if category == "table":
        top_w = rng.uniform(0.6, 0.9)
        top_d = rng.uniform(0.4, 0.7)
        parts = [_box((0, 0, 0.38), (top_w, top_d, 0.06))]
        for dx in (-1, 1):
            for dy in (-1, 1):
                parts.append(_box((dx * top_w / 2 * 0.9,
                                   dy * top_d / 2 * 0.9, 0.18),
                                  (0.06, 0.06, 0.4)))
        return _merge(parts)

    if category == "airplane":
        parts = [_box((0, 0, 0), (0.18, 0.9, 0.18))]          # 机身
        parts.append(_box((0, 0.05, 0), (1.1, 0.18, 0.04)))   # 主翼
        parts.append(_box((0, -0.38, 0.08), (0.4, 0.12, 0.04)))  # 尾翼
        parts.append(_box((0, -0.38, 0.18), (0.05, 0.12, 0.3)))  # 垂尾
        return _merge(parts)

    # car
    parts = [_box((0, 0, 0.12), (0.5, 0.9, 0.24))]
    parts.append(_box((0, -0.05, 0.32), (0.4, 0.45, 0.2)))
    return _merge(parts)


def sample_surface(verts, faces, n_points, rng):
    v0 = verts[faces[:, 0]]
    v1 = verts[faces[:, 1]]
    v2 = verts[faces[:, 2]]
    areas = 0.5 * np.linalg.norm(np.cross(v1 - v0, v2 - v0), axis=1)
    probs = areas / areas.sum()
    face_idx = rng.choice(len(faces), size=n_points, p=probs)
    u = rng.random((n_points, 1)).astype(np.float32)
    v = rng.random((n_points, 1)).astype(np.float32)
    over = (u + v) > 1
    u[over] = 1 - u[over]
    v[over] = 1 - v[over]
    a, b, c = v0[face_idx], v1[face_idx], v2[face_idx]
    pts = a + u * (b - a) + v * (c - a)
    return pts.astype(np.float32)


def normalize_points(pts):
    center = (pts.max(0) + pts.min(0)) / 2
    pts = pts - center
    scale = np.abs(pts).max()
    return pts / max(scale, 1e-6) * 0.45


def look_at(eye, target=np.zeros(3), up=np.array([0.0, 0.0, 1.0])):
    z = target - eye
    z = z / np.linalg.norm(z)
    x = np.cross(up, z)
    x = x / np.linalg.norm(x)
    y = np.cross(z, x)
    R = np.stack([x, y, z], axis=0)  # CV 约定：相机前方为 +z
    t = -R @ eye
    w2c = np.eye(4, dtype=np.float32)
    w2c[:3, :3] = R
    w2c[:3, 3] = t
    return w2c.astype(np.float32)


def project(pts, K, w2c):
    cam = pts @ w2c[:3, :3].T + w2c[:3, 3]
    z = cam[:, 2]
    pix = cam @ K.T
    u = pix[:, 0] / np.maximum(pix[:, 2], 1e-6)
    v = pix[:, 1] / np.maximum(pix[:, 2], 1e-6)
    return u, v, z


def render_scene(pts, category, w2c, H, W, focal, rng, n_bins=40):
    K = np.array([[focal, 0, W / 2], [0, focal, H / 2], [0, 0, 1]],
                 dtype=np.float32)
    u, v, z = project(pts, K, w2c)
    ui = np.clip(np.round(u).astype(np.int64), 0, W - 1)
    vi = np.clip(np.round(v).astype(np.int64), 0, H - 1)
    in_front = z > 1e-3
    in_img = (u >= 0) & (u < W) & (v >= 0) & (v < H) & in_front

    # 全分辨率 z-buffer
    depth = np.full(H * W, np.inf, dtype=np.float32)
    flat = vi * W + ui
    np.minimum.at(depth, flat[in_img], z[in_img])
    depth_map = depth.reshape(H, W)
    mask = np.isfinite(depth_map)

    # 深度法向 + 简单 Lambert 着色
    d = np.where(mask, depth_map, depth_map[mask].mean() if mask.any() else 1.0)
    gz, gx = np.gradient(d)
    n = np.stack([-gx, -gz, np.ones_like(gx) * focal], axis=-1)
    n = n / np.linalg.norm(n, axis=-1, keepdims=True)
    light = np.array([0.3, -0.4, 0.85], dtype=np.float32)
    light /= np.linalg.norm(light)
    shade = np.clip((n @ light) * 0.5 + 0.6, 0.15, 1.0)
    base = ALBEDO[category]
    rgb = np.zeros((H, W, 3), dtype=np.float32)
    rgb[..., :] = (base * shade)[..., None]
    rgb = rgb * mask[..., None]
    depth_out = np.where(mask, depth_map, 0.0).astype(np.float32)

    # 低分辨率深度分箱 → 可见点（模拟单次深度相机遮挡）
    bu = np.clip((u / W * n_bins).astype(np.int64), 0, n_bins - 1)
    bv = np.clip((v / H * n_bins).astype(np.int64), 0, n_bins - 1)
    bin_depth = np.full(n_bins * n_bins, np.inf, dtype=np.float32)
    bidx = bv * n_bins + bu
    np.minimum.at(bin_depth, bidx[in_img], z[in_img])
    visible = in_img & (z <= bin_depth[bidx] + 0.02)
    return rgb, mask.astype(np.float32), depth_out, K, visible


class SyntheticCompletion(Dataset):
    """参数化合成补全数据集。

    Args:
        split: train/val/test
        n_partial/n_complete: 稀疏输入/完整真值点数
        image_size: 渲染分辨率
    """

    def __init__(self, split="train", n_samples=256, n_partial=2048,
                 n_complete=16384, image_size=112, n_render=32768,
                 categories=None):
        self.split = split
        self.n_samples = n_samples
        self.n_partial = n_partial
        self.n_complete = n_complete
        self.H = self.W = image_size
        self.n_render = n_render
        self.focal = 1.15 * image_size
        if categories is None:
            self.categories = CATEGORIES
        else:
            bad = [c for c in categories if c not in CATEGORIES]
            if bad:
                raise ValueError(f"未知合成类别: {bad}，可选 {CATEGORIES}")
            self.categories = list(categories)

    def __len__(self):
        return self.n_samples * len(self.categories)

    def __getitem__(self, idx):
        cat = self.categories[idx % len(self.categories)]
        rng = np.random.RandomState(idx if self.split != "train" else None)
        verts, faces = build_mesh(cat, rng)
        pts = sample_surface(verts, faces, self.n_render, rng)
        pts = normalize_points(pts)

        if self.split == "train":
            az = rng.uniform(0, 2 * np.pi)
            el = rng.uniform(0.25, 0.7)
        else:
            az = (idx * 0.7) % (2 * np.pi)
            el = 0.5
        eye = np.array([np.cos(az) * np.cos(el),
                        np.sin(az) * np.cos(el),
                        np.sin(el)], dtype=np.float32) * 1.6
        w2c = look_at(eye)

        rgb, mask, depth, K, visible = render_scene(
            pts, cat, w2c, self.H, self.W, self.focal, rng)

        vis_idx = np.where(visible)[0]
        if len(vis_idx) >= self.n_partial:
            partial = pts[rng.choice(vis_idx, self.n_partial, replace=False)]
        else:
            pad = rng.choice(len(pts), self.n_partial - len(vis_idx))
            partial = np.concatenate([pts[vis_idx], pts[pad]], axis=0)
        complete = pts[rng.choice(len(pts), self.n_complete, replace=len(pts) < self.n_complete)]

        return {
            "partial": torch.from_numpy(partial).float(),
            "complete": torch.from_numpy(complete).float(),
            "image": torch.from_numpy(rgb).permute(2, 0, 1).contiguous(),
            "mask": torch.from_numpy(mask),
            "depth": torch.from_numpy(depth),
            "K": torch.from_numpy(K),
            "w2c": torch.from_numpy(w2c),
            "category": CATEGORIES.index(cat),
            "id": f"{cat}_{idx}",
        }
