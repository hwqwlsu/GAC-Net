from .synthetic import SyntheticCompletion, CATEGORIES as SYNTH_CATEGORIES
from .shapenet import ShapeNetCompletion, CATEGORY_NAMES as SHAPENET_CATEGORIES


def build_dataset(cfg, split):
    name = cfg["dataset"]
    common = {
        "n_partial": cfg["n_partial"],
        "n_complete": cfg["n_complete"],
    }
    if name == "synthetic":
        return SyntheticCompletion(
            split=split,
            n_samples=cfg["synthetic_samples"][split],
            image_size=cfg["image_size"],
            categories=cfg.get("synthetic_categories"),
            **common)
    if name == "shapenet55":
        return ShapeNetCompletion(
            root=cfg["data_root"], split=split,
            point_only=cfg.get("point_only", False),
            view_id=cfg.get("view_id", 0),
            pre_normalized=cfg.get("pre_normalized", False), **common)
    raise ValueError(f"未知数据集: {name}")
