"""评估指标：CD-L1 / CD-L2（×1e4）、F-Score。

所有点云已在数据侧归一化到单位包围盒，阈值 tau 取包围盒尺度比例
（PoinTr/ShapeNet-55 常用 tau=0.01, 0.02）。
"""
import torch

from .losses import _pairwise_min


@torch.no_grad()
def chamfer_metrics(pred, gt, chunk=4096):
    """返回单个样本批次上的平均 CD-L1、CD-L2（原始尺度）。"""
    d_pred = _pairwise_min(pred, gt, chunk)
    d_gt = _pairwise_min(gt, pred, chunk)
    cd_l1 = 0.5 * (d_pred.mean() + d_gt.mean())
    cd_l2 = 0.5 * ((d_pred ** 2).mean() + (d_gt ** 2).mean())
    return cd_l1.item(), cd_l2.item()


@torch.no_grad()
def f_score(pred, gt, tau=0.01, chunk=4096):
    """F-Score @ tau：预测与真值互相在阈值内的点比例的调和平均。"""
    d_pred = _pairwise_min(pred, gt, chunk)
    d_gt = _pairwise_min(gt, pred, chunk)
    precision = (d_pred < tau).float().mean()
    recall = (d_gt < tau).float().mean()
    f1 = 2 * precision * recall / (precision + recall + 1e-8)
    return f1.item()


@torch.no_grad()
def evaluate_sample(pred, gt, taus=(0.01, 0.02)):
    """单样本全套指标。pred/gt: (N,3)。"""
    pred = pred.unsqueeze(0)
    gt = gt.unsqueeze(0)
    cd1, cd2 = chamfer_metrics(pred, gt)
    out = {"CD_L1_x1e4": cd1 * 1e4, "CD_L2_x1e4": cd2 * 1e4}
    for t in taus:
        out[f"Fscore@{t}"] = f_score(pred, gt, tau=t)
    return out
