"""GACA：几何锚定跨模态注意力（Geometry-Anchored Cross-Attention）。

点 token 作为 Query，图像 patch token 作为 Key/Value；
利用相机内外参把点中心投影到图像平面，在注意力 logits 上叠加
与 patch 位置相关的高斯几何偏置，避免跨模态匹配只依赖外观相似性。
"""
import torch
import torch.nn as nn


class PosMLP(nn.Module):
    def __init__(self, in_dim, out_dim, hidden=128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden), nn.ReLU(inplace=True),
            nn.Linear(hidden, out_dim))

    def forward(self, x):
        return self.net(x)


def project_points(xyz, K, w2c, H, W, eps=1e-6):
    """将物体坐标点投影到归一化图像坐标。

    Args:
        xyz: (B,N,3) 物体坐标系
        K: (B,3,3) 相机内参（像素单位）
        w2c: (B,3,3) 或 (B,4,4) 世界(物体)→相机
        H, W: 图像尺寸
    Returns:
        uv_norm: (B,N,2) 归一化到 [-1,1]
        visible: (B,N) bool
    """
    R = w2c[:, :3, :3]
    t = w2c[:, :3, 3] if w2c.shape[-1] == 4 else None
    cam = torch.bmm(xyz, R.transpose(1, 2))
    if t is not None:
        cam = cam + t.unsqueeze(1)
    z = cam[..., 2]
    pix = torch.bmm(cam, K.transpose(1, 2))
    u = pix[..., 0] / (pix[..., 2].abs() + eps)
    v = pix[..., 1] / (pix[..., 2].abs() + eps)
    u_norm = 2.0 * u / max(W - 1, 1) - 1.0
    v_norm = 2.0 * v / max(H - 1, 1) - 1.0
    in_front = z > 1e-4
    in_plane = (u >= 0) & (u < W) & (v >= 0) & (v < H)
    return torch.stack([u_norm, v_norm], dim=-1), in_front & in_plane


class GeometryAnchoredCrossAttention(nn.Module):
    def __init__(self, dim=256, num_heads=4, ffn_mult=4, geo_sigma=0.25):
        super().__init__()
        self.dim = dim
        self.point_proj = nn.Linear(128, dim)
        self.image_proj = nn.Linear(256, dim)
        self.point_pos = PosMLP(3, dim)
        self.image_pos = PosMLP(2, dim)
        self.attn = nn.MultiheadAttention(dim, num_heads, batch_first=True)
        self.norm1 = nn.LayerNorm(dim)
        self.norm2 = nn.LayerNorm(dim)
        self.ffn = nn.Sequential(
            nn.Linear(dim, dim * ffn_mult), nn.GELU(),
            nn.Linear(dim * ffn_mult, dim))
        self.geo_scale = nn.Parameter(torch.tensor(1.0 / (geo_sigma ** 2)))
        self.pool_proj = nn.Linear(dim * 2, dim)

    def forward(self, point_xyz, point_feat, image_tokens, grid,
                K=None, w2c=None, image_size=None):
        """
        Args:
            point_xyz: (B,Np,3)
            point_feat: (B,Np,128)
            image_tokens: (B,Ni,256)
            grid: (h, w)
            K, w2c: 可选，(B,3,3)/(B,4,4)
            image_size: (H, W)
        Returns:
            fused: (B,Np,dim)
            global_feat: (B,dim)
        """
        B, Np, _ = point_xyz.shape
        h, w = grid
        q = self.point_proj(point_feat) + self.point_pos(point_xyz)
        k = self.image_proj(image_tokens)

        # 图像 patch 中心归一化坐标
        us = (torch.arange(w, device=q.device, dtype=q.dtype) + 0.5) / w
        vs = (torch.arange(h, device=q.device, dtype=q.dtype) + 0.5) / h
        grid_v, grid_u = torch.meshgrid(vs, us, indexing="ij")
        uv_grid = torch.stack([grid_u * 2 - 1, grid_v * 2 - 1], dim=-1)
        k = k + self.image_pos(uv_grid.reshape(1, h * w, 2))

        attn_mask = None
        if K is not None and w2c is not None and image_size is not None:
            H, W = image_size
            uv_pt, visible = project_points(point_xyz, K, w2c, H, W)
            d2 = ((uv_pt.unsqueeze(2) - uv_grid.reshape(1, 1, h * w, 2)) ** 2).sum(-1)
            bias = -d2 * self.geo_scale.clamp(min=0.1)  # (B,Np,Ni)
            bias = bias.masked_fill(~visible.unsqueeze(-1), 0.0)
            # nn.MultiheadAttention 的 3D mask 形状需为 (B*heads, Nq, Nk)
            nh = self.attn.num_heads
            attn_mask = bias.unsqueeze(1).expand(B, nh, Np, h * w)
            attn_mask = attn_mask.reshape(B * nh, Np, h * w)

        out, _ = self.attn(q, k, k, attn_mask=attn_mask, need_weights=False)
        x = self.norm1(q + out)
        x = self.norm2(x + self.ffn(x))

        pooled = torch.cat([x.max(dim=1)[0], x.mean(dim=1)], dim=-1)
        # 返回：融合点 token、点全局特征、投影后的图像 token
        return x, self.pool_proj(pooled), k
