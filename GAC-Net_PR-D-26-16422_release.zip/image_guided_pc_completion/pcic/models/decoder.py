"""由粗到细的点云补全解码器。

1) 由点/图像全局特征生成 coarse seeds；
2) seed token 通过 Transformer 解码器与融合后的点 token、图像 token 交互；
3) 两级雪片式分裂（point splitting）逐级加密点云。
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class PointSplit(nn.Module):
    """雪片式点分裂：每个父点生成 up 个带学习偏移的子点。"""

    def __init__(self, dim, up=8, use_attention=False, num_heads=4,
                 init_radius=0.05):
        super().__init__()
        self.up = up
        self.use_attention = use_attention
        self.child_embed = nn.Parameter(torch.randn(up, dim) * 0.02)
        self.fc_in = nn.Sequential(
            nn.Linear(dim * 2, dim), nn.ReLU(inplace=True),
            nn.Linear(dim, dim))
        if use_attention:
            layer = nn.TransformerEncoderLayer(
                dim, num_heads, dim * 2, batch_first=True,
                activation="gelu", norm_first=True)
            self.refine = nn.TransformerEncoder(layer, num_layers=1)
        self.fc_off = nn.Linear(dim, 3)
        self.fc_feat = nn.Linear(dim, dim)
        self.radius = nn.Parameter(torch.tensor(float(init_radius)))

    def forward(self, xyz, feat):
        B, N, C = feat.shape
        emb = self.child_embed.view(1, 1, self.up, C).expand(B, N, -1, -1)
        parent = feat.unsqueeze(2).expand(-1, -1, self.up, -1)
        child = self.fc_in(torch.cat([parent, emb], dim=-1))  # (B,N,k,C)

        new_xyz = xyz.unsqueeze(2) + torch.tanh(self.fc_off(child)) * self.radius
        new_feat = self.fc_feat(child)

        new_xyz = new_xyz.reshape(B, N * self.up, 3)
        new_feat = new_feat.reshape(B, N * self.up, C)
        if self.use_attention:
            new_feat = self.refine(new_feat)
        return new_xyz, new_feat


class CompletionDecoder(nn.Module):
    def __init__(self, dim=256, n_seed=256, up_factors=(8, 8),
                 num_heads=4):
        super().__init__()
        self.n_seed = n_seed
        # 全局特征 = 点全局(512) + 图像全局(512)
        self.fc_latent = nn.Sequential(
            nn.Linear(512 + 512, dim), nn.ReLU(inplace=True),
            nn.Linear(dim, dim))
        self.fc_seed_xyz = nn.Linear(dim, n_seed * 3)
        self.fc_seed_feat = nn.Linear(dim, n_seed * dim)
        self.dim = dim

        # seed 与点 token / 图像 token 交互
        dec_layer = nn.TransformerDecoderLayer(
            dim, num_heads, dim * 4, batch_first=True,
            activation="gelu", norm_first=True)
        self.seed_refine = nn.TransformerDecoder(dec_layer, num_layers=2)
        self.coarse_delta = nn.Sequential(
            nn.Linear(dim, dim), nn.ReLU(inplace=True), nn.Linear(dim, 3))
        self.coarse_scale = nn.Parameter(torch.tensor(0.1))

        assert len(up_factors) in (1, 2)
        self.split1 = PointSplit(dim, up_factors[0], use_attention=True,
                                 init_radius=0.05)
        # 单级消融：up_factors=[64] 时无第二级
        self.split2 = (PointSplit(dim, up_factors[1], use_attention=False,
                                  init_radius=0.02)
                       if len(up_factors) == 2 else None)

    def forward(self, point_global, image_global, point_tokens, image_tokens):
        """
        Args:
            point_global: (B,512)
            image_global: (B,512) 维度不足时由外部投影
            point_tokens: (B,Np,dim)
            image_tokens: (B,Ni,dim)
        Returns:
            coarse: (B,n_seed,3), fine: (B,n_seed*up1*up2,3)
        """
        B = point_global.shape[0]
        g = self.fc_latent(torch.cat([point_global, image_global], dim=-1))
        coarse = torch.sigmoid(self.fc_seed_xyz(g)).reshape(B, self.n_seed, 3) - 0.5
        seed_feat = self.fc_seed_feat(g).reshape(B, self.n_seed, self.dim)

        if image_tokens is None:  # 无图像消融：memory 仅含点 token
            memory = point_tokens
        else:
            memory = torch.cat([point_tokens, image_tokens], dim=1)
        seed_feat = self.seed_refine(seed_feat, memory)
        coarse = coarse + torch.tanh(self.coarse_delta(seed_feat)) * self.coarse_scale

        x1, f1 = self.split1(coarse, seed_feat)
        if self.split2 is not None:
            fine, _ = self.split2(x1, f1)
        else:
            fine = x1
        return coarse, fine
