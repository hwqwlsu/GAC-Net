"""GAC-Net 总体网络：点分支 + 图像分支 + GACA 融合 + 由粗到细补全解码。"""
import torch
import torch.nn as nn

from .pointnet2 import PointNet2Encoder
from .image_encoder import ImageEncoder
from .fusion import GeometryAnchoredCrossAttention
from .decoder import CompletionDecoder

IMAGENET_MEAN = (0.485, 0.456, 0.406)
IMAGENET_STD = (0.229, 0.224, 0.225)


class GACNet(nn.Module):
    """Geometry-Anchored Cross-modal completion network.

    Args:
        dim: 跨模态隐空间维度
        n_seed / up_factors: 解码器 seed 数与两级分裂倍率
        pretrained_image: 是否使用 ImageNet 预训练 ResNet18
        use_view: 是否在网络侧保留视角相关张量（视角一致性损失在外部计算）
    """

    def __init__(self, dim=256, n_seed=256, up_factors=(8, 8),
                 pretrained_image=True, num_heads=4,
                 n_l1=512, k_group=16, use_image=True,
                 geo_anchor=True, fusion_mode="gaca"):
        super().__init__()
        self.use_image = use_image
        self.geo_anchor = geo_anchor
        self.fusion_mode = fusion_mode
        self.point_encoder = PointNet2Encoder(n_l1=n_l1, k=k_group)
        self.point_global_proj = nn.Linear(512, 512)
        if use_image:
            self.image_encoder = ImageEncoder(pretrained=pretrained_image)
            if fusion_mode == "gaca":
                self.fusion = GeometryAnchoredCrossAttention(
                    dim=dim, num_heads=num_heads)
            else:  # concat 融合消融：早期拼接替代跨模态注意力
                self.concat_proj = nn.Linear(
                    128 + self.image_encoder.global_dim, dim)
            self.image_global_proj = nn.Linear(self.image_encoder.global_dim, 512)
            # gaca 模式下融合输出为 dim；concat 模式下为原始图像 token 维度
            tok_in = dim if fusion_mode == "gaca" else self.image_encoder.token_dim
            self.image_token_proj = nn.Linear(tok_in, dim)
        else:
            # 无图像消融：点 token 直接投影到跨模态维度，无图像分支参数
            self.point_token_proj = nn.Linear(128, dim)
        self.decoder = CompletionDecoder(
            dim=dim, n_seed=n_seed, up_factors=up_factors,
            num_heads=num_heads)
        self.register_buffer(
            "mean", torch.tensor(IMAGENET_MEAN).view(1, 3, 1, 1), persistent=False)
        self.register_buffer(
            "std", torch.tensor(IMAGENET_STD).view(1, 3, 1, 1), persistent=False)

    def forward(self, batch):
        points = batch["partial"]          # (B,N,3)
        l1_xyz, l1_feat, _, _, point_global = self.point_encoder(points)

        if self.use_image:
            image = batch["image"]         # (B,3,H,W) in [0,1]
            image = (image - self.mean) / self.std
            img_tokens, grid, img_global = self.image_encoder(image)

            K = batch.get("K")
            w2c = batch.get("w2c")
            # point-only 数据没有相机参数（K 全 0），或消融关闭几何锚定时，关闭几何偏置
            if K is not None and (float(K.abs().sum()) == 0.0 or not self.geo_anchor):
                K = w2c = None
            if self.fusion_mode == "gaca":
                point_tokens, _, img_tokens_fused = self.fusion(
                    l1_xyz, l1_feat, img_tokens, grid,
                    K=K, w2c=w2c,
                    image_size=(image.shape[-2], image.shape[-1]))
                img_tokens_dec = self.image_token_proj(img_tokens_fused)
            else:  # concat：图像全局特征广播拼接到每个点 token
                gi = img_global.unsqueeze(1).expand(-1, l1_feat.shape[1], -1)
                point_tokens = self.concat_proj(torch.cat([l1_feat, gi], dim=-1))
                img_tokens_dec = self.image_token_proj(img_tokens)
            image_global = self.image_global_proj(img_global)
        else:
            point_tokens = self.point_token_proj(l1_feat)
            img_tokens_dec = None
            image_global = torch.zeros(
                points.shape[0], 512, device=points.device, dtype=points.dtype)

        coarse, fine = self.decoder(
            self.point_global_proj(point_global),
            image_global, point_tokens, img_tokens_dec)
        return {"coarse": coarse, "fine": fine}
