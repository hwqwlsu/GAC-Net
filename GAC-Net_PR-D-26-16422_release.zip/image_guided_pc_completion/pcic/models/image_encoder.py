"""图像分支编码器：ResNet18（ImageNet 预训练可选）。

输出 layer3 特征图作为图像 token（stride 16），以及 layer4 全局特征。
"""
import torch
import torch.nn as nn

try:
    from torchvision.models import resnet18, ResNet18_Weights
    _HAS_TV = True
except Exception:  # pragma: no cover
    _HAS_TV = False


class SmallCNN(nn.Module):
    """无 torchvision 时的兜底小型 CNN（论文实验不要使用，仅保证代码可运行）。"""

    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(3, 32, 3, 2, 1), nn.BatchNorm2d(32), nn.ReLU(),
            nn.Conv2d(32, 64, 3, 2, 1), nn.BatchNorm2d(64), nn.ReLU(),
            nn.Conv2d(64, 128, 3, 2, 1), nn.BatchNorm2d(128), nn.ReLU(),
            nn.Conv2d(128, 256, 3, 2, 1), nn.BatchNorm2d(256), nn.ReLU(),
        )

    def forward(self, x):
        f = self.net(x)              # (B,256,H/16,W/16)
        g = f.mean(dim=(2, 3))       # (B,256)
        return f, g, 512            # layer4 缺失，用 0 占位全局维度由网络处理


class ImageEncoder(nn.Module):
    def __init__(self, pretrained: bool = True, use_layer3: bool = True):
        super().__init__()
        if _HAS_TV:
            weights = ResNet18_Weights.IMAGENET1K_V1 if pretrained else None
            try:
                net = resnet18(weights=weights)
            except Exception:
                # 离线环境无法下载权重时回退随机初始化，保证可运行
                net = resnet18(weights=None)
            self.stem = nn.Sequential(net.conv1, net.bn1, net.relu, net.maxpool)
            self.layer1 = net.layer1
            self.layer2 = net.layer2
            self.layer3 = net.layer3
            self.layer4 = net.layer4
            self.token_dim = 256
            self.global_dim = 512
            self._fallback = False
        else:
            self._fallback = True
            self.small = SmallCNN()
            self.token_dim = 256
            self.global_dim = 256

    def forward(self, x):
        """
        Args:
            x: (B,3,H,W)，ImageNet 归一化后的 RGB
        Returns:
            tokens: (B, h*w, token_dim)
            grid: (h, w) 特征图尺寸
            global_feat: (B, global_dim)
        """
        if self._fallback:
            f, g, _ = self.small(x)
            B, C, h, w = f.shape
            return f.flatten(2).transpose(1, 2), (h, w), g

        x = self.stem(x)
        x = self.layer1(x)
        x = self.layer2(x)
        f3 = self.layer3(x)                       # (B,256,h,w)
        f4 = self.layer4(f3)                     # (B,512,h/2,w/2)
        B, C, h, w = f3.shape
        tokens = f3.flatten(2).transpose(1, 2)   # (B,h*w,256)
        global_feat = f4.mean(dim=(2, 3))        # (B,512)
        return tokens, (h, w), global_feat
