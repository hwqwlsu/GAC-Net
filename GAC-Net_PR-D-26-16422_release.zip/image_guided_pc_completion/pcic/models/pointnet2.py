"""纯 PyTorch 实现的 PointNet++ 编码器（FPS + KNN 球组邻域）。

不依赖 pointnet2_ops 等 CUDA 扩展，Windows/Linux 均可直接运行；
输入输出张量约定与论文方法节一一对应。
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


def furthest_point_sample(xyz: torch.Tensor, npoint: int) -> torch.Tensor:
    """最远点采样。

    Args:
        xyz: (B, N, 3)
        npoint: 采样点数 M
    Returns:
        idx: (B, M)
    """
    B, N, _ = xyz.shape
    device = xyz.device
    centroids = torch.zeros(B, npoint, dtype=torch.long, device=device)
    distance = torch.full((B, N), 1e10, device=device)
    farthest = torch.randint(0, N, (B,), device=device)
    batch_idx = torch.arange(B, device=device)
    for i in range(npoint):
        centroids[:, i] = farthest
        centroid = xyz[batch_idx, farthest, :].unsqueeze(1)  # (B,1,3)
        dist = ((xyz - centroid) ** 2).sum(-1)
        distance = torch.min(distance, dist)
        farthest = distance.argmax(-1)
    return centroids


def knn_query(k: int, query_xyz: torch.Tensor, key_xyz: torch.Tensor):
    """K 近邻索引。

    Returns:
        idx: (B, M, k)，query_xyz 中每个点在 key_xyz 中的 k 个近邻
    """
    dist = torch.cdist(query_xyz, key_xyz)  # (B,M,N)
    _, idx = dist.topk(k, dim=-1, largest=False)
    return idx


def gather_points(features: torch.Tensor, idx: torch.Tensor) -> torch.Tensor:
    """按索引聚集点特征。

    Args:
        features: (B, N, C)
        idx: (B, M, k)
    Returns:
        (B, M, k, C)
    """
    B, M, k = idx.shape
    C = features.shape[-1]
    idx_exp = idx.unsqueeze(-1).expand(-1, -1, -1, C)  # (B,M,k,C)
    expanded = features.unsqueeze(1).expand(B, M, -1, -1)  # (B,M,N,C)
    return torch.gather(expanded, 2, idx_exp)  # (B,M,k,C)


class SharedMLP(nn.Module):
    """逐点共享 MLP（Linear + BN1d + ReLU）。"""

    def __init__(self, channels):
        super().__init__()
        layers = []
        for i in range(len(channels) - 1):
            layers += [nn.Linear(channels[i], channels[i + 1], bias=False),
                       nn.BatchNorm1d(channels[i + 1]),
                       nn.ReLU(inplace=True)]
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        # x: (..., C)
        orig = x.shape
        x = self.net(x.reshape(-1, orig[-1])).reshape(*orig[:-1], -1)
        return x


class SetAbstraction(nn.Module):
    """PointNet++ set abstraction：FPS 下采样 + KNN 分组 + 局部 PointNet。"""

    def __init__(self, npoint: int, k: int, in_dim: int, mlp_channels):
        super().__init__()
        self.npoint = npoint
        self.k = k
        self.mlp = SharedMLP(mlp_channels)
        assert mlp_channels[0] == in_dim

    def forward(self, xyz, features=None):
        """
        Args:
            xyz: (B,N,3)
            features: (B,N,C) 或 None
        Returns:
            new_xyz: (B,M,3), new_feat: (B,M,Cout)
        """
        fps_idx = furthest_point_sample(xyz, self.npoint)  # (B,M)
        new_xyz = torch.gather(xyz, 1, fps_idx.unsqueeze(-1).expand(-1, -1, 3))
        group_idx = knn_query(self.k, new_xyz, xyz)  # (B,M,k)
        group_xyz = gather_points(xyz, group_idx)  # (B,M,k,3)
        centered = group_xyz - new_xyz.unsqueeze(2)
        if features is not None:
            group_feat = gather_points(features, group_idx)
            local = torch.cat([centered, group_feat], dim=-1)
        else:
            local = centered
        local = self.mlp(local)  # (B,M,k,Cout)
        new_feat = local.max(dim=2)[0]  # (B,M,Cout)
        return new_xyz, new_feat


class PointNet2Encoder(nn.Module):
    """两层 SA 点云编码器。

    输出：
        l1_xyz (B,512,3), l1_feat (B,512,128)  —— 供跨模态融合的点 token
        l2_xyz (B,128,3), l2_feat (B,128,512)
        global_feat (B,512)                     —— 最大池化全局特征
    """

    def __init__(self, n_l1=512, n_l2=128, k=16):
        super().__init__()
        self.sa1 = SetAbstraction(n_l1, k, in_dim=3, mlp_channels=[3, 64, 64, 128])
        self.sa2 = SetAbstraction(n_l2, k, in_dim=128 + 3, mlp_channels=[131, 256, 256, 512])

    def forward(self, points):
        # points: (B,N,3)
        l1_xyz, l1_feat = self.sa1(points, None)
        l2_xyz, l2_feat = self.sa2(l1_xyz, l1_feat)
        global_feat = l2_feat.max(dim=1)[0]  # (B,512)
        return l1_xyz, l1_feat, l2_xyz, l2_feat, global_feat
