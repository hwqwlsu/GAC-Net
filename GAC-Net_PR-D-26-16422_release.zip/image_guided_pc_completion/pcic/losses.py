"""训练损失：对称 Chamfer 距离（分块计算，避免 16384^2 显存爆炸）+
视角一致性损失（预测点云投影轮廓/深度与输入 RGB 视图对齐）。
"""
import torch


def _pairwise_min(src, dst, chunk=2048):
    """对 src 中每个点求到 dst 的最近距离（分块）。返回 (B,N_src)。"""
    B = src.shape[0]
    outs = []
    for i in range(0, src.shape[1], chunk):
        d = torch.cdist(src[:, i:i + chunk], dst)  # (B,c,M)
        outs.append(d.min(dim=-1).values)
    return torch.cat(outs, dim=1)


def chamfer_distance(pred, gt, p=1, chunk=2048):
    """对称 Chamfer 距离。

    Args:
        pred, gt: (B,N,3) / (B,M,3)
        p: 1 为 CD-L1（PCN/PoinTr 常用），2 为 CD-L2
    """
    d_pred = _pairwise_min(pred, gt, chunk)
    d_gt = _pairwise_min(gt, pred, chunk)
    if p == 2:
        d_pred, d_gt = d_pred ** 2, d_gt ** 2
    return d_pred.mean() + d_gt.mean()


def silhouette_view_loss(pred, K, w2c, mask_gt, depth_gt=None,
                         sigma_px=3.0, depth_weight=0.5):
    """把预测点云投影到输入相机，与渲染真值做软轮廓/深度一致性。

    Args:
        pred: (B,N,3)
        K: (B,3,3)
        w2c: (B,4,4) 或 (B,3,3)
        mask_gt: (B,H,W) 物体轮廓 0/1
        depth_gt: (B,H,W) 深度真值，0 表示无效像素（可选）
        sigma_px: 点 splat 高斯半径（像素）
    """
    B, H, W = mask_gt.shape
    R = w2c[:, :3, :3]
    t = w2c[:, :3, 3] if w2c.shape[-1] == 4 else torch.zeros(B, 3, device=pred.device)
    cam = torch.bmm(pred, R.transpose(1, 2)) + t.unsqueeze(1)
    z = cam[..., 2]
    pix = torch.bmm(cam, K.transpose(1, 2))
    u = pix[..., 0] / (pix[..., 2].abs() + 1e-6)
    v = pix[..., 1] / (pix[..., 2].abs() + 1e-6)
    valid = (z > 1e-4) & (u >= 0) & (u < W) & (v >= 0) & (v < H)

    ui = u.clamp(0, W - 1.001)
    vi = v.clamp(0, H - 1.001)
    u0, v0 = ui.floor(), vi.floor()
    fu, fv = ui - u0, vi - v0
    w00 = (1 - fu) * (1 - fv)
    w10 = fu * (1 - fv)
    w01 = (1 - fu) * fv
    w11 = fu * fv

    # 每个点按高斯 splat 强度加权（双线性散布到 4 个最近像素）
    gauss = torch.exp(-((ui - u.round()) ** 2 + (vi - v.round()) ** 2)
                      / (2.0 * sigma_px ** 2))

    energy = torch.zeros(B, H * W, device=pred.device)
    depth_num = torch.zeros(B, H * W, device=pred.device)
    depth_den = torch.zeros(B, H * W, device=pred.device) + 1e-8
    corners = [
        (u0.long(), v0.long(), w00),
        ((u0 + 1).long(), v0.long(), w10),
        (u0.long(), (v0 + 1).long(), w01),
        ((u0 + 1).long(), (v0 + 1).long(), w11),
    ]
    valid_f = valid.float() * gauss
    for cu, cv, cw in corners:
        cw = cw * valid_f
        idx = (cv * W + cu).clamp(0, H * W - 1)
        energy.scatter_add_(1, idx, cw)
        depth_num.scatter_add_(1, idx, cw * z)
        depth_den.scatter_add_(1, idx, cw)

    # BCE 与深度归约在 autocast 下不安全/对精度敏感，显式 float32 计算
    with torch.amp.autocast(pred.device.type, enabled=False):
        alpha_pred = (1.0 - torch.exp(-energy.float())).reshape(B, H, W)
        mask_loss = torch.nn.functional.binary_cross_entropy(
            alpha_pred.clamp(1e-5, 1 - 1e-5), mask_gt.float(), reduction="mean")

        loss = mask_loss
        if depth_gt is not None:
            d_valid = (depth_gt > 0).float()
            d_pred = (depth_num.float() / depth_den.float()).reshape(B, H, W)
            d_err = (d_pred - depth_gt.float()).abs() * d_valid
            loss = loss + depth_weight * d_err.sum() / d_valid.sum().clamp(min=1.0)
    return loss


def completion_loss(outputs, batch, cfg):
    """总损失 = coarse CD + fine CD (+ 视角一致性)。"""
    gt = batch["complete"]
    B, M, _ = gt.shape
    coarse = outputs["coarse"]
    fine = outputs["fine"]

    # coarse 对随机下采样真值
    perm = torch.randperm(M, device=gt.device)[:coarse.shape[1]]
    gt_coarse = gt[:, perm]

    l_coarse = chamfer_distance(coarse, gt_coarse, p=1)
    l_fine = chamfer_distance(fine, gt, p=1)
    total = cfg["w_coarse"] * l_coarse + cfg["w_fine"] * l_fine

    logs = {"loss_coarse": l_coarse.detach(), "loss_fine": l_fine.detach()}
    K = batch.get("K")
    if K is not None and float(K.abs().sum()) == 0.0:
        K = None
    if cfg.get("w_view", 0.0) > 0 and K is not None:
        l_view = silhouette_view_loss(
            fine, K, batch["w2c"], batch["mask"], batch.get("depth"),
            depth_weight=cfg.get("view_depth_weight", 0.5))
        total = total + cfg["w_view"] * l_view
        logs["loss_view"] = l_view.detach()
    logs["loss_total"] = total.detach()
    return total, logs
