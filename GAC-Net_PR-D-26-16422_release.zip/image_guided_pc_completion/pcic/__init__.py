"""Image-Guided Sparse Point Cloud Completion (PCIC)."""
