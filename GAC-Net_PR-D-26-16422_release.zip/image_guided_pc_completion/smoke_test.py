"""端到端冒烟测试：合成数据上验证前向/反向/评估全链路。

    python smoke_test.py
不下载任何数据，CPU/GPU 均可运行。只验证代码正确性，不产生论文结果。
"""
import torch
from torch.utils.data import DataLoader

from pcic.data import build_dataset
from pcic.models import GACNet
from pcic.losses import completion_loss
from pcic.metrics import chamfer_metrics, f_score
from pcic.utils import seed_everything, count_parameters


def main():
    seed_everything(0)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    cfg = {
        "dataset": "synthetic", "n_partial": 512, "n_complete": 2048,
        "image_size": 64,
        "synthetic_samples": {"train": 96, "val": 24, "test": 24},
    }
    model_cfg = {"dim": 128, "n_seed": 64, "up_factors": [4, 8],
                 "pretrained_image": False, "num_heads": 4,
                 "n_l1": 128, "k_group": 8}
    loss_cfg = {"w_coarse": 1.0, "w_fine": 1.0, "w_view": 0.05}

    train_set = build_dataset(cfg, "train")
    test_set = build_dataset(cfg, "test")
    loader = DataLoader(train_set, batch_size=8, shuffle=True, num_workers=0)
    test_loader = DataLoader(test_set, batch_size=8, num_workers=0)

    model = GACNet(**model_cfg).to(device)
    print(f"参数量: {count_parameters(model)/1e6:.2f}M, device={device}")
    opt = torch.optim.AdamW(model.parameters(), lr=5e-4)

    def move(batch):
        return {k: (v.to(device) if torch.is_tensor(v) else v) for k, v in batch.items()}

    model.train()
    losses = []
    for epoch in range(8):
        ep = 0.0
        for batch in loader:
            batch = move(batch)
            opt.zero_grad()
            out = model(batch)
            assert out["coarse"].shape[1:] == (64, 3), out["coarse"].shape
            assert out["fine"].shape[1:] == (2048, 3), out["fine"].shape
            loss, _ = completion_loss(out, batch, loss_cfg)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
            ep += float(loss)
        losses.append(ep / len(loader))
        print(f"epoch {epoch+1}: loss={losses[-1]:.5f}")

    assert all(torch.isfinite(p).all() for p in model.parameters()), "参数出现 NaN"
    assert losses[-1] < losses[0], f"损失未下降: {losses[0]:.4f} -> {losses[-1]:.4f}"

    model.eval()
    cd_vals, fs_vals = [], []
    with torch.no_grad():
        for batch in test_loader:
            batch = move(batch)
            out = model(batch)
            cd1, cd2 = chamfer_metrics(out["fine"], batch["complete"])
            fs = f_score(out["fine"][:1], batch["complete"][:1], tau=0.05)
            cd_vals.append(cd1)
            fs_vals.append(fs)
    print(f"测试 CD-L1(x1e4)={sum(cd_vals)/len(cd_vals)*1e4:.2f}  "
          f"F@0.05={sum(fs_vals)/len(fs_vals):.3f}")
    print("SMOKE TEST PASSED")


if __name__ == "__main__":
    main()
