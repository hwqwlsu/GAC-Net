# GAC-Net：图像引导的稀疏点云补全

Geometry-Anchored Cross-modal network for **image-guided sparse point cloud completion**。

输入：单视角稀疏/部分点云 + 该视角 RGB 图像；输出：完整稠密点云（默认 16384 点）。

## 1. 方法

```
部分点云 ─► PointNet++ (FPS+KNN, 两层SA) ─► 点 token (512×128)
                                                  │
RGB图像 ─► ResNet18(layer3, 14×14 patch) ─► 图像 token ─► GACA 几何锚定跨模态注意力
(相机 K,w2c 把点投影到图像，注意力 logits 叠加高斯位置偏置)        │
                                                  ▼
                          coarse seeds (256) ─ Transformer 解码
                                                  ▼
                          雪片分裂 ×8 ─► 2048 ─ 雪片分裂 ×8 ─► 16384 完整点云
```

- **GACA**（`pcic/models/fusion.py`）：点作 Query、图像 patch 作 Key/Value；投影坐标提供显式几何先验。
- **由粗到细解码器**（`pcic/models/decoder.py`）：seed 与点/图像 token 交互后两级分裂加密。
- **损失**（`pcic/losses.py`）：coarse/fine 对称 Chamfer-L1 + 视角一致性损失（预测点软投影轮廓/深度与 RGB 视图对齐）。
- **指标**（`pcic/metrics.py`）：CD-L1、CD-L2（×1e4）、F-Score@0.01/0.02。

纯 PyTorch 实现 FPS/KNN，**不需要编译 pointnet2_ops**，Windows/Linux 均可运行。

## 2. 快速验证（不下载数据）

```bash
pip install torch torchvision numpy tqdm
python smoke_test.py
```

合成数据仅用于验证代码正确性（前向形状、反传、loss 下降、指标计算），
**不得作为论文结果**。

## 3. 真实数据准备（ShapeNet55 / PCN 协议）

图像引导实验的关键是 **partial 扫描、RGB、相机参数必须来自同一台相机**，
因此推荐用渲染脚本从 ShapeNet 网格一次性生成三者，而不要直接用 PCN 发布的
partial（其相机位姿未知，无法对齐 RGB）。

### 3.1 用渲染脚本生成对齐数据（推荐）

下载 [ShapeNetCore.v2](https://shapenet.org/) 网格，目录形如
`<root>/<synset>/<model>/models/model_normalized.obj`。
Linux 服务器安装渲染依赖后直接运行：

```bash
pip install trimesh pyrender pygltflib Pillow
sudo apt-get install -y libegl1 libgl1 libglib2.0-0   # EGL 无头渲染系统库

# 先用 3 个模型验证环境
PYOPENGL_PLATFORM=egl python tools/render_shapenet.py \
    --models_dir /data/ShapeNetCore.v2 --out data/shapenet55 \
    --categories 03001627 --limit 3 --workers 1 --save_depth

# 检查 partial↔RGB↔相机是否对齐（点召回应 >0.95）
python tools/verify_alignment.py --root data/shapenet55 --split test -n 50 --dump check.png

# 全量：官方 PCN 划分（每行 <synset>/<model>），8 进程
PYOPENGL_PLATFORM=egl python tools/render_shapenet.py \
    --models_dir /data/ShapeNetCore.v2 --splits_dir assets/pcn_splits \
    --out data/shapenet55 --workers 16 --save_depth
```

每个模型同一台相机产出：RGB（224×224，黑背景）、深度反投影 partial（8192 点，
含轻微深度噪声）、表面采样 complete（16384 点）、相机 K/w2c（OpenCV 约定，
与 GACA 投影一致）、可选深度图。train 1 个随机视角，test 8 个等间隔视角；
中断后续跑自动跳过已完成样本；失败模型记入 `render_failures.txt`。
不给 `--splits_dir` 时按模型 id 哈希 85/5/10 划分。
ShapeNet 原始模型为 z-up，脚本默认旋转到 y-up；若你的数据已 y-up 用 `--up_axis y`。

产物布局：

```
data/shapenet55/
  pcd/<split>/partial/<synset>/<model>__v<view>.npy
  pcd/<split>/complete/<synset>/<model>.npy
  renders/<synset>_<model>__v<view>.png
  cams/<synset>_<model>__v<view>.json
  depth/<synset>_<model>__v<view>.npy        # --save_depth 时
  splits/{train,val,test}.txt
```

渲染产物已在规范坐标系（中心归零、最大坐标 ±0.45），配置中保持
`"pre_normalized": true`，加载时不会二次归一化。

### 3.2 纯点云模式（baseline 复现）

若只使用 PoinTr/PCN 发布的 `.pcd/.npy` 点云（无 RGB、无相机），把文件按
`pcd/<split>/{partial,complete}/<rel>` 放好，配置设 `"point_only": true,
"pre_normalized": false`，加载器自动按包围盒归一化；此时几何偏置与视角损失关闭，
用于公平复现纯点云 baseline。

## 4. 训练与评估

```bash
# 小规模先跑通（6 类合成，2048 输出点，几分钟）
python train.py --config configs/smoke.json

# 单类环境验证：只渲染 chair、正式输出点数 16384，验证 GACA+视角损失+全尺寸解码器
# （8GB 显存用 batch 4；合成数据仅用于验证，不得作为论文结果）
python train.py --config configs/chair_smoke.json

# 正式实验（改 default.json 里 data_root / batch_size）
python train.py --config configs/default.json

# 消融：无图像分支（model.use_image=false，完全移除图像编码器/GACA/投影层；
# 与 default.json 唯一差别即此，数据端 point_only=true 使 K/w2c 置零、视角损失关闭）
python train.py --config configs/point_only.json

# 其余消融变体（均由 default.json 单变量派生，均已做前向/损失冒烟）：
#   ablation_no_anchor.json  关闭几何锚定（GACA 退化为普通跨模态注意力）
#   ablation_no_view.json    w_view=0
#   ablation_sil_only.json   视角损失仅轮廓项（view_depth_weight=0）
#   ablation_concat.json     早期拼接融合替代 GACA
#   ablation_one_stage.json  单级分裂 up=[64]
python train.py --config configs/ablation_no_anchor.json

# 逐类别在线评估，输出 test_metrics.json
python evaluate.py --ckpt experiments/gacnet_shapenet55/best_model.pth

# 或导出预测点云，与所有外部 baseline 一起统一评分
python predict.py --ckpt experiments/gacnet_shapenet55/best_model.pth \
    --out predictions/gacnet --split test
```

单卡 RTX 4090 可运行（batch 16、**fp32**、16384 输出点，分块 CD 控制显存）。
注意 AMP 在本模型上不可用：16384 点的 cdist 与投影 splat 在 fp16 下会产生
inf 梯度（实测梯度范数 nan / 1e7，训练发散），配置统一 `amp: false`。
正式结果请跑 **3 个随机种子**，报均值±标准差。

## 5. 外部 baseline 对接（SnowflakeNet / PoinTr / AdaPoinTr / SeedFormer 等）

公平比较原则：所有方法在**同一份 partial 扫描、同一份 complete GT、同一归一化
空间**中训练和测试，并使用本工程的统一评估器评分（各仓库自带评估脚本的点数、
归一化口径不同，不能直接引用其输出数字）。

```bash
# (1) 把渲染数据导出为 PCN 布局（ASCII PCD + 各 split 列表）
python tools/baselines/export_pcn.py \
    --root data/shapenet55 --out external_data/PCN

# (2) 在外部仓库中训练/测试（模板见 tools/baselines/run_snowflakenet.sh、
#     run_pointr.sh；数据软链接到其 data/PCN；关闭仓库自带归一化/缩放，
#     使用其 PCN 数据模式，partial 点数与本工程一致 2048）
#     注意：AdaPoinTr/SeedFormer/GRNet 同样消费 PCN 布局，复用同一份导出。

# (3) 收集外部仓库预测结果（自动识别 .npy/.pcd/.xyz、类别子目录或拍平命名，
#     fine/coarse 同名时优先 fine），并报告与官方 split 的覆盖率
python tools/baselines/collect_predictions.py \
    --src ../SnowflakeNet/result --method snowflakenet \
    --split_file data/shapenet55/splits/test.txt

# (4) 所有方法（含 predict.py 导出的 gacnet）统一评分：
#     results/comparison.csv + results/prediction_metrics/<method>.json
python tools/eval_predictions.py --data_root data/shapenet55

# (5) 显著性：ours vs 每个 baseline 逐样本配对 t 检验（Holm 校正）
python tools/significance.py --ref gacnet --data_root data/shapenet55
```

外部仓库的预测目录/命令行随版本变化，`run_*.sh` 中已用 `[CHECK]` 标出需要
对照其当前 README 核对的步骤；收集器覆盖率不是 1.0 时先修 id 映射再评估，
不要在缺样本情况下出论文表。论文数值只取自 `results/comparison.csv`。

## 6. 论文实验计划

| 实验 | 设置 |
|---|---|
| 主对比 | PCN 8 类 + ShapeNet55；CD-L1/CD-L2（×1e4）、F-Score@1% |
| 点云 baseline | FoldingNet, PCN, TopNet, GRNet, SnowflakeNet, PoinTr, AdaPoinTr, SeedFormer, AnchorFormer（优先用其开源代码在同一划分复跑，其次引用论文数值并注明） |
| RGB 对照 | 单视图重建方法（Pixel2Point、Pix2Vox 等）作为"仅图像"参照 |
| 消融 | 去图像分支 / 拼接 vs 跨模态注意力 vs GACA / 去视角一致性损失 / 解码器分裂级数 / 视角数 |
| 鲁棒性 | 输入稀疏度 256/512/1024/2048/4096；遮挡率；图像模糊（真实加扰） |
| 统计 | 3 seed 均值±标准差，必要时配对 t 检验 |

所有 baseline 与数值必须能由开源代码或原论文表格核实，禁止虚构对比方法。
