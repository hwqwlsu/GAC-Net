"""把本工程渲染的数据导出为 PCN 布局，供外部补全仓库使用。

SnowflakeNet / PoinTr(PCN 模式) / AdaPoinTr / SeedFormer / GRNet / FoldingNet
都能读取 PCN 目录约定。为保证公平比较：
  - partial 使用与 GAC-Net 完全相同的单视角深度反投影扫描；
  - complete 每个模型一份（多视角共享）；
  - 坐标已归一化（±0.45），导出不再变换；外部仓库若有"归一化"开关请关闭。

输出：
    <out>/
      train.txt / val.txt / test.txt            # 每行 <synset>/<model>[__vV]
      <split>/partial/<synset>/<model>__vV.pcd
      <split>/complete/<synset>/<model>.pcd

用法：
    python tools/baselines/export_pcn.py \
        --root data/shapenet55 --out external_data/PCN
    # 只导出测试集：
    python tools/baselines/export_pcn.py --root data/shapenet55 \
        --out external_data/PCN --splits test
"""
import argparse
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from io_pcd import write_pcd  # noqa: E402


def read_split(root, split):
    p = os.path.join(root, "splits", f"{split}.txt")
    if not os.path.exists(p):
        raise FileNotFoundError(f"缺少 {p}，请先运行渲染脚本")
    with open(p, "r", encoding="utf-8") as f:
        return [ln.strip().replace("\\", "/") for ln in f if ln.strip()]


def strip_view(stem):
    base = stem[:-4] if stem.endswith(".npy") else stem
    if "__v" in base:
        base = base.split("__v")[0]
    return base


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default="data/shapenet55")
    ap.add_argument("--out", default="external_data/PCN")
    ap.add_argument("--splits", nargs="+", default=["train", "val", "test"])
    ap.add_argument("--ext", choices=["pcd", "npy"], default="pcd")
    args = ap.parse_args()

    stats = {}
    for split in args.splits:
        entries = read_split(args.root, split)
        list_lines = []
        done_complete = set()
        n_part = 0
        for entry in entries:
            syn, fn = entry.split("/", 1)
            stem = fn[:-4] if fn.endswith(".npy") else fn
            model_stem = strip_view(stem)

            part_src = os.path.join(
                args.root, "pcd", split, "partial", syn, fn)
            comp_id = f"{syn}/{model_stem}"
            comp_src = os.path.join(
                args.root, "pcd", split, "complete", syn, model_stem + ".npy")
            if not os.path.exists(part_src):
                print(f"[warn] 缺少 partial，跳过: {part_src}")
                continue
            if not os.path.exists(comp_src):
                print(f"[warn] 缺少 complete，跳过: {comp_src}")
                continue

            part_dst = os.path.join(
                args.out, split, "partial", syn, stem + "." + args.ext)
            comp_dst = os.path.join(
                args.out, split, "complete", syn, model_stem + "." + args.ext)

            pts = np.load(part_src).astype(np.float32)
            if args.ext == "pcd":
                write_pcd(part_dst, pts)
                if comp_id not in done_complete:
                    write_pcd(comp_dst, np.load(comp_src).astype(np.float32))
                    done_complete.add(comp_id)
            else:
                os.makedirs(os.path.dirname(part_dst), exist_ok=True)
                np.save(part_dst, pts)
                if comp_id not in done_complete:
                    os.makedirs(os.path.dirname(comp_dst), exist_ok=True)
                    np.save(comp_dst, np.load(comp_src).astype(np.float32))
                    done_complete.add(comp_id)

            list_lines.append(f"{syn}/{stem}")
            n_part += 1

        # 列表同时写到根目录（SnowflakeNet 约定）与 split 目录内（其他仓库约定）
        list_text = "\n".join(list_lines) + "\n"
        for p in (os.path.join(args.out, f"{split}.txt"),
                  os.path.join(args.out, split, f"{split}.txt")):
            os.makedirs(os.path.dirname(p), exist_ok=True)
            with open(p, "w", encoding="utf-8") as f:
                f.write(list_text)
        stats[split] = {"partial": n_part, "complete": len(done_complete)}

    print("[done] 导出统计：")
    for k, v in stats.items():
        print(f"  {k}: {v['partial']} partial, {v['complete']} complete -> {args.out}")


if __name__ == "__main__":
    main()
