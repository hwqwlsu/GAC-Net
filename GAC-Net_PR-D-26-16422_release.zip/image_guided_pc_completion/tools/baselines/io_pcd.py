"""ASCII PCD / XYZ / NPY 读写（无第三方点云库依赖）。

供 baseline 数据导出与预测结果收集使用：外部点云补全仓库
（SnowflakeNet / PoinTr / AdaPoinTr / SeedFormer / GRNet 等）
普遍以 ASCII PCD 交换 PCN 布局数据。
"""
import os

import numpy as np

PCD_HEADER = """# .PCD v0.7 - Point Cloud Data file format
VERSION 0.7
FIELDS x y z
SIZE 4 4 4
TYPE F F F
COUNT 1 1 1
WIDTH {n}
HEIGHT 1
VIEWPOINT 0 0 0 1 0 0 0
POINTS {n}
DATA ascii
"""


def write_pcd(path, points):
    """points: (N,3) float -> ASCII PCD v0.7。"""
    pts = np.asarray(points, dtype=np.float32)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="ascii", newline="\n") as f:
        f.write(PCD_HEADER.format(n=len(pts)))
        for p in pts:
            f.write(f"{p[0]:.6f} {p[1]:.6f} {p[2]:.6f}\n")


def read_pcd(path):
    """读取 ASCII/binary PCD 的 xyz（binary 仅支持 FLOAT32 单字段 xyz）。"""
    with open(path, "rb") as f:
        header_lines = []
        while True:
            line = f.readline()
            header_lines.append(line)
            if line.strip().startswith(b"DATA"):
                data_type = line.split()[1].strip().decode()
                break
        n = 0
        for line in header_lines:
            if line.startswith(b"POINTS"):
                n = int(line.split()[1])
        if data_type == "ascii":
            pts = np.loadtxt(f, dtype=np.float32, ndmin=2)
        elif data_type == "binary":
            raw = f.read()
            pts = np.frombuffer(raw, dtype=np.float32).reshape(n, -1)
        else:
            raise ValueError(f"不支持的 PCD DATA 类型: {data_type}")
    return pts[:, :3].astype(np.float32)


def load_points_any(path):
    if path.endswith(".npy"):
        return np.load(path).astype(np.float32)
    if path.endswith(".pcd"):
        return read_pcd(path)
    if path.endswith((".xyz", ".txt")):
        return np.loadtxt(path, dtype=np.float32, ndmin=2)[:, :3]
    raise ValueError(f"不支持的点云格式: {path}")
