#!/usr/bin/env bash
# SnowflakeNet (https://github.com/AllenXiangX/SnowflakeNet) 对接模板。
# 目的：让 SnowflakeNet 在与 GAC-Net 完全相同的 partial/GT/归一化上训练与测试，
# 预测结果交回本工程统一评估，避免各仓库自带评估器的口径差异。
#
# 仓库的命令行参数随版本可能变化；带 [CHECK] 的步骤请以其当前 README 为准核对。
set -e

# ===== 按实际路径修改 =====
REPO_DIR=${REPO_DIR:-"../SnowflakeNet"}
PCN_DATA=${PCN_DATA:-"$(pwd)/external_data/PCN"}   # export_pcn.py 的输出
SPLIT=${SPLIT:-"test"}
# ==========================

cd "$REPO_DIR"

# 1) 环境（需要能编译 pointnet2_ops / emd 等 CUDA 扩展；torch 版本与其 requirements 对齐）
#    pip install -r requirements.txt
#    cd models/pointnet2_ops && pip install -e .

# 2) 数据接入：仓库默认从 ../data/PCN 读取，做软链接即可
mkdir -p data
ln -sfn "$PCN_DATA" data/PCN

# 3) 训练 [CHECK：以仓库 README 的训练命令为准，常见写法如下]
# python main.py --exp_name snowflakenet_pcn --epochs 200

# 4) 测试，输出预测点云（确认输出目录，一般在 log/.../result 或 data/PCN/test/result 下）
# python test_snowflakenet.py --ckpts log/snowflakenet_pcn/best_model.pth --catego all

# 5) 回到本工程收集并统一评估
cd -
python tools/baselines/collect_predictions.py \
    --src "$REPO_DIR/log/snowflakenet_pcn/result" \
    --method snowflakenet \
    --split_file "data/shapenet55/splits/${SPLIT}.txt" \
    --ext auto --id_mode auto

python tools/eval_predictions.py --split "$SPLIT"
