#!/usr/bin/env bash
# PoinTr (https://github.com/yuxumin/PoinTr) 对接模板（PCN 数据模式）。
# 要点：使用 PCN 布局数据（与 GAC-Net 同一份扫描），不要用其 ShapeNet55 模式
# （该模式在加载时由 complete 现场生成 partial，partial 分布与本实验不一致）。
#
# 仓库参数随版本变化；带 [CHECK] 的步骤以其当前 README 为准。
set -e

# ===== 按实际路径修改 =====
REPO_DIR=${REPO_DIR:-"../PoinTr"}
PCN_DATA=${PCN_DATA:-"$(pwd)/external_data/PCN"}
EXP=${EXP:-"PoinTr_PCN"}
SPLIT=${SPLIT:-"test"}
# ==========================

cd "$REPO_DIR"

# 1) 环境：PointNet2 扩展按其 install.sh 编译；torch/CUDA 与 requirements 对齐
#    bash install.sh

# 2) 数据软链接
mkdir -p data
ln -sfn "$PCN_DATA" data/PCN

# 3) 训练（PCN 配置；[CHECK] 脚本名以仓库当前版本为准）
# bash train.sh --config configs/PCN_models/PoinTr.yaml --exp_name "$EXP"

# 4) 测试（输出 .npy 预测，目录通常为 example/<exp>；确认后回填 RESULT_DIR）
# bash test.sh --config configs/PCN_models/PoinTr.yaml \
#     --ckpts experiments/"$EXP"/ckpt-best.pth --exp_name "${EXP}_test"
RESULT_DIR=${RESULT_DIR:-"example/${EXP}_test"}

cd -
python tools/baselines/collect_predictions.py \
    --src "$REPO_DIR/$RESULT_DIR" \
    --method pointr \
    --split_file "data/shapenet55/splits/${SPLIT}.txt" \
    --ext auto --id_mode auto

python tools/eval_predictions.py --split "$SPLIT"
