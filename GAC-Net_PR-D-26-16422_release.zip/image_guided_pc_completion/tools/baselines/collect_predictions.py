"""把外部补全仓库的预测结果收集到统一目录 predictions/<method>/。

外部仓库输出格式各不相同（.npy / ASCII PCD / .xyz，目录层级不一），
本脚本递归扫描后按"规范 id"归位：
    <out>/<method>/<synset>/<model>__v<view>.npy
规范 id 与 splits/<split>.txt 条目一致，随后由 tools/eval_predictions.py 统一评分。

用法：
    # SnowflakeNet（输出 .pcd，常见于 result/ 目录，保留类别子目录）
    python tools/baselines/collect_predictions.py \
        --src ../SnowflakeNet/result --method snowflakenet \
        --split_file data/shapenet55/splits/test.txt --ext pcd

    # PoinTr（输出 .npy，文件名可能被拍平为 03001627_xxx__v0.npy）
    python tools/baselines/collect_predictions.py \
        --src ../PoinTr/example --method pointr \
        --split_file data/shapenet55/splits/test.txt --ext npy --id_mode auto

    # 任意目录，扩展名自动识别
    python tools/baselines/collect_predictions.py --src DIR --method foo \
        --split_file data/shapenet55/splits/test.txt
"""
import argparse
import os
import re
import shutil
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from io_pcd import load_points_any  # noqa: E402

WRAPPER_DIRS = {"result", "results", "pred", "preds", "prediction",
                "predictions", "output", "outputs", "fine", "pcd", "test"}
TAIL_SUFFIXES = re.compile(
    r"(_(pred|fine|coarse|prediction|predictions|output|outputs|result|recon|comp|complete))+$",
    re.IGNORECASE)
SYN_RE = re.compile(r"^\d{8}")


def canonize(rel_noext, mode):
    """相对路径（无扩展名）-> 规范 id <synset>/<model>[__vV]。"""
    parts = [p for p in rel_noext.replace("\\", "/").split("/")]
    # 去掉常见包装目录
    while parts and parts[0] in WRAPPER_DIRS:
        parts = parts[1:]
    stem = parts[-1]
    stem = TAIL_SUFFIXES.sub("", stem)

    if mode == "path":
        rest = parts[:-1]
        syn = next((p for p in rest if SYN_RE.match(p)), None)
        if syn is None and SYN_RE.match(stem):
            # 拍平命名：03001627_model__v0
            m = re.match(r"^(\d{8})_(.+)$", stem)
            if m:
                return f"{m.group(1)}/{m.group(2)}"
        if syn is None:
            return None
        return f"{syn}/{stem}"

    if mode == "flat":
        m = re.match(r"^(\d{8})_(.+)$", stem)
        return f"{m.group(1)}/{m.group(2)}" if m else None

    # auto：优先路径中的 synset 目录，其次拍平命名
    if len(parts) >= 2 and SYN_RE.match(parts[-2]):
        return f"{parts[-2]}/{stem}"
    m = re.match(r"^(\d{8})_(.+)$", stem)
    if m:
        return f"{m.group(1)}/{m.group(2)}"
    return None


def scan(src, exts):
    for dp, _, files in os.walk(src):
        for fn in files:
            if os.path.splitext(fn)[1].lower().lstrip(".") in exts:
                yield os.path.join(dp, fn)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True, help="外部仓库预测结果目录")
    ap.add_argument("--method", required=True, help="方法名（输出子目录名）")
    ap.add_argument("--out", default="predictions")
    ap.add_argument("--split_file", default="data/shapenet55/splits/test.txt")
    ap.add_argument("--ext", default="auto",
                    choices=["auto", "npy", "pcd", "xyz", "txt"])
    ap.add_argument("--id_mode", default="auto", choices=["auto", "path", "flat"])
    ap.add_argument("--move", action="store_true", help="移动而非复制")
    ap.add_argument("--strict", action="store_true",
                    help="与 split 不一致（缺样/多样）时以非零码退出")
    args = ap.parse_args()

    exts = (["npy", "pcd", "xyz", "txt"] if args.ext == "auto"
            else [args.ext])
    expected = None
    if os.path.exists(args.split_file):
        with open(args.split_file, "r", errors="ignore") as f:
            expected = set(
                ln.strip().replace("\\", "/")[:-4]
                if ln.strip().endswith(".npy") else ln.strip().replace("\\", "/")
                for ln in f if ln.strip())

    dest_root = os.path.join(args.out, args.method)
    os.makedirs(dest_root, exist_ok=True)

    found = {}
    skipped_bad = []
    for path in scan(args.src, exts):
        rel = os.path.relpath(path, args.src)
        rel_noext = os.path.splitext(rel)[0]
        cid = canonize(rel_noext, args.id_mode)
        if cid is None:
            skipped_bad.append(rel)
            continue
        # 同一 id 多个文件时：fine > 普通 > coarse（雪片类仓库会同时存两级）
        if cid in found:
            old, new = found[cid].lower(), rel.lower()
            old_score = 0 if "fine" in old else 2 if "coarse" in old else 1
            new_score = 0 if "fine" in new else 2 if "coarse" in new else 1
            if new_score >= old_score:
                continue
        found[cid] = path

    n_written = 0
    for cid, src_path in sorted(found.items()):
        if expected is not None and cid not in expected:
            continue
        dst = os.path.join(dest_root, cid + ".npy")
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        if src_path.endswith(".npy"):
            (shutil.move if args.move else shutil.copyfile)(src_path, dst)
        else:
            pts = load_points_any(src_path)
            np.save(dst, pts.astype(np.float32))
        n_written += 1

    print(f"方法 [{args.method}] 收集 {n_written} 个预测 -> {dest_root}")
    if skipped_bad:
        print(f"[warn] {len(skipped_bad)} 个文件无法解析 id，示例: {skipped_bad[:5]}")
    if expected is not None:
        got = set(found) & expected
        missing = sorted(expected - got)
        extra = sorted(set(found) - expected)
        if missing:
            print(f"[warn] 缺少 {len(missing)} 个，示例: {missing[:5]}")
        if extra:
            print(f"[warn] split 外 {len(extra)} 个，示例: {extra[:5]}")
        print(f"覆盖率: {len(got)}/{len(expected)} = {len(got)/len(expected):.3f}")
        if args.strict and missing:
            sys.exit(1)


if __name__ == "__main__":
    main()
