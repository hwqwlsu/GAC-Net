"""渲染数据对齐质量校验（不需要 pyrender，只用 numpy + Pillow）。

检查 tools/render_shapenet.py 产物中"部分点云 ↔ RGB 轮廓/深度 ↔ 相机参数"是否对齐：
  1) 点云投影到图像后，落在物体轮廓内的比例（点召回，应 >0.95）；
  2) 投影点覆盖的轮廓像素比例（扫描完整性，受扫描分辨率影响，一般 >0.8）；
  3) 投影点深度与渲染深度图的中位残差（应接近 depth_noise 量级）。

用法：
    python tools/verify_alignment.py --root data/shapenet55 --split test -n 100
    python tools/verify_alignment.py --root data/shapenet55 --dump check.png
"""
import argparse
import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from camera_utils import project_points  # noqa: E402


def load_sample(root, split, entry):
    """entry 例：03001627/abc__v0.npy"""
    partial = np.load(os.path.join(root, "pcd", split, "partial", entry))
    stem = os.path.splitext(entry.replace("\\", "_").replace("/", "_"))[0]
    cam_path = os.path.join(root, "cams", stem + ".json")
    img_path = os.path.join(root, "renders", stem + ".png")
    depth_path = os.path.join(root, "depth", stem + ".npy")
    with open(cam_path, "r", encoding="utf-8") as f:
        cam = json.load(f)
    from PIL import Image
    rgb = np.asarray(Image.open(img_path).convert("RGB"), dtype=np.float32) / 255.0
    mask = rgb.mean(-1) > 0.02
    depth = np.load(depth_path) if os.path.exists(depth_path) else None
    return partial, np.array(cam["K"]), np.array(cam["w2c"]), rgb, mask, depth, stem


def check_one(partial, K, w2c, mask, depth=None):
    H, W = mask.shape
    u, v, z = project_points(partial, K, w2c)
    in_img = (u >= 0) & (u < W) & (v >= 0) & (v < H) & (z > 0)
    pts_uv = np.stack([u[in_img], v[in_img]], axis=1)
    pts_uv = np.round(pts_uv).astype(int).clip([0, 0], [W - 1, H - 1])
    ui, vi = pts_uv.T
    hit = mask[vi, ui]

    # 1) 点落在轮廓内的比例（忽略扫描边缘像素误差，容差 2px）
    covered = np.zeros_like(mask)
    covered[vi, ui] = True
    pad = np.pad(mask, 2, mode="edge")
    neighborhood = np.zeros_like(mask)
    for du in range(-2, 3):
        for dv in range(-2, 3):
            neighborhood |= pad[2 + dv:2 + dv + H, 2 + du:2 + du + W]
    point_recall = float((hit | neighborhood[vi, ui]).mean())

    # 2) 轮廓覆盖（2px 膨胀点覆盖）
    cover_dil = np.zeros_like(mask)
    for du in (-1, 0, 1):
        for dv in (-1, 0, 1):
            cover_dil[np.clip(vi + dv, 0, H - 1), np.clip(ui + du, 0, W - 1)] = True
    mask_coverage = float((mask & cover_dil).sum() / max(mask.sum(), 1))

    # 3) 深度残差
    depth_resid = None
    if depth is not None:
        d_ref = depth[vi, ui]
        good = d_ref > 0
        if good.any():
            depth_resid = float(np.median(np.abs(z[in_img][good] - d_ref[good])))

    return {
        "n_points": int(len(partial)),
        "in_image_ratio": float(in_img.mean()),
        "point_recall": point_recall,
        "mask_coverage": mask_coverage,
        "depth_resid_median": depth_resid,
        "proj": (u, v, in_img),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--split", default="test")
    ap.add_argument("-n", "--num", type=int, default=50)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--dump", default="")
    args = ap.parse_args()

    part_dir = os.path.join(args.root, "pcd", args.split, "partial")
    entries = []
    for dp, _, files in os.walk(part_dir):
        for fn in files:
            if fn.endswith(".npy"):
                entries.append(os.path.relpath(os.path.join(dp, fn), part_dir)
                               .replace(os.sep, "/"))
    entries.sort()
    rng = np.random.RandomState(args.seed)
    if len(entries) > args.num:
        entries = list(rng.choice(entries, args.num, replace=False))

    rows, dump_data = [], []
    for e in entries:
        partial, K, w2c, rgb, mask, depth, stem = load_sample(args.root, args.split, e)
        r = check_one(partial, K, w2c, mask, depth)
        r["id"] = stem
        rows.append(r)
        if args.dump and len(dump_data) < 8:
            dump_data.append((rgb, r["proj"], mask, stem))

    def avg(key):
        vals = [r[key] for r in rows if r[key] is not None]
        return float(np.mean(vals)) if vals else float("nan")

    print(f"样本数: {len(rows)}")
    print(f"点在画面内比例      : {avg('in_image_ratio'):.4f}  (期望≈1)")
    print(f"点→轮廓召回 (2px)   : {avg('point_recall'):.4f}  (期望>0.95)")
    print(f"轮廓覆盖 (扫描完整度): {avg('mask_coverage'):.4f}  (期望>0.8)")
    print(f"深度中位残差        : {avg('depth_resid_median'):.5f}  (无深度图则 nan)")

    bad = [r["id"] for r in rows
           if r["point_recall"] < 0.9 or r["in_image_ratio"] < 0.98]
    if bad:
        print(f"[警告] {len(bad)} 个样本对齐异常，前 10 个: {bad[:10]}")

    if args.dump and dump_data:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig, axes = plt.subplots(2, len(dump_data), figsize=(3 * len(dump_data), 6))
        for j, (rgb, (u, v, in_img), mask, stem) in enumerate(dump_data):
            axes[0, j].imshow(rgb)
            sel = in_img
            axes[0, j].scatter(u[sel], v[sel], s=0.2, c="lime", alpha=0.3)
            axes[0, j].set_title(stem[:22], fontsize=7)
            axes[0, j].axis("off")
            axes[1, j].imshow(mask, cmap="gray")
            axes[1, j].scatter(u[sel], v[sel], s=0.2, c="red", alpha=0.3)
            axes[1, j].axis("off")
        plt.tight_layout()
        plt.savefig(args.dump, dpi=130)
        print(f"[saved] {args.dump}")


if __name__ == "__main__":
    main()
