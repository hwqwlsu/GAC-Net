"""跨方法统一评估器：所有方法的预测点云用同一份 GT、同一套指标评分。

预测目录：predictions/<method>/<synset>/<model>__vV.npy
真值目径：<data_root>/pcd/<split>/complete/<synset>/<model>.npy（多视角共享）

指标与 pcic/metrics.py 完全一致：CD-L1、CD-L2（×1e4）、F-Score@0.01/0.02。
输出 results/prediction_metrics/<method>.json 与 results/comparison.csv。

用法：
    python tools/eval_predictions.py --data_root data/shapenet55
    python tools/eval_predictions.py --data_root data/shapenet55 \
        --methods gacnet snowflakenet pointr --align center
"""
import argparse
import csv
import json
import os
import sys

import numpy as np
import torch

PROJ_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, PROJ_ROOT)
from pcic.metrics import evaluate_sample  # noqa: E402

SYN2NAME = {
    "02691156": "airplane", "02933112": "cabinet", "02958343": "car",
    "03001627": "chair", "03636649": "lamp", "04256520": "sofa",
    "04379243": "table", "04530566": "watercraft",
}
METRIC_KEYS = ["CD_L1_x1e4", "CD_L2_x1e4", "Fscore@0.01", "Fscore@0.02"]


def split_view(cid):
    return cid.split("__v")[0] if "__v" in cid else cid


def discover_methods(pred_root, only):
    if only:
        return [m for m in only if os.path.isdir(os.path.join(pred_root, m))]
    return sorted(d for d in os.listdir(pred_root)
                  if os.path.isdir(os.path.join(pred_root, d)))


def iter_pred_files(method_dir):
    for dp, _, files in os.walk(method_dir):
        for fn in files:
            if fn.endswith(".npy"):
                rel = os.path.relpath(os.path.join(dp, fn), method_dir)
                cid = rel.replace("\\", "/")[:-4]
                yield cid, os.path.join(dp, fn)


def evaluate_method(method, pred_root, gt_root, split, align, device):
    method_dir = os.path.join(pred_root, method)
    per_cat = {}
    n_bad = 0
    for cid, path in sorted(iter_pred_files(method_dir)):
        syn = cid.split("/", 1)[0]
        gt_id = split_view(cid)
        gt_path = os.path.join(gt_root, split, "complete", gt_id + ".npy")
        if not os.path.exists(gt_path):
            n_bad += 1
            continue
        pred = np.load(path).astype(np.float32)
        gt = np.load(gt_path).astype(np.float32)
        if pred.ndim != 2 or pred.shape[1] != 3 or len(pred) < 8:
            n_bad += 1
            continue
        if align == "center":
            pred = pred - pred.mean(0) + gt.mean(0)
        with torch.no_grad():
            m = evaluate_sample(torch.from_numpy(pred).to(device),
                                torch.from_numpy(gt).to(device))
        m["n_points"] = int(len(pred))
        per_cat.setdefault(syn, []).append(m)

    report = {}
    all_rows = []
    for syn, rows in sorted(per_cat.items()):
        name = SYN2NAME.get(syn, syn)
        agg = {k: float(np.mean([r[k] for r in rows])) for k in METRIC_KEYS}
        agg["n"] = len(rows)
        agg["mean_points"] = float(np.mean([r["n_points"] for r in rows]))
        report[name] = agg
        all_rows.append((method, name, agg))
    if per_cat:
        cat_aggs = [agg for _, _, agg in all_rows]
        # 与 evaluate.py 一致：类别宏平均
        overall = {k: float(np.mean([r[k] for r in cat_aggs]))
                   for k in METRIC_KEYS}
        overall["n"] = sum(agg["n"] for _, _, agg in all_rows)
        overall["mean_points"] = float(np.mean(
            [agg["mean_points"] for _, _, agg in all_rows]))
        report["overall"] = overall
    if n_bad:
        print(f"[{method}] 警告：{n_bad} 个预测缺少 GT 或形状非法，已跳过")
    return report


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pred_root", default="predictions")
    ap.add_argument("--data_root", default="data/shapenet55")
    ap.add_argument("--split", default="test")
    ap.add_argument("--methods", nargs="*", default=None)
    ap.add_argument("--align", choices=["none", "center"], default="none",
                    help="center: 仅做质心对齐（诊断外部仓库重新居中点云的情况）")
    ap.add_argument("--out", default="results")
    args = ap.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    gt_root = os.path.join(args.data_root, "pcd")
    methods = discover_methods(args.pred_root, args.methods)
    if not methods:
        print(f"在 {args.pred_root} 下没有找到方法目录")
        return

    os.makedirs(os.path.join(args.out, "prediction_metrics"), exist_ok=True)
    all_reports = {}
    for method in methods:
        report = evaluate_method(method, args.pred_root, gt_root,
                                 args.split, args.align, device)
        all_reports[method] = report
        with open(os.path.join(args.out, "prediction_metrics", f"{method}.json"),
                  "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2, ensure_ascii=False)

    # 长表 CSV：method, category, 各指标
    csv_path = os.path.join(args.out, "comparison.csv")
    with open(csv_path, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["method", "category"] + METRIC_KEYS + ["n", "mean_points"])
        for method in methods:
            for cat, agg in all_reports[method].items():
                w.writerow([method, cat] + [f"{agg[k]:.4f}" for k in METRIC_KEYS]
                           + [agg["n"], f"{agg['mean_points']:.0f}"])

    # 控制台总表
    cats = []
    for r in all_reports.values():
        for c in r:
            if c not in cats:
                cats.append(c)
    header = f"{'method':<18}" + "".join(f"{c:>12}" for c in cats)
    print("\n=== CD-L1 (x1e4) ===")
    print(header)
    for method in methods:
        row = f"{method:<18}"
        for c in cats:
            v = all_reports[method].get(c, {}).get("CD_L1_x1e4")
            row += f"{v:>12.3f}" if v is not None else f"{'-':>12}"
        print(row)
    print("\n=== F-Score@0.01 ===")
    print(header)
    for method in methods:
        row = f"{method:<18}"
        for c in cats:
            v = all_reports[method].get(c, {}).get("Fscore@0.01")
            row += f"{v:>12.4f}" if v is not None else f"{'-':>12}"
        print(row)
    print(f"\n[saved] {csv_path} 与 {os.path.join(args.out, 'prediction_metrics')}")


if __name__ == "__main__":
    main()
