# -*- coding: utf-8 -*-
"""跨方法显著性检验：ours vs 每个 baseline 的逐样本配对 t 检验。

对 test split 上每个样本计算指标（默认 CD-L1×1e4），按样本 id 两两配对，
ours 与每个 baseline 做 scipy 配对 t 检验（双尾），并对多重比较做 Holm 校正。
逐样本配对（而非 3-seed 均值配对）检验的是"同一输入下两方法差异是否系统性"，
是补全论文的常规做法；3 seed 的均值±std 另由训练日志汇总。

用法：
  python tools/significance.py --ref gacnet --methods snowflakenet pointr egii
输出：results/significance.json + 控制台表格。
"""
import argparse
import json
import os
import sys

import numpy as np
import torch
from scipy import stats

PROJ_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, PROJ_ROOT)
from pcic.metrics import evaluate_sample  # noqa: E402

SYN2NAME = {
    "02691156": "airplane", "02933112": "cabinet", "02958343": "car",
    "03001627": "chair", "03636649": "lamp", "04256520": "sofa",
    "04379243": "table", "04530566": "watercraft",
}
KEY_OF = {"cd_l1": "CD_L1_x1e4", "cd_l2": "CD_L2_x1e4",
          "f1": "Fscore@0.01", "f2": "Fscore@0.02"}


def split_view(cid):
    return cid.split("__v")[0] if "__v" in cid else cid


def per_sample_metrics(method_dir, gt_root, split, key, device):
    """返回 {cid: metric}。"""
    out = {}
    for dp, _, files in os.walk(method_dir):
        for fn in sorted(files):
            if not fn.endswith(".npy"):
                continue
            rel = os.path.relpath(os.path.join(dp, fn), method_dir)
            cid = rel.replace("\\", "/")[:-4]
            gt_path = os.path.join(gt_root, split, "complete",
                                   split_view(cid) + ".npy")
            if not os.path.exists(gt_path):
                continue
            pred = np.load(os.path.join(dp, fn)).astype(np.float32)
            gt = np.load(gt_path).astype(np.float32)
            if pred.ndim != 2 or pred.shape[1] != 3 or len(pred) < 8:
                continue
            with torch.no_grad():
                m = evaluate_sample(torch.from_numpy(pred).to(device),
                                    torch.from_numpy(gt).to(device))
            out[cid] = float(m[key])
    return out


def holm_correction(pvals):
    """Holm-Bonferroni，输入 p 列表，返回校正后显著性阈值判定列表。"""
    order = np.argsort(pvals)
    m = len(pvals)
    adj = [None] * m
    running = 0.0
    for rank, idx in enumerate(order):
        running = max(running, pvals[idx] * (m - rank))
        adj[idx] = min(running, 1.0)
    return adj


def stars(p):
    return "***" if p < 1e-3 else "**" if p < 1e-2 else "*" if p < 0.05 else "n.s."


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pred_root", default="predictions")
    ap.add_argument("--data_root", default="data/shapenet55")
    ap.add_argument("--split", default="test")
    ap.add_argument("--ref", default="gacnet", help="参考方法（通常是 ours）")
    ap.add_argument("--methods", nargs="*", default=None,
                    help="默认 pred_root 下除 ref 外全部")
    ap.add_argument("--metric", choices=list(KEY_OF), default="cd_l1")
    ap.add_argument("--out", default="results/significance.json")
    args = ap.parse_args()

    key = KEY_OF[args.metric]
    gt_root = os.path.join(args.data_root, "pcd")
    device = "cuda" if torch.cuda.is_available() else "cpu"

    ref_map = per_sample_metrics(os.path.join(args.pred_root, args.ref),
                                 gt_root, args.split, key, device)
    if not ref_map:
        sys.exit(f"[ERR] ref 方法 {args.ref} 无可用预测")

    methods = args.methods or sorted(
        d for d in os.listdir(args.pred_root)
        if os.path.isdir(os.path.join(args.pred_root, d)) and d != args.ref)

    rows = []
    for meth in methods:
        cur = per_sample_metrics(os.path.join(args.pred_root, meth),
                                 gt_root, args.split, key, device)
        common = sorted(set(ref_map) & set(cur))
        if len(common) < 8:
            print(f"[WARN] {meth}: 共同样本仅 {len(common)}，跳过")
            continue
        # overall（全部样本合并）与逐类
        groups = {"overall": common}
        for cid in common:
            syn = cid.split("/", 1)[0]
            groups.setdefault(SYN2NAME.get(syn, syn), []).append(cid)
        for scope, ids in sorted(groups.items()):
            if len(ids) < 8:
                continue
            a = np.array([ref_map[c] for c in ids])   # ours
            b = np.array([cur[c] for c in ids])       # baseline
            t, p = stats.ttest_rel(a, b)
            rows.append({
                "baseline": meth, "scope": scope, "n": len(ids),
                "ref_mean": float(a.mean()), "base_mean": float(b.mean()),
                "mean_diff": float((a - b).mean()),
                "win_rate": float((a < b).mean()),  # 假设指标越小越好
                "t": float(t), "p": float(p),
            })

    # Holm 校正：按 scope 分组校正（overall 与每个类别各自族）
    by_scope = {}
    for r in rows:
        by_scope.setdefault(r["scope"], []).append(r)
    for scope, rs in by_scope.items():
        adj = holm_correction([r["p"] for r in rs])
        for r, pa in zip(rs, adj):
            r["p_holm"] = float(pa)
            r["sig"] = stars(pa)

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump({"ref": args.ref, "metric": key, "split": args.split,
                   "note": "paired t-test per sample; win_rate = frac(ref better); "
                           "p_holm = Holm-corrected per scope",
                   "rows": rows}, f, indent=2, ensure_ascii=False)

    print(f"\nref={args.ref}  metric={key}  (负 mean_diff 且 win_rate>0.5 = ours 更优)")
    print(f"{'baseline':<16}{'scope':<10}{'n':>5}{'Δmean':>10}"
          f"{'win':>7}{'p':>10}{'p_holm':>10}  sig")
    for r in rows:
        print(f"{r['baseline']:<16}{r['scope']:<10}{r['n']:>5}"
              f"{r['mean_diff']:>10.3f}{r['win_rate']:>7.3f}"
              f"{r['p']:>10.2e}{r['p_holm']:>10.2e}  {r['sig']}")
    print(f"[OK] -> {args.out}")


if __name__ == "__main__":
    main()
