"""相机数学工具（纯 numpy，不依赖 pyrender，可单独测试）。

约定：
  - 物体/世界坐标系：ShapeNet 归一化后的规范坐标，y 轴向上；
  - OpenCV 相机系：x 向右、y 向下、z 向前（看向目标）；
  - pyrender/OpenGL 相机系：x 向右、y 向上、z 向后。
网络（pcic/models/fusion.py）使用 OpenCV 约定的 K 与 w2c。
"""
import numpy as np


def normalize_mesh_vertices(vertices, target_radius=0.45):
    """与数据加载器 normalize_pc 一致的归一化：质心居中、最大坐标到 ±target_radius。

    返回 (new_vertices, transform_4x4)，transform_4x4 把原始顶点变到规范坐标。
    """
    center = (vertices.max(0) + vertices.min(0)) / 2.0
    v = vertices - center
    radius = np.abs(v).max()
    scale = target_radius / max(radius, 1e-8)
    v = v * scale
    T = np.eye(4, dtype=np.float32)
    T[:3, 3] = -center
    S = np.eye(4, dtype=np.float32)
    S[0, 0] = S[1, 1] = S[2, 2] = scale
    M = (S @ T).astype(np.float32)
    return v.astype(np.float32), M


def look_at_cv(eye, target=np.zeros(3), up_t=np.array([0.0, 1.0, 0.0])):
    """构造 OpenCV 约定的 w2c（物体系 -> 相机系）。

    Args:
        eye: (3,) 相机位置（物体坐标）
        target: (3,) 注视点
        up_t: 世界上方向（ShapeNet 用 y 轴向上）
    Returns:
        w2c: (4,4)
    """
    eye = np.asarray(eye, dtype=np.float64)
    target = np.asarray(target, dtype=np.float64)
    z = target - eye                       # 相机前向
    z = z / np.linalg.norm(z)
    x = np.cross(up_t, z)                  # 相机右向
    x = x / np.linalg.norm(x)
    y = np.cross(z, x)                     # 相机下向（OpenCV）
    R = np.stack([x, y, z], axis=0)
    t = -R @ eye
    w2c = np.eye(4, dtype=np.float32)
    w2c[:3, :3] = R
    w2c[:3, 3] = t
    return w2c


def cv_to_gl_pose(w2c):
    """OpenCV w2c -> pyrender 需要的 OpenGL c2w (4,4)。"""
    w2c = np.asarray(w2c, dtype=np.float64)
    R_cv, t_cv = w2c[:3, :3], w2c[:3, 3]
    eye = -R_cv.T @ t_cv
    x_cv = R_cv[0]
    y_cv = R_cv[1]
    z_cv = R_cv[2]
    c2w = np.eye(4, dtype=np.float32)
    c2w[:3, 0] = x_cv      # GL x
    c2w[:3, 1] = -y_cv     # GL y（向上）
    c2w[:3, 2] = -z_cv     # GL z（向后）
    c2w[:3, 3] = eye
    return c2w


def orbit_eye(azimuth, elevation, distance, up_t=np.array([0.0, 1.0, 0.0])):
    """绕 y 轴轨道相机位置。

    Args:
        azimuth: 方位角（弧度），0 时相机在 +x 方向
        elevation: 仰角（弧度）
        distance: 到原点距离
    """
    ce, se = np.cos(elevation), np.sin(elevation)
    ca, sa = np.cos(azimuth), np.sin(azimuth)
    eye = np.array([distance * ce * ca,
                    distance * se,
                    distance * ce * sa], dtype=np.float32)
    return eye


def fit_distance(obj_radius, fov_y_rad, fill=0.85):
    """保证物体最大投影不超过画面 fill 比例所需的相机距离。"""
    return float(obj_radius * (1.0 + 1.0 / (fill * np.tan(fov_y_rad / 2.0))))


def backproject_depth(depth, K, w2c, stride=1, max_points=None,
                      depth_noise=0.0, rng=None):
    """深度图反投影为物体坐标系点云。

    Args:
        depth: (H,W) 深度（相机 z，>0 为有效）
        K: (3,3)
        w2c: (4,4)
        stride: 像素步长（降采样）
        max_points: 最多保留点数（随机选）
        depth_noise: 加到相机 z 的高斯噪声标准差（规范坐标单位）
        rng: np.random.Generator/RandomState
    Returns:
        points: (M,3) 物体坐标
        pixels: (M,2) (u,v)
    """
    H, W = depth.shape
    fx, fy = K[0, 0], K[1, 1]
    cx, cy = K[0, 2], K[1, 2]
    vs, us = np.nonzero(depth > 0)
    if stride > 1:
        us, vs = us[::stride], vs[::stride]
    z = depth[vs, us].astype(np.float64)
    if depth_noise > 0 and rng is not None:
        z = z + rng.normal(0, depth_noise, size=z.shape)
        z = np.clip(z, 1e-3, None)
    x = (us - cx) * z / fx
    y = (vs - cy) * z / fy
    cam = np.stack([x, y, z], axis=1)  # OpenCV 相机坐标
    R = w2c[:3, :3]
    t = w2c[:3, 3]
    world = (cam - t) @ R             # = R^T (cam - t)
    if max_points is not None and len(world) > max_points:
        rng = rng or np.random
        sel = rng.choice(len(world), max_points, replace=False)
        world, us, vs = world[sel], us[sel], vs[sel]
    return world.astype(np.float32), np.stack([us, vs], axis=1)


def project_points(xyz, K, w2c):
    """物体坐标点投影到像素，供对齐校验使用。

    Returns:
        u, v, z（相机 z）
    """
    R = w2c[:3, :3]
    t = w2c[:3, 3]
    cam = xyz @ R.T + t
    z = cam[:, 2]
    u = cam[:, 0] * K[0, 0] / np.maximum(z, 1e-8) + K[0, 2]
    v = cam[:, 1] * K[1, 1] / np.maximum(z, 1e-8) + K[1, 2]
    return u, v, z
