"""从 ShapeNet 网格批量渲染图像引导补全训练数据。

同一台相机同时产出：
  - RGB 渲染图（renders/<synset>_<model>__v<view>.png）
  - 深度反投影的部分点云（pcd/<split>/partial/...），模拟单视角深度扫描
  - 稠密完整点云（pcd/<split>/complete/...），网格表面采样
  - 相机参数（cams/...json，OpenCV 约定 K/w2c，与网络 GACA 投影一致）
  - 可选深度图（depth/...npy），用于视角一致性损失的深度监督

典型用法（Linux 服务器，无头 EGL）：
    pip install trimesh pyrender pygltflib Pillow
    PYOPENGL_PLATFORM=egl python tools/render_shapenet.py \
        --models_dir /data/ShapeNetCore.v2 \
        --splits_dir  assets/pcn_splits \
        --out data/shapenet55 --workers 16

无官方划分文件时，自动按模型 id 哈希 85/5/10 划分 train/val/test。
已存在的样本默认跳过（中断续跑），--force 重跑。
"""
import argparse
import hashlib
import json
import os
import sys
import traceback

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from camera_utils import (  # noqa: E402
    normalize_mesh_vertices, look_at_cv, cv_to_gl_pose, orbit_eye,
    fit_distance, backproject_depth,
)

VERSION = "gac-render-v1"
# z-up -> y-up（ShapeNet 原始模型多为 z-up；若你的模型已 y-up，用 --up_axis y）
R_ZUP_TO_YUP = np.array([[1, 0, 0], [0, 0, 1], [0, -1, 0]], dtype=np.float32)


def stable_seed(*parts):
    h = hashlib.md5("|".join(str(p) for p in parts).encode()).hexdigest()
    return int(h[:8], 16)


# ----------------------------- 任务清单 -----------------------------

def read_split_file(path):
    ids = []
    with open(path, "r", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if line:
                ids.append(line)
    return ids


def discover_models(models_dir, categories):
    models = []
    for synset in sorted(os.listdir(models_dir)):
        d = os.path.join(models_dir, synset)
        if not os.path.isdir(d) or not synset.isdigit():
            continue
        if categories and synset not in categories:
            continue
        for model_id in sorted(os.listdir(d)):
            obj = os.path.join(d, model_id, "models", "model_normalized.obj")
            if os.path.exists(obj):
                models.append(f"{synset}/{model_id}")
    return models


def build_jobs(args):
    """返回 [(model_id, split, [view,...]), ...]。"""
    split_models = {}
    if args.splits_dir and os.path.isdir(args.splits_dir):
        for split in ("train", "val", "test"):
            for cand in (f"{split}.list", f"{split}.txt"):
                p = os.path.join(args.splits_dir, cand)
                if os.path.exists(p):
                    split_models[split] = read_split_file(p)
                    break
    if not split_models:
        all_models = discover_models(args.models_dir, set(args.categories or []))
        split_models = {"train": [], "val": [], "test": []}
        for mid in all_models:
            h = stable_seed("split", mid) % 100
            split_models["train" if h < 85 else "val" if h < 95 else "test"].append(mid)

    jobs = []
    for split, mids in split_models.items():
        n_views = {"train": args.views_train, "val": args.views_val,
                   "test": args.views_test}[split]
        for mid in mids:
            if "/" not in mid:  # 只有 model id 时无法确定类别
                continue
            synset = mid.split("/")[0]
            if args.categories and synset not in args.categories:
                continue
            jobs.append((mid, split, list(range(n_views))))
    return jobs


# ----------------------------- 每个样本 -----------------------------

def output_paths(out, split, synset, model, view):
    stem = f"{synset}_{model}__v{view}"
    rel_part = os.path.join(synset, f"{model}__v{view}.npy")
    rel_comp = os.path.join(synset, f"{model}.npy")
    return {
        "partial": os.path.join(out, "pcd", split, "partial", rel_part),
        "complete": os.path.join(out, "pcd", split, "complete", rel_comp),
        "image": os.path.join(out, "renders", stem + ".png"),
        "cam": os.path.join(out, "cams", stem + ".json"),
        "depth": os.path.join(out, "depth", stem + ".npy"),
        "split_entry": f"{synset}/{model}__v{view}.npy",
    }


def load_normalized_mesh(model_path, up_axis, tm):
    obj = tm.load(model_path, force="mesh", process=True)
    if isinstance(obj, tm.Scene):
        geoms = []
        for node_name in obj.graph.nodes_geometry:
            T, geom = obj[node_name]
            g = obj.geometry[geom].copy()
            g.apply_transform(T)
            geoms.append(g)
        obj = tm.util.concatenate(geoms)
    obj.remove_degenerate_faces()
    obj.remove_duplicate_faces()

    _, M = normalize_mesh_vertices(np.asarray(obj.vertices))
    obj.apply_transform(M)
    if up_axis == "z":
        obj.apply_transform(np.vstack(
            [np.hstack([R_ZUP_TO_YUP, np.zeros((3, 1))]),
             np.array([[0, 0, 0, 1]])]).astype(np.float64))
    return obj


def render_one(model_id, split, views, args):
    """在工作进程内执行；返回 (model_id, status, msg)。"""
    pyrender = sys.modules.get("pyrender")
    tm = sys.modules.get("trimesh")
    synset, model = model_id.split("/")
    model_path = os.path.join(
        args.models_dir, synset, model, "models", args.model_filename)
    if not os.path.exists(model_path):
        return model_id, "skip", "obj missing"

    # 续跑：所有视角产物 + complete 都存在则跳过
    paths_all = [output_paths(args.out, split, synset, model, v) for v in views]
    if not args.force and all(
            os.path.exists(p["image"]) and os.path.exists(p["cam"])
            and os.path.exists(p["partial"]) for p in paths_all) \
            and os.path.exists(paths_all[0]["complete"]):
        return model_id, "skip", "exists"

    try:
        mesh = load_normalized_mesh(model_path, args.up_axis, tm)
        if len(mesh.faces) == 0:
            return model_id, "fail", "no faces"

        obj_radius = float(np.abs(np.asarray(mesh.vertices)).max())
        H = W = args.image_size
        f = args.focal_scale * W
        cx, cy = W / 2.0, H / 2.0
        fov_y = 2.0 * np.arctan(H / (2.0 * f))
        distance = fit_distance(obj_radius, fov_y, fill=args.fill)

        # 完整点云（所有视角共享，每个模型采样一次）
        rng_c = np.random.RandomState(stable_seed("complete", model_id))
        complete, _ = tm.sample.sample_surface(mesh, args.n_complete)
        complete = np.asarray(complete, dtype=np.float32)
        if len(complete) < args.n_complete:
            sel = rng_c.choice(len(complete), args.n_complete - len(complete))
            complete = np.concatenate([complete, complete[sel]], 0)

        pr_mesh = pyrender.Mesh.from_trimesh(mesh, smooth=args.smooth)
        renderer = pyrender.OffscreenRenderer(W, H)

        for v in views:
            paths = output_paths(args.out, split, synset, model, v)
            rng = np.random.RandomState(stable_seed("view", model_id, v, split, args.seed))
            if split == "train" and args.jitter:
                az = 2.0 * np.pi * v / max(len(views), 1) + \
                    rng.uniform(-args.jitter, args.jitter)
                el = np.deg2rad(args.elevation + rng.uniform(-5, 5))
            else:
                az = 2.0 * np.pi * v / max(len(views), 1)
                el = np.deg2rad(args.elevation)
            eye = orbit_eye(az, el, distance)
            w2c = look_at_cv(eye)
            gl_pose = cv_to_gl_pose(w2c)

            scene = pyrender.Scene(bg_color=(0, 0, 0, 255),
                                   ambient_light=(0.35, 0.35, 0.35))
            scene.add(pr_mesh)
            cam = pyrender.IntrinsicsCamera(
                fx=f, fy=f, cx=cx, cy=cy, znear=0.05, zfar=distance + 2.0)
            scene.add(cam, pose=gl_pose)
            # 两盏方向光，随相机位置布置，保证受光面稳定
            for li, lpos in enumerate([eye, eye + np.array([0.5, -0.4, 0.3])]):
                light = pyrender.DirectionalLight(
                    color=np.ones(3), intensity=4.0 if li == 0 else 2.0)
                lp = np.eye(4)
                lp[:3, 3] = lpos
                scene.add(light, pose=lp)

            color, depth = renderer.render(scene)
            K = np.array([[f, 0, cx], [0, f, cy], [0, 0, 1]], dtype=np.float32)

            partial, _ = backproject_depth(
                depth, K, w2c, stride=1, max_points=args.n_partial_dense,
                depth_noise=args.depth_noise, rng=rng)
            if len(partial) < 64:
                renderer.delete()
                return model_id, "fail", f"view {v}: only {len(partial)} visible points"

            _write_sample(paths, color, depth, K, w2c, partial, complete, args)
        renderer.delete()
        return model_id, "ok", f"{len(views)} views"
    except Exception:
        return model_id, "fail", traceback.format_exc(limit=2)


def _write_sample(paths, color, depth, K, w2c, partial, complete, args):
    from PIL import Image
    for key in ("partial", "complete", "image", "cam"):
        os.makedirs(os.path.dirname(paths[key]), exist_ok=True)
    np.save(paths["partial"], partial.astype(np.float32))
    if not os.path.exists(paths["complete"]):
        np.save(paths["complete"], complete.astype(np.float32))
    Image.fromarray(color[..., :3]).save(paths["image"])
    if args.save_depth:
        os.makedirs(os.path.dirname(paths["depth"]), exist_ok=True)
        np.save(paths["depth"], depth.astype(np.float32))
    cam_json = {
        "K": K.tolist(), "w2c": w2c.tolist(),
        "image_size": [args.image_size, args.image_size],
        "depth_noise": args.depth_noise, "version": VERSION,
    }
    with open(paths["cam"], "w", encoding="utf-8") as f:
        json.dump(cam_json, f)


# ----------------------------- 多进程入口 -----------------------------

def init_worker(gl_platform):
    os.environ.setdefault("PYOPENGL_PLATFORM", gl_platform)
    import trimesh  # noqa: F401
    import pyrender  # noqa: F401


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--models_dir", required=True,
                    help="ShapeNetCore.v2 根目录（含 <synset>/<model>/models/*.obj）")
    ap.add_argument("--splits_dir", default="",
                    help="含 train/val/test 的 .list 或 .txt；不给则按 id 哈希划分")
    ap.add_argument("--out", default="data/shapenet55")
    ap.add_argument("--categories", nargs="*", default=[],
                    help="只渲染这些 synset，如 03001627 02691156")
    ap.add_argument("--model_filename", default="model_normalized.obj")
    ap.add_argument("--up_axis", choices=["z", "y"], default="z")
    ap.add_argument("--image_size", type=int, default=224)
    ap.add_argument("--focal_scale", type=float, default=1.15,
                    help="fx = focal_scale * 图像宽度")
    ap.add_argument("--fill", type=float, default=0.85)
    ap.add_argument("--elevation", type=float, default=25.0, help="仰角（度）")
    ap.add_argument("--jitter", type=float, default=0.2,
                    help="训练集方位角抖动（弧度），0 关闭")
    ap.add_argument("--views_train", type=int, default=1)
    ap.add_argument("--views_val", type=int, default=1)
    ap.add_argument("--views_test", type=int, default=8)
    ap.add_argument("--n_partial_dense", type=int, default=8192)
    ap.add_argument("--n_complete", type=int, default=16384)
    ap.add_argument("--depth_noise", type=float, default=0.002)
    ap.add_argument("--save_depth", action="store_true")
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--smooth", action="store_true", default=True)
    ap.add_argument("--gl_platform", default="egl",
                    choices=["egl", "osmesa", "pyglet", ""])
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()

    jobs = build_jobs(args)
    if args.limit:
        jobs = jobs[:args.limit]
    print(f"共 {len(jobs)} 个模型任务，输出到 {args.out}")
    if not jobs:
        return

    os.makedirs(args.out, exist_ok=True)
    tasks = [(mid, split, views, args) for mid, split, views in jobs]
    n_ok = n_skip = n_fail = 0
    failures = []

    if args.workers > 1:
        import multiprocessing as mp
        ctx = mp.get_context("spawn")
        with ctx.Pool(args.workers, initializer=init_worker,
                      initargs=(args.gl_platform,)) as pool:
            results = pool.starmap(_worker_entry, tasks, chunksize=1)
    else:
        if args.gl_platform:
            os.environ.setdefault("PYOPENGL_PLATFORM", args.gl_platform)
        init_worker(args.gl_platform)
        results = [_worker_entry(*t) for t in tasks]

    for mid, status, msg in results:
        if status == "ok":
            n_ok += 1
        elif status == "skip":
            n_skip += 1
        else:
            n_fail += 1
            failures.append((mid, msg))
    print(f"完成 ok={n_ok} skip={n_skip} fail={n_fail}")

    # 由实际落盘文件重建 splits/<split>.txt，避免多进程写冲突
    for split in ("train", "val", "test"):
        part_dir = os.path.join(args.out, "pcd", split, "partial")
        entries = []
        if os.path.isdir(part_dir):
            for dirpath, _, files in os.walk(part_dir):
                for fn in files:
                    if fn.endswith(".npy"):
                        entries.append(os.path.relpath(
                            os.path.join(dirpath, fn), part_dir).replace(os.sep, "/"))
        if entries:
            os.makedirs(os.path.join(args.out, "splits"), exist_ok=True)
            with open(os.path.join(args.out, "splits", f"{split}.txt"),
                      "w", encoding="utf-8") as f:
                f.write("\n".join(sorted(entries)))

    if failures:
        with open(os.path.join(args.out, "render_failures.txt"),
                  "w", encoding="utf-8") as f:
            for mid, msg in failures:
                f.write(f"=== {mid} ===\n{msg}\n")
        print(f"失败详情见 {os.path.join(args.out, 'render_failures.txt')}")


def _worker_entry(model_id, split, views, args):
    return render_one(model_id, split, views, args)


if __name__ == "__main__":
    main()
