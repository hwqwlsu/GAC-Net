"""把 GAC-Net 对某个 split 的预测结果导出为统一 .npy，供跨方法统一评估。

输出布局（id 与 splits/<split>.txt 条目一致，去掉 .npy）：
    <out>/<synset>/<model>__v<view>.npy   ->  (N,3) float32

用法：
    python predict.py --ckpt experiments/gacnet_shapenet55/best_model.pth \
        --out predictions/gacnet --split test
"""
import argparse
import json
import os

import numpy as np
import torch
from torch.utils.data import DataLoader

from pcic.data import build_dataset
from pcic.models import GACNet


def move(batch, device):
    return {k: (v.to(device) if torch.is_tensor(v) else v) for k, v in batch.items()}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--split", default="test")
    ap.add_argument("--override", default=None)
    ap.add_argument("--batch_size", type=int, default=16)
    args = ap.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    ckpt = torch.load(args.ckpt, map_location=device, weights_only=False)
    cfg = ckpt["config"]
    if args.override:
        cfg.update(json.loads(args.override))

    dataset = build_dataset(cfg, args.split)
    loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=False,
                        num_workers=cfg.get("num_workers", 4))
    model = GACNet(**cfg["model"]).to(device)
    model.load_state_dict(ckpt["model"])
    model.eval()

    os.makedirs(args.out, exist_ok=True)
    n = 0
    with torch.no_grad():
        for batch in loader:
            ids = batch["id"]
            batch = move(batch, device)
            fine = model(batch)["fine"]
            for i, pid in enumerate(ids):
                # dataset 的 id 不含扩展名，形如 03001627/model__v0
                rel = pid[:-4] if pid.endswith(".npy") else pid
                dst = os.path.join(args.out, rel + ".npy")
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                np.save(dst, fine[i].cpu().numpy().astype(np.float32))
                n += 1
    print(f"[saved] {n} 个预测 -> {args.out}")


if __name__ == "__main__":
    main()
