# -*- coding: utf-8 -*-
import zipfile, collections
z = zipfile.ZipFile("/root/autodl-tmp/pix3d.zip")
n = z.namelist()
print("entries:", len(n))
print("first:", n[:6])
objs = [x for x in n if x.endswith(".obj")]
print("obj count:", len(objs))
print("obj sample:", objs[:5])
print("top dirs:", collections.Counter(x.split("/")[0] for x in n).most_common(8))
if objs:
    print("obj 2nd dirs:", collections.Counter(x.split("/")[1] for x in objs).most_common(8))
    print("obj 3rd dirs:", collections.Counter(x.split("/")[2] for x in objs if len(x.split("/")) > 2).most_common(12))
