# -*- coding: utf-8 -*-
"""AutoDL SSH 助手：python autodl_ssh.py run "<cmd>" [timeout] | put <local> <remote>"""
import sys, warnings
warnings.filterwarnings("ignore")
import paramiko

import os
HOST, PORT, USER = "connect.westd.seetacloud.com", 28382, "root"
KEY = os.path.expandvars(r"%USERPROFILE%\.ssh\autodl_5090")
PWD = os.environ.get("AUTODL_SSH_PWD", "")

def client():
    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    if PWD:
        c.connect(HOST, port=PORT, username=USER, password=PWD, timeout=20, look_for_keys=False)
    else:
        c.connect(HOST, port=PORT, username=USER, key_filename=KEY, timeout=20)
    return c

def run(cmd, timeout=300):
    c = client()
    stdin, stdout, stderr = c.exec_command(cmd, timeout=timeout)
    out = stdout.read().decode("utf-8", "replace")
    err = stderr.read().decode("utf-8", "replace")
    code = stdout.channel.recv_exit_status()
    c.close()
    return code, out, err

def upload(local, remote):
    c = client()
    s = c.open_sftp()
    s.put(local, remote)
    s.close(); c.close()

if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    if sys.argv[1] == "run":
        code, out, err = run(sys.argv[2], int(sys.argv[3]) if len(sys.argv) > 3 else 300)
        print(out)
        if err.strip():
            print("[stderr]", err[-1500:])
        print("[exit]", code)
    elif sys.argv[1] == "put":
        upload(sys.argv[2], sys.argv[3])
        print("[uploaded]", sys.argv[3])
    elif sys.argv[1] == "get":
        c = client()
        s = c.open_sftp()
        s.get(sys.argv[2], sys.argv[3])
        s.close(); c.close()
        print("[downloaded]", sys.argv[3])
