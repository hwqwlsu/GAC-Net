# -*- coding: utf-8 -*-
p = "/root/SnowflakeNet/models/pointnet2_ops_lib/setup.py"
s = open(p).read()
s = s.replace('os.environ["TORCH_CUDA_ARCH_LIST"] = "12.0"',
              'os.environ["TORCH_CUDA_ARCH_LIST"] = "9.0+PTX"')
open(p, "w").write(s)
print("patched to 9.0+PTX:", "9.0+PTX" in s)
