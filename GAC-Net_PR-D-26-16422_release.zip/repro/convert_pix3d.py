# -*- coding: utf-8 -*-
"""服务器端：Pix3D OBJ -> ShapeNet v2 风格布局（chair/table/sofa）。
实际结构：model/<cat>/<model_name>/model.obj（无顶层 pix3d/ 前缀）。"""
import os
import zipfile

ZIP = "/root/autodl-tmp/pix3d.zip"
OUT = "/root/autodl-tmp/pix3d_meshes"
CATS = {"chair": "03001627", "table": "04379243", "sofa": "04256520"}

zf = zipfile.ZipFile(ZIP)
names = [n for n in zf.namelist()
         if n.endswith("/model.obj") and n.split("/")[0] == "model"
         and n.split("/")[1] in CATS]
print("obj files:", len(names))

n_ok = 0
for n in names:
    parts = n.split("/")
    cat, mid = parts[1], parts[2]
    dst_dir = os.path.join(OUT, CATS[cat], mid, "models")
    dst = os.path.join(dst_dir, "model_normalized.obj")
    if not os.path.exists(dst):
        os.makedirs(dst_dir, exist_ok=True)
        with zf.open(n) as src, open(dst, "wb") as f:
            f.write(src.read())
    n_ok += 1
print("extracted:", n_ok)
for cat, syn in CATS.items():
    p = os.path.join(OUT, syn)
    print(syn, cat, len(os.listdir(p)) if os.path.isdir(p) else 0)
print("CONVERT_DONE")
