# -*- coding: utf-8 -*-
"""服务器端 baseline 对接链路验证：模拟渲染数据 → predict → export_pcn
→ collect(假baseline=GT+噪声) → eval_predictions。"""
import json, os, sys
import numpy as np
import torch

sys.path.insert(0, "/root/image_guided_pc_completion")
from pcic.data.synthetic import build_mesh, sample_surface, normalize_points, CATEGORIES
from tools.camera_utils import look_at_cv, orbit_eye, fit_distance, project_points
from PIL import Image

ROOT = "/root/autodl-tmp/bl_shapenet"
PROJ = "/root/image_guided_pc_completion"
CATS = ["chair", "table", "sofa"]
SYN = {"chair": "03001627", "table": "04379243", "sofa": "04256520"}
rng = np.random.default_rng(7)

# ---------- 1. 模拟渲染产物 ----------
for split, n_model in [("train", 2), ("test", 2)]:
    for cat in CATS:
        for m in range(n_model):
            mid = f"m{m}"
            verts, faces = build_mesh(cat, rng)
            comp = normalize_points(sample_surface(verts, faces, 16384, rng)).astype(np.float32)
            d_comp = f"{ROOT}/pcd/{split}/complete/{SYN[cat]}"
            os.makedirs(d_comp, exist_ok=True)
            np.save(f"{d_comp}/{mid}.npy", comp)
            nv = 2 if split == "test" else 1
            for v in range(nv):
                az = rng.uniform(0, 2 * np.pi); el = rng.uniform(0.3, 0.9)
                eye = orbit_eye(az, el, fit_distance(0.9, 0.5, 0.85))
                w2c = look_at_cv(eye, np.zeros(3))
                K = np.array([[140.0, 0, 56], [0, 140.0, 56], [0, 0, 1.0]])
                pts = comp[rng.choice(16384, 8192, replace=False)]
                u, vv, z = project_points(pts, K, w2c)
                uv = np.stack([u, vv], 1)
                keep = (uv[:, 0] >= 0) & (uv[:, 0] < 112) & (uv[:, 1] >= 0) & (uv[:, 1] < 112)
                partial = pts[keep][:2048]
                stem = f"{SYN[cat]}/{mid}__v{v}"
                dp = f"{ROOT}/pcd/{split}/partial/{SYN[cat]}"
                os.makedirs(dp, exist_ok=True)
                np.save(f"{dp}/{mid}__v{v}.npy", partial)
                img = np.full((112, 112, 3), 200, np.uint8)
                ui = uv[keep][:2048].astype(int)
                img[ui[:, 1], ui[:, 0]] = [30, 30, 30]
                flat = f"{SYN[cat]}_{mid}__v{v}"
                dr = f"{ROOT}/renders"
                os.makedirs(dr, exist_ok=True)
                Image.fromarray(img).save(f"{dr}/{flat}.png")
                dc = f"{ROOT}/cams"
                os.makedirs(dc, exist_ok=True)
                json.dump({"K": K.tolist(), "w2c": w2c.tolist(),
                           "pre_normalized": True},
                          open(f"{dc}/{flat}.json", "w"))
                dd = f"{ROOT}/depth"
                os.makedirs(dd, exist_ok=True)
                depth = np.zeros((112, 112), np.float32)
                depth[ui[:, 1], ui[:, 0]] = z[keep][:2048]
                np.save(f"{dd}/{flat}.npy", depth)
ids = [f"{SYN[c]}/m{m}__v{v}.npy" for c in CATS for m in range(2) for v in range(2)]
os.makedirs(f"{ROOT}/splits", exist_ok=True)
for sp in ["train", "val", "test"]:
    open(f"{ROOT}/splits/{sp}.txt", "w").write("\n".join(ids))
print("[1] mock render data ok:", len(ids), "view entries")

# ---------- 2. predict (GAC-Net) ----------
os.chdir(PROJ)
ov = json.dumps({"data_root": ROOT, "dataset": "shapenet55",
                 "image_size": 112, "pre_normalized": True})
r = os.system(f"/root/miniconda3/bin/python predict.py "
              f"--ckpt experiments/chair_smoke/best_model.pth "
              f"--out predictions/gacnet --split test "
              f"--override '{ov}' > /tmp/predict.log 2>&1")
print("[2] predict rc:", r)
if r != 0:
    print(open("/tmp/predict.log").read()[-500:])

# ---------- 3. export_pcn ----------
r = os.system(f"/root/miniconda3/bin/python tools/baselines/export_pcn.py "
              f"--root {ROOT} --out /root/autodl-tmp/bl_pcn > /tmp/export.log 2>&1")
print("[3] export rc:", r)

# ---------- 4. 模拟 SnowflakeNet 风格预测并 collect ----------
out_dir = "/root/autodl-tmp/bl_pcn"
for c in CATS:
    for m in range(2):
        gt = np.load(f"{ROOT}/pcd/test/complete/{SYN[c]}/m{m}.npy")
        for v in range(2):
            pred = gt + rng.normal(0, 0.01, gt.shape).astype(np.float32)
            dd = f"/root/autodl-tmp/snow_result/{SYN[c]}"
            os.makedirs(dd, exist_ok=True)
            sys.path.insert(0, PROJ)
            from tools.baselines.io_pcd import write_pcd
            write_pcd(f"{dd}/m{m}__v{v}.pcd", pred)
r = os.system(f"/root/miniconda3/bin/python tools/baselines/collect_predictions.py "
              f"--src /root/autodl-tmp/snow_result --method snowflakenet "
              f"--split_file {ROOT}/splits/test.txt --strict > /tmp/collect.log 2>&1")
print("[4] collect rc:", r)
print(open("/tmp/collect.log").read()[-400:])

# ---------- 5. eval_predictions ----------
r = os.system(f"/root/miniconda3/bin/python tools/eval_predictions.py "
              f"--data_root {ROOT} > /tmp/eval.log 2>&1")
print("[5] eval rc:", r)
print(open("/tmp/eval.log").read()[-600:])
print("CHAIN_DONE")
