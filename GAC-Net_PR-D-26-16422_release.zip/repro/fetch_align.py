# -*- coding: utf-8 -*-
import sys, warnings
warnings.filterwarnings("ignore")
import paramiko
c = paramiko.SSHClient()
c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect("connect.westb.seetacloud.com", port=23326, username="root",
          password="yuk4EGNx2TKK", timeout=20)
s = c.open_sftp()
s.get("/root/autodl-tmp/align_dump.png",
      r"C:\Users\黄文全\Documents\Trae-CN\temp_20261013_01\align_check.png")
print("got align_dump.png")
s.close(); c.close()
