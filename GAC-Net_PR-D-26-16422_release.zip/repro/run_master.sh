#!/bin/bash
# 主管线 + 扩展实验总队列（v0-only 协议；预测产物写数据盘，评估后仅保留 v0）
cd /root/image_guided_pc_completion
PY=/root/miniconda3/bin/python
SNOW=/root/miniconda3/envs/snowflake/bin/python
PRED=/root/autodl-tmp/pc_predictions

keep_v0 () { find "$1" -name '*.npy' ! -name '*__v0.npy' -delete; }

echo "=== [0/12] cleanup failed leftovers ==="
rm -rf $PRED/gacnet_pcn8 experiments/gacnet_pcn8_pointonly experiments/gacnet_pcn8_noanchor
df -h / /root/autodl-tmp | tail -2

echo "=== [1/12] GAC-Net predict + eval (v0) ==="
$PY predict.py --ckpt experiments/gacnet_pcn8/best_model.pth --out $PRED/gacnet_pcn8 --split test 2>&1 | tail -2
keep_v0 $PRED/gacnet_pcn8
ln -sfn $PRED/gacnet_pcn8 predictions/gacnet_pcn8
$PY tools/eval_predictions.py --pred_root predictions --data_root data/shapenet8/pcd --split test --methods gacnet_pcn8 2>&1 | tail -6

echo "=== [2/12] train point_only (50ep) ==="
$PY train.py --config configs/pcn8_pointonly.json 2>&1 | tail -3
$PY predict.py --ckpt experiments/gacnet_pcn8_pointonly/best_model.pth --out $PRED/pointonly_pcn8 --split test 2>&1 | tail -2
keep_v0 $PRED/pointonly_pcn8
ln -sfn $PRED/pointonly_pcn8 predictions/pointonly_pcn8
$PY tools/eval_predictions.py --pred_root predictions --data_root data/shapenet8/pcd --split test --methods pointonly_pcn8 2>&1 | tail -5

echo "=== [3/12] train SnowflakeNet (50ep) ==="
cd /root/SnowflakeNet/completion
$SNOW train.py --config configs/pcn8.yaml 2>&1 | tail -3
SN_CKPT=$(ls -t /root/autodl-tmp/snow_exp/pcn8/ckpt*.pth 2>/dev/null | head -1)
echo "snow ckpt: $SN_CKPT"
$SNOW predict_dump_snow.py --config configs/pcn8.yaml --ckpt "$SN_CKPT" --src_root /root/autodl-tmp/PCN8_snow/test/partial --views 0 --out /root/autodl-tmp/snow_pred_pcn8 2>&1 | tail -2
cd /root/image_guided_pc_completion
$PY tools/baselines/collect_predictions.py --src /root/autodl-tmp/snow_pred_pcn8 --method snowflakenet_pcn8 --split_file data/shapenet8/splits/test.txt --ext pcd --strict 2>&1 | tail -3
$PY tools/eval_predictions.py --pred_root predictions --data_root data/shapenet8/pcd --split test --methods snowflakenet_pcn8 2>&1 | tail -5
rm -rf /root/autodl-tmp/snow_pred_pcn8

echo "=== [4/12] train no_anchor (30ep) ==="
$PY train.py --config configs/pcn8_noanchor.json 2>&1 | tail -2
$PY predict.py --ckpt experiments/gacnet_pcn8_noanchor/best_model.pth --out $PRED/noanchor_pcn8 --split test 2>&1 | tail -2
keep_v0 $PRED/noanchor_pcn8
ln -sfn $PRED/noanchor_pcn8 predictions/noanchor_pcn8
$PY tools/eval_predictions.py --pred_root predictions --data_root data/shapenet8/pcd --split test --methods noanchor_pcn8 2>&1 | tail -5

echo "=== [5/12] train no_lview (30ep) ==="
$PY train.py --config configs/pcn8_nolview.json 2>&1 | tail -2
$PY predict.py --ckpt experiments/gacnet_pcn8_nolview/best_model.pth --out $PRED/nolview_pcn8 --split test 2>&1 | tail -2
keep_v0 $PRED/nolview_pcn8
ln -sfn $PRED/nolview_pcn8 predictions/nolview_pcn8
$PY tools/eval_predictions.py --pred_root predictions --data_root data/shapenet8/pcd --split test --methods nolview_pcn8 2>&1 | tail -5

echo "=== [6/12] Pix3D zero-shot generalization ==="
$PY predict.py --ckpt experiments/gacnet_pcn8/best_model.pth --out $PRED/gacnet_pcn8_to_pix3d --split test --override '{"data_root":"data/pix3d_dev"}' 2>&1 | tail -2
ln -sfn $PRED/gacnet_pcn8_to_pix3d predictions/gacnet_pcn8_to_pix3d
$PY tools/eval_predictions.py --pred_root predictions --data_root data/pix3d_dev/pcd --split test --methods gacnet_pcn8_to_pix3d 2>&1 | tail -5

echo "=== [7/12] sparsity sweep ==="
for N in 256 512 1024; do
  $PY predict.py --ckpt experiments/gacnet_pcn8/best_model.pth --out $PRED/gacnet_pcn8_ds$N --split test --override "{\"n_partial\": $N}" 2>&1 | tail -1
  keep_v0 $PRED/gacnet_pcn8_ds$N
  ln -sfn $PRED/gacnet_pcn8_ds$N predictions/gacnet_pcn8_ds$N
  $PY tools/eval_predictions.py --pred_root predictions --data_root data/shapenet8/pcd --split test --methods gacnet_pcn8_ds$N 2>&1 | tail -4
done

echo "=== [8/12] image degradation sweep ==="
$PY tools/gen_shadow_degrade.py 2>&1 | tail -2
for D in blur2 noise05 gray; do
  $PY predict.py --ckpt experiments/gacnet_pcn8/best_model.pth --out $PRED/gacnet_pcn8_$D --split test --override "{\"data_root\":\"data/shapenet8_$D\"}" 2>&1 | tail -1
  keep_v0 $PRED/gacnet_pcn8_$D
  ln -sfn $PRED/gacnet_pcn8_$D predictions/gacnet_pcn8_$D
  $PY tools/eval_predictions.py --pred_root predictions --data_root data/shapenet8/pcd --split test --methods gacnet_pcn8_$D 2>&1 | tail -4
done

echo "=== [9/12] visualizations ==="
$PY tools/viz_stage.py 2>&1 | tail -2
$PY tools/viz_bias.py 2>&1 | tail -2

echo "=== [10/12] efficiency ==="
$PY tools/bench_efficiency.py --part gac 2>&1 | tail -2
$SNOW tools/bench_efficiency.py --part snow 2>&1 | tail -2

echo "=== [11/12] official ckpt probe (best-effort) ==="
source /etc/network_turbo 2>/dev/null || true
$PY tools/try_official_ckpt.py 2>&1 | tail -8 || true

echo "=== [12/12] generate all assets ==="
$SNOW /root/image_guided_pc_completion/make_all_assets.py 2>&1 | tail -14
echo "MASTER_DONE"
