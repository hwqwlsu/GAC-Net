# -*- coding: utf-8 -*-
import warnings
warnings.filterwarnings("ignore")
import paramiko
c = paramiko.SSHClient()
c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect("connect.westb.seetacloud.com", port=23326, username="root",
          password="yuk4EGNx2TKK", timeout=20)
s = c.open_sftp()
base = r"C:\Users\黄文全\Documents\Trae-CN\temp_20261013_01\server_results"
import os
os.makedirs(base, exist_ok=True)
files = {
    "/root/image_guided_pc_completion/results/comparison.csv": "pix3d_comparison.csv",
    "/root/image_guided_pc_completion/experiments/pix3d_dev/train_log.csv": "pix3d_train_log.csv",
}
for r, l in files.items():
    s.get(r, os.path.join(base, l))
    print("got", l)
s.close(); c.close()
