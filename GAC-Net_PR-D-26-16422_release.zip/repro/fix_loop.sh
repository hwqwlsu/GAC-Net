#!/bin/bash
# 后台循环：每 30 秒修正一次 Windows 反斜杠文件名
while true; do
    cd /root/autodl-tmp
    for f in ShapeNetCore_zips\\*.zip; do
        [ -e "$f" ] || continue
        syn="${f#ShapeNetCore_zips\\}"
        mv "$f" "ShapeNetCore_zips/$syn" 2>/dev/null && echo "fixed $syn"
    done
    sleep 30
done
