# -*- coding: utf-8 -*-
"""给 predict_dump_snow.py 加 --views 过滤，保证与 GAC-Net 同样本集（v0）。"""
p = "/root/SnowflakeNet/completion/predict_dump_snow.py"
s = open(p, encoding="utf-8").read()

old_arg = 'ap.add_argument("--out", default="/root/autodl-tmp/snow_pred")'
new_arg = old_arg + '\n    ap.add_argument("--views", default=None, help="逗号分隔视角过滤，如 0")'
assert old_arg in s, "arg line not found"
s = s.replace(old_arg, new_arg)

old_loop = "                pts = read_pcd(vf)"
new_loop = ('                if args.views and str(view) not in args.views.split(","):\n'
            "                    continue\n" + old_loop)
assert old_loop in s, "loop line not found"
s = s.replace(old_loop, new_loop)

open(p, "w", encoding="utf-8").write(s)
print("PATCHED_OK")
