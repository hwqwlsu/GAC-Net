import sys, os, traceback
sys.path.insert(0, "/root/SnowflakeNet/completion")
os.chdir("/root/SnowflakeNet/completion")

import torch
from utils import yaml_reader
from core.datasets.pcn import PCNDataLoader, collate_fn

cfg = yaml_reader.read_yaml("configs/pcn8.yaml")
dl = PCNDataLoader(cfg)

subset = cfg.test.split
ds = dl.get_dataset(subset)
print("subset =", subset, "| len =", len(ds))

for i in [0, 1, len(ds) // 2, len(ds) - 1]:
    try:
        tid, mid, data = ds[i]
        print("  item %d OK: cat=%s model=%s partial=%s gt=%s" % (
            i, tid, mid[:12], tuple(data['partial_cloud'].shape), tuple(data['gtcloud'].shape)))
    except Exception:
        print("  item %d FAILED" % i)
        traceback.print_exc()
        break

print("\n=== DataLoader 跑 60 个 batch（验证不再崩） ===")
loader = torch.utils.data.DataLoader(ds, batch_size=16, shuffle=True,
                                     num_workers=4, collate_fn=collate_fn, drop_last=True)
for bi, batch in enumerate(loader):
    if bi >= 60:
        print("  60 batches 全部通过，路径 bug 已修复")
        break
print("  final batch partial:", tuple(batch['partial_cloud'].shape),
      "gt:", tuple(batch['gtcloud'].shape))
