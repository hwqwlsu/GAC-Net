# -*- coding: utf-8 -*-
"""从真实训练日志与 eval 结果生成论文图表。
输入：experiments/pix3d_{dev,pointonly}/train_log.csv, results/comparison.csv
输出：paper/figures/fig_train_curves.png, fig_pix3d_comparison.png
所有数字均为真实训练/评估产物，无虚构。"""
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = "/root/image_guided_pc_completion"
OUT = "/root/autodl-tmp/paper_figures"
os.makedirs(OUT, exist_ok=True)

plt.rcParams.update({
    "font.size": 11, "axes.titlesize": 12, "axes.labelsize": 11,
    "legend.fontsize": 9, "figure.dpi": 150, "savefig.dpi": 300,
    "font.family": "DejaVu Sans",
})

def read_log(path):
    cols = None
    rows = []
    with open(path) as f:
        for line in f:
            parts = line.strip().split(",")
            if cols is None:
                cols = parts; continue
            rows.append(parts)
    d = {c: [] for c in cols}
    for r in rows:
        for c, v in zip(cols, r):
            try: d[c].append(float(v))
            except ValueError: d[c].append(np.nan)
    return {k: np.array(v) for k, v in d.items()}

# ---- Fig: training curves ----
gac = read_log(os.path.join(ROOT, "experiments/pix3d_dev/train_log.csv"))
po = read_log(os.path.join(ROOT, "experiments/pix3d_pointonly/train_log.csv"))

fig, axes = plt.subplots(1, 2, figsize=(10, 3.8))
ax = axes[0]
ax.plot(gac["epoch"], gac["loss"], label="GAC-Net (image-guided)", color="#1f77b4")
ax.plot(po["epoch"], po["loss"], label="Point-only ablation", color="#ff7f0e", ls="--")
ax.set_xlabel("Epoch"); ax.set_ylabel("Training loss")
ax.set_title("(a) Training loss on Pix3D")
ax.legend(); ax.grid(alpha=0.3)

ax = axes[1]
gval = np.where(gac["cd_l1_val"] < 0, np.nan, gac["cd_l1_val"])
pval = np.where(po["cd_l1_val"] < 0, np.nan, po["cd_l1_val"])
ax.plot(gac["epoch"], gval, label="GAC-Net", color="#1f77b4", marker="o", ms=3)
ax.plot(po["epoch"], pval, label="Point-only", color="#ff7f0e", ls="--", marker="s", ms=3)
ax.set_xlabel("Epoch"); ax.set_ylabel("Val CD-L1 (raw)")
ax.set_title("(b) Validation Chamfer-L1")
ax.legend(); ax.grid(alpha=0.3)
plt.tight_layout()
plt.savefig(os.path.join(OUT, "fig_train_curves.png"), bbox_inches="tight")
plt.close()
print("saved fig_train_curves.png")

# ---- Fig: Pix3D comparison (3 methods) ----
import csv
comp = {}
with open(os.path.join(ROOT, "results/comparison.csv"), encoding="utf-8-sig") as f:
    for r in csv.DictReader(f):
        comp.setdefault(r["method"], {})[r["category"]] = r

methods = ["gacnet_pix3d", "pointonly_pix3d", "snowflake_pix3d"]
labels = ["GAC-Net\n(image-guided)", "Point-only\nablation", "SnowflakeNet\n(point-only)"]
colors = ["#1f77b4", "#ff7f0e", "#2ca02c"]
cats = ["chair", "sofa", "table"]

fig, axes = plt.subplots(1, 2, figsize=(11, 4.0))
x = np.arange(len(cats))
w = 0.26
for i, (m, lab, c) in enumerate(zip(methods, labels, colors)):
    vals = [float(comp[m][cat]["CD_L1_x1e4"]) for cat in cats]
    axes[0].bar(x + (i - 1) * w, vals, w, label=lab, color=c)
axes[0].set_xticks(x); axes[0].set_xticklabels(cats)
axes[0].set_ylabel("CD-L1 (×10⁴)  ↓")
axes[0].set_title("(a) Chamfer-L1 on Pix3D (lower is better)")
axes[0].legend(fontsize=8); axes[0].grid(axis="y", alpha=0.3)

for i, (m, lab, c) in enumerate(zip(methods, labels, colors)):
    vals = [float(comp[m][cat]["Fscore@0.01"]) for cat in cats]
    axes[1].bar(x + (i - 1) * w, vals, w, label=lab, color=c)
axes[1].set_xticks(x); axes[1].set_xticklabels(cats)
axes[1].set_ylabel("F-Score@1%  ↑")
axes[1].set_title("(b) F-Score@1% on Pix3D (higher is better)")
axes[1].legend(fontsize=8); axes[1].grid(axis="y", alpha=0.3)
plt.tight_layout()
plt.savefig(os.path.join(OUT, "fig_pix3d_comparison.png"), bbox_inches="tight")
plt.close()
print("saved fig_pix3d_comparison.png")
print("FIGS_DONE")
