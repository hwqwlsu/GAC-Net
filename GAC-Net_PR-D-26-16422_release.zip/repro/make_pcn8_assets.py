# -*- coding: utf-8 -*-
"""PCN-8 训练完成后：从真实评估结果生成论文表格与图。
输入: results/prediction_metrics/{gacnet_pcn8,pointonly_pcn8,snowflakenet_pcn8}.json
      experiments/gacnet_pcn8{,_pointonly}/train_log.csv
      data/shapenet8/pcd/test/{partial,complete}/...
输出: paper_assets/tables.md, fig_pcn8_cdl1_bars.png, fig_pcn8_curves.png,
      fig_pcn8_qualitative.png
"""
import csv
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = "/root/image_guided_pc_completion"
OUT = os.path.join(ROOT, "paper_assets")
os.makedirs(OUT, exist_ok=True)

CATS = ["airplane", "cabinet", "car", "chair", "lamp", "sofa", "table", "watercraft"]
METHODS = [
    ("snowflakenet_pcn8", "SnowflakeNet"),
    ("pointonly_pcn8", "Point-only (w/o image)"),
    ("gacnet_pcn8", "GAC-Net (ours)"),
]
COLORS = {"snowflakenet_pcn8": "#8C8C8C", "pointonly_pcn8": "#DD8452",
          "gacnet_pcn8": "#4C72B0"}


def load_reports():
    reports = {}
    for key, _ in METHODS:
        p = os.path.join(ROOT, "results", "prediction_metrics", key + ".json")
        if os.path.exists(p):
            with open(p, encoding="utf-8") as f:
                reports[key] = json.load(f)
    return reports


def load_curves(exp):
    p = os.path.join(ROOT, "experiments", exp, "train_log.csv")
    if not os.path.exists(p):
        return [], []
    ep, loss = [], []
    with open(p, encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            try:
                ep.append(int(row["epoch"]))
                loss.append(float(row["loss"]))
            except (ValueError, KeyError):
                continue
    return ep, loss


def fmt(x, nd=1):
    return f"{x:.{nd}f}" if isinstance(x, (int, float)) else "TBD"


def gen_tables(reports):
    lines = []
    lines.append("# PCN-8 真实实验结果（自动生成，请勿手改数字）\n")

    # Table 1: CD-L1 per category
    lines.append("## Table 1. Completion on PCN-8 (CD-L1 x1e4, lower is better)\n")
    lines.append("| Method | " + " | ".join(c[:5] for c in CATS) + " | Avg. |")
    lines.append("|---|" + "---|" * (len(CATS) + 1))
    for key, label in METHODS:
        if key not in reports:
            lines.append(f"| {label} | " + "TBD | " * (len(CATS) + 1))
            continue
        r = reports[key]
        vals = [fmt(r.get(c, {}).get("CD_L1_x1e4")) for c in CATS]
        lines.append(f"| {label} | " + " | ".join(vals) + f" | {fmt(r['overall']['CD_L1_x1e4'])} |")

    # Table 2: CD-L2 + F-Score
    lines.append("\n## Table 2. CD-L2 x1e4 and F-Score (overall, macro)\n")
    lines.append("| Method | CD-L2 | F@1% | F@2% |")
    lines.append("|---|---|---|---|")
    for key, label in METHODS:
        if key not in reports:
            lines.append(f"| {label} | TBD | TBD | TBD |")
            continue
        o = reports[key]["overall"]
        lines.append(f"| {label} | {fmt(o['CD_L2_x1e4'])} | "
                     f"{fmt(o['Fscore@0.01'], 3)} | {fmt(o['Fscore@0.02'], 3)} |")

    # Table 4: ablation
    lines.append("\n## Table 4. Ablation: GAC-Net vs point-only (overall)\n")
    lines.append("| Variant | CD-L1 | CD-L2 | F@1% |")
    lines.append("|---|---|---|---|")
    for key, label in [("gacnet_pcn8", "GAC-Net (full)"),
                       ("pointonly_pcn8", "Point-only (no image)")]:
        if key in reports:
            o = reports[key]["overall"]
            lines.append(f"| {label} | {fmt(o['CD_L1_x1e4'])} | "
                         f"{fmt(o['CD_L2_x1e4'])} | {fmt(o['Fscore@0.01'], 3)} |")
        else:
            lines.append(f"| {label} | TBD | TBD | TBD |")

    with open(os.path.join(OUT, "tables.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print("[saved] tables.md")


def gen_cdl1_bars(reports):
    avail = [(k, l) for k, l in METHODS if k in reports]
    if not avail:
        print("[skip] cdl1 bars: no reports")
        return
    x = np.arange(len(CATS))
    w = 0.8 / max(len(avail), 1)
    fig, ax = plt.subplots(figsize=(10, 4.2))
    for i, (key, label) in enumerate(avail):
        vals = [reports[key].get(c, {}).get("CD_L1_x1e4", np.nan) for c in CATS]
        ax.bar(x + (i - (len(avail) - 1) / 2) * w, vals, w * 0.92,
               label=label, color=COLORS[key], edgecolor="white")
    ax.set_xticks(x)
    ax.set_xticklabels(CATS, rotation=20, ha="right")
    ax.set_ylabel("CD-L1 x1e4 (lower is better)")
    ax.legend(frameon=False)
    ax.spines[["top", "right"]].set_visible(False)
    plt.tight_layout()
    plt.savefig(os.path.join(OUT, "fig_pcn8_cdl1_bars.png"), dpi=150)
    plt.close()
    print("[saved] fig_pcn8_cdl1_bars.png")


def gen_curves():
    eps_a, loss_a = load_curves("gacnet_pcn8")
    eps_b, loss_b = load_curves("gacnet_pcn8_pointonly")
    if not eps_a and not eps_b:
        print("[skip] curves: no train_log")
        return
    fig, ax = plt.subplots(figsize=(7, 4))
    if eps_a:
        ax.plot(eps_a, loss_a, label="GAC-Net (full)", color="#4C72B0")
    if eps_b:
        ax.plot(eps_b, loss_b, label="Point-only", color="#DD8452")
    ax.set_xlabel("Epoch")
    ax.set_ylabel("Training loss (CD-L1)")
    ax.legend(frameon=False)
    ax.spines[["top", "right"]].set_visible(False)
    plt.tight_layout()
    plt.savefig(os.path.join(OUT, "fig_pcn8_curves.png"), dpi=150)
    plt.close()
    print("[saved] fig_pcn8_curves.png")


def gen_qualitative(reports, n_samples=3):
    """选 CD-L1 中位附近真实 test 样本，画 partial/GT/三方法对比。"""
    import open3d as o3d

    def read_pts(path):
        if path.endswith(".npy"):
            return np.load(path).astype(np.float32)
        return np.asarray(o3d.io.read_point_cloud(path).points, np.float32)

    gac = reports.get("gacnet_pcn8")
    if not gac:
        print("[skip] qualitative: no gacnet report")
        return
    test_txt = os.path.join(ROOT, "data", "shapenet8", "splits", "test.txt")
    with open(test_txt) as f:
        ids = [ln.strip()[:-4] for ln in f if ln.strip().endswith("__v0.npy")]
    rng = np.random.RandomState(0)
    picks = rng.choice(len(ids), size=n_samples, replace=False)
    rows = [ids[i] for i in picks]

    ncol = 2 + len([1 for k, _ in METHODS if k in reports])
    fig = plt.figure(figsize=(3 * ncol, 3.1 * len(rows)))
    for r, cid in enumerate(rows):
        syn, mid = cid.split("/")
        col = 0
        panels = [("Input", os.path.join(ROOT, "data/shapenet8/pcd/test/partial",
                                         syn, mid + "__v0.npy"))]
        panels.append(("Ground truth", os.path.join(
            ROOT, "data/shapenet8/pcd/test/complete", syn, mid + ".npy")))
        for key, label in METHODS:
            p = os.path.join(ROOT, "predictions", key, syn, mid + "__v0.npy")
            if os.path.exists(p):
                panels.append((label.split(" (")[0], p))
        for label, path in panels:
            ax = fig.add_subplot(len(rows), ncol, r * ncol + col + 1, projection="3d")
            pts = read_pts(path)
            step = max(1, len(pts) // 1200)
            pts = pts[::step]
            ax.scatter(pts[:, 0], pts[:, 2], -pts[:, 1], s=1.2,
                       c=pts[:, 2], cmap="viridis", linewidth=0)
            ax.set_axis_off()
            if r == 0:
                ax.set_title(label, fontsize=10)
            col += 1
    plt.tight_layout()
    plt.savefig(os.path.join(OUT, "fig_pcn8_qualitative.png"), dpi=150)
    plt.close()
    print("[saved] fig_pcn8_qualitative.png")


def main():
    reports = load_reports()
    print("available reports:", list(reports))
    gen_tables(reports)
    gen_cdl1_bars(reports)
    gen_curves()
    gen_qualitative(reports)
    print("ASSETS_DONE")


if __name__ == "__main__":
    main()
