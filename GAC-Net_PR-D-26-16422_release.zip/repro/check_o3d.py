# -*- coding: utf-8 -*-
import sys
try:
    import open3d as o3d
    print("open3d OK", o3d.__version__)
    pc = o3d.io.read_point_cloud("/root/autodl-tmp/PCN_snow/test/partial/03001627/IKEA_JOKKMOKK.pcd")
    import numpy as np
    pts = np.asarray(pc.points)
    print("pcd read OK", pts.shape, pts.dtype, "range", pts.min(), pts.max())
except Exception as e:
    print("FAIL:", repr(e))
    sys.exit(1)
print("CHECK_DONE")
