"""CPU 冒烟测试：验证基线仓库配置 -> 数据集加载 -> 模型构建 全链路（不碰 GPU）。

用法: python /root/smoke_baseline.py <repo_dir> <model_yaml>
"""
import os
import sys
import argparse

repo, cfgp = sys.argv[1], sys.argv[2]
os.chdir(repo)
sys.path.insert(0, repo)

from utils.config import cfg_from_yaml_file
from tools import builder

args = argparse.Namespace(distributed=False, launcher='none',
                          num_workers=0, local_rank=0)
cfg = cfg_from_yaml_file(cfgp)

_, test_loader = builder.dataset_builder(args, cfg.dataset.test)
n = len(test_loader.dataset)
tids, mids, data = next(iter(test_loader))
print('TEST_SAMPLES', n)
print('SAMPLE', tids, mids, tuple(data[0].shape))
if len(data) > 1:
    print('GT_SHAPE', tuple(data[1].shape))

model = builder.model_builder(cfg.model)
print('MODEL_OK', type(model).__name__)
print('SMOKE_PASS', repo)
