cd /root/image_guided_pc_completion/data/shapenet8/splits
for s in 02691156 02933112 02958343 03001627 03636649 04256520 04379243 04530566; do
  tr=$(grep -c $s train.txt)
  te=$(grep -c $s test.txt)
  echo "$s $tr $te"
done
