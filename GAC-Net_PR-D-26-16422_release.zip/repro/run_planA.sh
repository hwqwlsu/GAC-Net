#!/bin/bash
# 方案 A 主链：SnowflakeNet 50ep → full_w0 50ep → noanchor_50 50ep → 统一评估 → 生成表格
# 所有方法统一 50 epoch 预算，w_view=0
cd /root/image_guided_pc_completion
PY=/root/miniconda3/bin/python
SNOW=/root/miniconda3/envs/snowflake/bin/python
PRED=/root/autodl-tmp/pc_predictions
LOG=/root/chain_planA.log

keep_v0 () { find "$1" -name '*.npy' ! -name '*__v0.npy' -delete; }

echo "=== [0/8] 等待 SnowflakeNet 训练结束 ===" | tee -a $LOG
# 雪花链结束标志：/root/snow_chain.log 出现 SNOW_CHAIN_DONE
while ! grep -q "SNOW_CHAIN_DONE" /root/snow_chain.log 2>/dev/null; do
  # 但如果 snow_chain 本身失败（SNOW_CHAIN_FAILED），也停下
  if grep -q "SNOW_CHAIN_FAILED" /root/snow_chain.log 2>/dev/null; then
    echo "SNOW_CHAIN_FAILED: snowflake 链先失败了，中止方案 A" | tee -a $LOG
    exit 1
  fi
  sleep 120
done
echo "snowflake 基线就绪 at $(date)" | tee -a $LOG

# snow 预测已由 snow_chain 完成，跳过

echo "=== [1/8] full_w0 训练 50ep ===" | tee -a $LOG
$PY train.py --config configs/pcn8_full_w0.json 2>&1 | tail -3 | tee -a $LOG
echo "full_w0 train exit=$?" | tee -a $LOG

echo "=== [2/8] full_w0 预测+评估 ===" | tee -a $LOG
$PY predict.py --ckpt experiments/gacnet_pcn8_fullw0/best_model.pth --out $PRED/gacnet_fullw0 --split test 2>&1 | tail -2 | tee -a $LOG
keep_v0 $PRED/gacnet_fullw0
ln -sfn $PRED/gacnet_fullw0 predictions/gacnet_fullw0
$PY tools/eval_predictions.py --pred_root predictions --data_root data/shapenet8 --split test --methods gacnet_fullw0 2>&1 | tail -5 | tee -a $LOG

echo "=== [3/8] noanchor_50 训练 50ep ===" | tee -a $LOG
$PY train.py --config configs/pcn8_noanchor_50.json 2>&1 | tail -3 | tee -a $LOG
echo "noanchor_50 train exit=$?" | tee -a $LOG

echo "=== [4/8] noanchor_50 预测+评估 ===" | tee -a $LOG
$PY predict.py --ckpt experiments/gacnet_pcn8_noanchor50/best_model.pth --out $PRED/noanchor_50 --split test 2>&1 | tail -2 | tee -a $LOG
keep_v0 $PRED/noanchor_50
ln -sfn $PRED/noanchor_50 predictions/noanchor_50
$PY tools/eval_predictions.py --pred_root predictions --data_root data/shapenet8 --split test --methods noanchor_50 2>&1 | tail -5 | tee -a $LOG

# point_only 已评估过，只需要把旧的评估结果移到新命名（或直接用旧的）
# 但 predictions/ 已被清理，需要重新软链 + 重新评估
echo "=== [5/8] point_only 重评估 ===" | tee -a $LOG
# point_only 预测文件在数据盘上应该还在（之前软链被删，但数据盘文件未删）
if [ -d $PRED/pointonly_pcn8 ]; then
  ln -sfn $PRED/pointonly_pcn8 predictions/pointonly_pcn8
else
  echo "pointonly 数据盘文件丢失，需重训" | tee -a $LOG
  $PY train.py --config configs/pcn8_pointonly.json 2>&1 | tail -3 | tee -a $LOG
  $PY predict.py --ckpt experiments/gacnet_pcn8_pointonly/best_model.pth --out $PRED/pointonly_pcn8 --split test 2>&1 | tail -2 | tee -a $LOG
  keep_v0 $PRED/pointonly_pcn8
  ln -sfn $PRED/pointonly_pcn8 predictions/pointonly_pcn8
fi
$PY tools/eval_predictions.py --pred_root predictions --data_root data/shapenet8 --split test --methods pointonly_pcn8 2>&1 | tail -5 | tee -a $LOG

echo "=== [6/8] full_w0 vs old_full 对照 ===" | tee -a $LOG
# 旧 full 模型如果要对比，需要先重评估
if [ -f experiments/gacnet_pcn8/best_model.pth ]; then
  $PY predict.py --ckpt experiments/gacnet_pcn8/best_model.pth --out $PRED/gacnet_oldfull --split test 2>&1 | tail -2 | tee -a $LOG
  keep_v0 $PRED/gacnet_oldfull
  ln -sfn $PRED/gacnet_oldfull predictions/gacnet_oldfull
  $PY tools/eval_predictions.py --pred_root predictions --data_root data/shapenet8 --split test --methods gacnet_oldfull 2>&1 | tail -5 | tee -a $LOG
fi

echo "=== [7/8] 汇总全部方法指标 ===" | tee -a $LOG
for m in gacnet_fullw0 pointonly_pcn8 noanchor_50 snowflakenet_pcn8 gacnet_oldfull; do
  f=results/prediction_metrics/$m.json
  if [ -f "$f" ]; then
    echo "--- $m ---" | tee -a $LOG
    $PY -c "
import json
d = json.load(open('$f'))
o = d.get('overall', d)
n = o.get('n', 1)
print('  n=%d CD-L1=%.2f CD-L2=%.4f F@0.01=%.4f F@0.02=%.4f' % (n, o.get('CD_L1_x1e4',0), o.get('CD_L2_x1e4',0), o.get('Fscore@0.01',0), o.get('Fscore@0.02',0)))
" 2>/dev/null | tee -a $LOG
  else
    echo "--- $m MISSING ---" | tee -a $LOG
  fi
done

echo "=== [8/8] 磁盘清理（删除临时预测目录） ===" | tee -a $LOG
rm -rf $PRED/gacnet_oldfull
df -h / /root/autodl-tmp | tail -2 | tee -a $LOG

echo "PLANA_DONE $(date)" | tee -a $LOG
