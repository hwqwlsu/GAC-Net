# -*- coding: utf-8 -*-
"""SnowflakeNet(completion 链路) 预测导出。
对 PCN_snow/test 全部视角推理，保存最细尺度输出为
<out>/<syn>/<model>__v<view>.pcd（ASCII），供 tools/baselines/collect_predictions.py 归位。
测试时输入重采样复刻官方 UpSamplePoints（FPS 到随机 512-1024 再补到 2048），
固定种子保证可复现。"""
import argparse
import glob
import os
import random
import sys

import numpy as np
import torch

sys.path.insert(0, "/root/SnowflakeNet/completion")
from core import builder  # noqa: E402
from utils import yaml_reader  # noqa: E402


def farthest_point_sample(point, npoint):
    N, D = point.shape
    xyz = point[:, :3]
    centroids = np.zeros((npoint,))
    distance = np.ones((N,)) * 1e10
    farthest = np.random.randint(0, N)
    for i in range(npoint):
        centroids[i] = farthest
        centroid = xyz[farthest, :]
        dist = np.sum((xyz - centroid) ** 2, -1)
        mask = dist < distance
        distance[mask] = dist[mask]
        farthest = np.argmax(distance, -1)
    return point[centroids.astype(np.int32)]


def upsample_to(ptcloud, n_points):
    n_valid = random.randint(512, 1024)
    ptcloud = farthest_point_sample(ptcloud, n_valid)
    curr = ptcloud.shape[0]
    need = n_points - curr
    if need < 0:
        return ptcloud[np.random.permutation(n_points)]
    while curr <= need:
        ptcloud = np.tile(ptcloud, (2, 1))
        need -= curr
        curr *= 2
    choice = np.random.permutation(need)
    return np.concatenate((ptcloud, ptcloud[choice]))


def read_pcd(path):
    import open3d as o3d
    return np.asarray(o3d.io.read_point_cloud(path).points, dtype=np.float32)


def write_pcd_ascii(path, pts):
    with open(path, "w") as f:
        f.write("# .PCD v0.7 - Point Cloud Data file format\n")
        f.write("VERSION 0.7\nFIELDS x y z\nSIZE 4 4 4\nTYPE F F F\nCOUNT 1 1 1\n")
        f.write("WIDTH %d\nHEIGHT 1\nVIEWPOINT 0 0 0 1 0 0 0\nPOINTS %d\nDATA ascii\n"
                % (pts.shape[0], pts.shape[0]))
        for p in pts:
            f.write("%.6f %.6f %.6f\n" % (p[0], p[1], p[2]))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--src_root", default="/root/autodl-tmp/PCN_snow/test/partial")
    ap.add_argument("--out", default="/root/autodl-tmp/snow_pred")
    args = ap.parse_args()

    random.seed(0)
    np.random.seed(0)
    torch.manual_seed(0)
    torch.cuda.manual_seed_all(0)

    config = yaml_reader.read_yaml(args.config)
    model = builder.make_model(config)
    model = torch.nn.DataParallel(model).cuda()
    ckpt = torch.load(args.ckpt, map_location="cuda", weights_only=False)
    model.load_state_dict(ckpt["model"])
    model.eval()
    print("ckpt loaded:", args.ckpt, "epoch:", ckpt.get("epoch_index"), flush=True)

    n_done = 0
    printed_shape = False
    for syn in sorted(os.listdir(args.src_root)):
        pdir = os.path.join(args.src_root, syn)
        for model_id in sorted(os.listdir(pdir)):
            mdir = os.path.join(pdir, model_id)
            if not os.path.isdir(mdir):
                continue
            for vf in sorted(glob.glob(os.path.join(mdir, "*.pcd"))):
                view = int(os.path.splitext(os.path.basename(vf))[0])
                pts = read_pcd(vf)
                pts = upsample_to(pts, config.dataset.n_points)
                inp = torch.from_numpy(np.ascontiguousarray(pts)).unsqueeze(0).float().cuda()
                with torch.no_grad():
                    preds = model(inp)
                out = preds[-1][0].detach().cpu().numpy().astype(np.float32)
                if not printed_shape:
                    print("pred shape:", out.shape, flush=True)
                    printed_shape = True
                odir = os.path.join(args.out, syn)
                os.makedirs(odir, exist_ok=True)
                write_pcd_ascii(os.path.join(odir, "%s__v%d.pcd" % (model_id, view)), out)
                n_done += 1
            print("model done:", syn, model_id, flush=True)
    print("total preds:", n_done)
    print("PREDICT_DONE")


main()
