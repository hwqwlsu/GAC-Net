# -*- coding: utf-8 -*-
"""Fig.1 流水线总览：深度视图 -> partial cloud + RGB -> GAC-Net -> completed cloud + 视角一致性回投。"""
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

OUT = "/root/autodl-tmp/paper_figures"
os.makedirs(OUT, exist_ok=True)

fig, ax = plt.subplots(figsize=(13, 4.2))
ax.set_xlim(0, 13); ax.set_ylim(0, 4.2)
ax.axis("off")

def box(x, y, w, h, text, fc, ec="#333", fontsize=9):
    p = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.04",
                       fc=fc, ec=ec, lw=1.3)
    ax.add_patch(p)
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center",
            fontsize=fontsize, wrap=True)

def arrow(x1, y1, x2, y2):
    a = FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>",
                        mutation_scale=14, color="#444", lw=1.4)
    ax.add_patch(a)

# Inputs
box(0.2, 2.7, 2.2, 1.1, "RGB image I\n(ResNet-18 tokens)", "#e8f1ff")
box(0.2, 0.8, 2.2, 1.1, "Partial cloud P\n(depth back-projection)\n(2048 pts)", "#fff4e6")
ax.text(1.3, 4.05, "Calibrated RGB-D view", ha="center", fontsize=10, style="italic")

# Encoders
box(3.0, 2.8, 1.8, 0.9, "Image encoder\nResNet-18", "#dce9ff")
box(3.0, 0.9, 1.8, 0.9, "Point encoder\nPointNet++", "#ffe8d6")
arrow(2.4, 3.25, 3.0, 3.25)
arrow(2.4, 1.35, 3.0, 1.35)

# GACA
box(5.4, 1.8, 2.2, 1.3, "GACA\nGeometry-Anchored\nCross-modal Attention", "#f3e8ff", fontsize=9)
arrow(4.8, 3.25, 5.4, 2.7)
arrow(4.8, 1.35, 5.4, 2.2)
ax.text(6.5, 3.35, "camera π(K,T)\nGaussian bias", ha="center", fontsize=8, color="#7a3db8")

# Decoder
box(8.2, 1.8, 1.8, 1.3, "Coarse-to-fine\ndecoder\n(snowflake split)", "#e6ffe8")
arrow(7.6, 2.45, 8.2, 2.45)

# Output
box(10.6, 1.8, 2.2, 1.3, "Completed cloud\nŶ (16384 pts)", "#e8fff5")
arrow(10.0, 2.45, 10.6, 2.45)

# View-consistency loop
box(5.4, 0.1, 7.4, 0.9, "View-consistency loss  L_view = L_sil + 0.5·L_dep   (soft splat reprojection of Ŷ into input view)",
    "#fff9e6", fontsize=8.5)
arrow(11.7, 1.8, 11.7, 1.0, )
arrow(11.7, 1.0, 12.8, 1.0)
arrow(12.8, 1.0, 12.8, 0.55)
ax.annotate("", xy=(5.4, 0.55), xytext=(12.8, 0.55),
            arrowprops=dict(arrowstyle="-|>", color="#c08a00", lw=1.4))
ax.text(9.1, 0.0, "reproject Ŷ → silhouette + depth", ha="center", fontsize=7.5, color="#9a6b00")

# Chamfer loss
ax.text(9.1, 3.5, "+ Chamfer-L1 (coarse + fine)", ha="center", fontsize=9, color="#2a7a2a")

plt.tight_layout()
plt.savefig(os.path.join(OUT, "fig1_pipeline.png"), bbox_inches="tight", dpi=300)
plt.close()
print("saved fig1_pipeline.png")
print("PIPE_DONE")
