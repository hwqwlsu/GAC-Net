#!/bin/bash
# 修正：文件被命名为 "ShapeNetCore_zips\syn.zip" 放在 /root/autodl-tmp/ 下
cd /root/autodl-tmp
mkdir -p ShapeNetCore_zips
for f in ShapeNetCore_zips\\*.zip; do
    [ -e "$f" ] || continue
    syn="${f#ShapeNetCore_zips\\}"
    mv "$f" "ShapeNetCore_zips/$syn"
    echo "moved: $f -> ShapeNetCore_zips/$syn"
done
ls -la ShapeNetCore_zips/
