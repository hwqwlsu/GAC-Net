#!/usr/bin/env bash
# run_baseline_chain.sh — 等 planA 链结束后，自动串行执行 PoinTr / AnchorFormer 基线
# 启动方式: nohup bash /root/run_baseline_chain.sh > /root/chain_baselines.log 2>&1 < /dev/null &
# 完成标志: /root/chain_baselines.log 出现 BASELINE_CHAIN_DONE
set -u

WORKSPACE="/root/image_guided_pc_completion"
PLANA_LOG="/root/chain_planA.log"
PRED_LOG="/root/pointr_run.log"
AF_LOG="/root/anchorformer_run.log"
POLL_SEC=300        # 5 分钟轮询一次
STALE_SEC=1800      # planA 日志 30 分钟无更新且无进程 → 判定崩溃

log() { echo "[$(date '+%F %T')] $*"; }

log "=== 基线串联链启动，等待 planA 完成（PLANA_DONE） ==="

while true; do
    if grep -q "PLANA_DONE" "$PLANA_LOG" 2>/dev/null; then
        log "检测到 PLANA_DONE，planA 链已完成，开始基线"
        break
    fi
    if ! pgrep -f "run_planA" >/dev/null 2>&1; then
        NOW=$(date +%s)
        MTIME=$(stat -c %Y "$PLANA_LOG" 2>/dev/null || echo "$NOW")
        AGE=$(( NOW - MTIME ))
        if [ "$AGE" -gt "$STALE_SEC" ]; then
            log "[ABORT] planA 进程不在且日志已 ${AGE}s 未更新，疑似崩溃，退出"
            echo "BASELINE_CHAIN_ABORTED plana_crash"
            exit 1
        fi
        log "[warn] 未检测到 run_planA 进程，但日志 ${AGE}s 前仍有更新，继续等待"
    fi
    sleep "$POLL_SEC"
done

log "=== [1/2] PoinTr 基线开始，日志: $PRED_LOG ==="
bash "$WORKSPACE/tools/baselines/run_pointr.sh" > "$PRED_LOG" 2>&1
POINTR_RC=$?
log "PoinTr 退出码: $POINTR_RC"
echo "POINTR_STAGE_DONE rc=$POINTR_RC"

log "=== [2/2] AnchorFormer 基线开始，日志: $AF_LOG ==="
bash "$WORKSPACE/tools/baselines/run_anchorformer.sh" > "$AF_LOG" 2>&1
AF_RC=$?
log "AnchorFormer 退出码: $AF_RC"
echo "ANCHORFORMER_STAGE_DONE rc=$AF_RC"

log "=== 汇总 ==="
log "pointr_rc=$POINTR_RC anchorformer_rc=$AF_RC"
echo "BASELINE_CHAIN_DONE pointr_rc=$POINTR_RC anchorformer_rc=$AF_RC"
