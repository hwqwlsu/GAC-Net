import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

cats = ["airplane", "cabinet", "car", "chair", "lamp", "sofa", "table", "watercraft"]
train = [3411, 1328, 2964, 5740, 1976, 2690, 7208, 1667]
test = [1680, 632, 1344, 2736, 968, 1288, 3392, 776]
colors = ["#4C72B0", "#DD8452", "#55A467", "#C44E52",
          "#8172B2", "#937860", "#DA8BC3", "#8C8C8C"]

fig, ax = plt.subplots(figsize=(9, 4.2))
x = np.arange(len(cats))
w = 0.38
ax.bar(x - w/2, train, w, label="train", color="#4C72B0", edgecolor="white")
ax.bar(x + w/2, test, w, label="test", color="#DD8452", edgecolor="white")
for i, (t, te) in enumerate(zip(train, test)):
    ax.text(i - w/2, t + 80, str(t), ha="center", va="bottom", fontsize=8)
    ax.text(i + w/2, te + 80, str(te), ha="center", va="bottom", fontsize=8)
ax.set_xticks(x)
ax.set_xticklabels(cats, rotation=20, ha="right")
ax.set_ylabel("Number of models")
ax.set_title("PCN-8 dataset split (ShapeNetCore v2)")
ax.legend(frameon=False)
ax.spines[["top", "right"]].set_visible(False)
ax.set_ylim(0, 8200)
plt.tight_layout()
plt.savefig("/root/fig_dataset_stats.png", dpi=150)
print("saved fig_dataset_stats.png")
