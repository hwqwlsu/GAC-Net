# -*- coding: utf-8 -*-
import os
p = "/root/autodl-tmp/PCN_snow/test/partial/03001627"
items = sorted(os.listdir(p))
print("total:", len(items))
for it in items[:8]:
    full = os.path.join(p, it)
    print(("DIR " if os.path.isdir(full) else "FILE"), it)
pc = "/root/autodl-tmp/PCN/test/partial/03001627"
items2 = sorted(os.listdir(pc))
print("src total:", len(items2))
for it in items2[:8]:
    print("SRC", it)
