#!/bin/bash
# 善后看门狗：等待恢复链结束（chain_recovery.log 中第二个 RECOVERY_DONE，第一个是 12:12 误启动残留）
# 然后补跑被 run_recovery.sh 自毁 bug（rm -rf predictions/$M + ln -sfn 自引用）影响的两个 GAC-Net 方法
cd /root/image_guided_pc_completion
PY=/root/miniconda3/bin/python
PRED=/root/autodl-tmp/pc_predictions
LOG=/root/recovery_logs/late_fix.log
{
  until [ $(grep -c 'RECOVERY_DONE' /root/chain_recovery.log) -ge 2 ] && ! pgrep -f 'train.py|predict.py' >/dev/null; do
    sleep 300
  done
  echo "chain done, late fix start $(date)"
  df -h /root/autodl-tmp | tail -1

  # 1) 训练已结束，train.py 的验证转储只剩 v0 有价值，清掉其余视角释放约 2.1G
  find $PRED/gacnet_noanchor50 -name '*.npy' ! -name '*__v0.npy' -delete 2>/dev/null
  echo "cleaned gacnet_noanchor50 non-v0 dumps"
  df -h /root/autodl-tmp | tail -1

  # 2) noanchor_50：链路的 rm+ln 自毁会留下悬空自引用链接，先摘除再按需补跑
  if [ -L $PRED/noanchor_50 ]; then rm -f $PRED/noanchor_50; echo "removed dangling noanchor_50 symlink"; fi
  n=$(ls $PRED/noanchor_50/*__v0.npy 2>/dev/null | wc -l)
  echo "noanchor_50 v0 files: $n"
  if [ "$n" -lt 100 ]; then
    $PY predict.py --ckpt experiments/gacnet_pcn8_noanchor50/best_model.pth --out $PRED/noanchor_50 --split test
    echo "noanchor_50 predict rc=$? $(date)"
    find $PRED/noanchor_50 -name '*.npy' ! -name '*__v0.npy' -delete
  fi
  $PY tools/eval_predictions.py --pred_root predictions --data_root data/shapenet8 --split test --methods noanchor_50 > /root/recovery_logs/noanchor_50_eval2.log 2>&1
  echo "noanchor_50 eval rc=$? $(date)"
  tail -5 /root/recovery_logs/noanchor_50_eval2.log

  # 3) gacnet_fullw0：链路预测阶段因当时目录是死链而失败，补跑
  if [ -L $PRED/gacnet_fullw0 ]; then rm -f $PRED/gacnet_fullw0; echo "removed dangling gacnet_fullw0 symlink"; fi
  m=$(ls $PRED/gacnet_fullw0/*__v0.npy 2>/dev/null | wc -l)
  echo "gacnet_fullw0 v0 files: $m"
  if [ "$m" -lt 100 ]; then
    $PY predict.py --ckpt experiments/gacnet_pcn8_fullw0/best_model.pth --out $PRED/gacnet_fullw0 --split test
    echo "gacnet_fullw0 predict rc=$? $(date)"
    find $PRED/gacnet_fullw0 -name '*.npy' ! -name '*__v0.npy' -delete
  fi
  $PY tools/eval_predictions.py --pred_root predictions --data_root data/shapenet8 --split test --methods gacnet_fullw0 > /root/recovery_logs/gacnet_fullw0_eval2.log 2>&1
  echo "gacnet_fullw0 eval rc=$? $(date)"
  tail -5 /root/recovery_logs/gacnet_fullw0_eval2.log

  echo "LATE_FIX_DONE $(date)"
} > $LOG 2>&1
