# -*- coding: utf-8 -*-
"""定性对比图：对同一组 Pix3D 椅子模型，并排渲染 partial / GT / GAC-Net / point-only / SnowflakeNet。
使用真实预测文件，无虚构。"""
import os, glob
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D  # noqa

ROOT = "/root/image_guided_pc_completion"
PRED = os.path.join(ROOT, "predictions")
DATA = os.path.join(ROOT, "data/pix3d_dev")
OUT = "/root/autodl-tmp/paper_figures"

models = ["IKEA_JOKKMOKK", "SS_001", "SS_047"]
syn = "03001627"
view = 0

def load_npy(path):
    return np.load(path)

def render(ax, pts, title, elev=20, azim=45):
    ax.scatter(pts[:, 0], pts[:, 1], pts[:, 2], s=0.3, c=pts[:, 2], cmap="viridis", alpha=0.8)
    ax.set_title(title, fontsize=9)
    ax.set_xlim(-0.5, 0.5); ax.set_ylim(-0.5, 0.5); ax.set_zlim(-0.5, 0.5)
    ax.view_init(elev=elev, azim=azim)
    ax.set_xticks([]); ax.set_yticks([]); ax.set_zticks([])

# find GT and partial paths
def find_gt_partial(model, view):
    gt = os.path.join(DATA, "pcd/test/complete", syn, f"{model}.npy")
    pt = os.path.join(DATA, "pcd/test/partial", syn, f"{model}__v{view}.npy")
    return gt, pt

cols = ["Partial", "GT", "GAC-Net", "Point-only", "SnowflakeNet"]
methods = ["gacnet_pix3d", "pointonly_pix3d", "snowflake_pix3d"]

fig, axes = plt.subplots(len(models), 5, figsize=(12, 2.6 * len(models)),
                         subplot_kw={"projection": "3d"})
for i, model in enumerate(models):
    gt_path, pt_path = find_gt_partial(model, view)
    gt = load_npy(gt_path)
    pt = load_npy(pt_path)
    render(axes[i, 0], pt, f"{model}\n{cols[0]}")
    render(axes[i, 1], gt, cols[1])
    for j, m in enumerate(methods):
        p = os.path.join(PRED, m, syn, f"{model}__v{view}.npy")
        pred = load_npy(p)
        render(axes[i, 2 + j], pred, cols[2 + j])
plt.tight_layout()
plt.savefig(os.path.join(OUT, "fig_qualitative_pix3d.png"), bbox_inches="tight")
plt.close()
print("saved fig_qualitative_pix3d.png")
print("QUAL_DONE")
