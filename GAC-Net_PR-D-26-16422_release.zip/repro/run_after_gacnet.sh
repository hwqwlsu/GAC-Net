#!/bin/bash
# GAC-Net 训练完成后的全流程：预测+评估 -> point_only训练+评估 -> SnowflakeNet训练+评估 -> 出图表
set -e
cd /root/image_guided_pc_completion
PY=/root/miniconda3/bin/python
SNOW=/root/miniconda3/envs/snowflake/bin/python

echo "=== [1/8] GAC-Net predict test (view 0) ==="
$PY predict.py --ckpt experiments/gacnet_pcn8/best_model.pth \
    --out predictions/gacnet_pcn8 --split test 2>&1 | tail -3

echo "=== [2/8] eval GAC-Net ==="
$PY tools/eval_predictions.py --pred_root predictions --data_root data/shapenet8/pcd \
    --split test --methods gacnet_pcn8 2>&1 | tail -8

echo "=== [3/8] train point_only (50 ep) ==="
$PY train.py --config configs/pcn8_pointonly.json 2>&1 | tail -3

echo "=== [4/8] point_only predict + eval ==="
$PY predict.py --ckpt experiments/gacnet_pcn8_pointonly/best_model.pth \
    --out predictions/pointonly_pcn8 --split test 2>&1 | tail -3
$PY tools/eval_predictions.py --pred_root predictions --data_root data/shapenet8/pcd \
    --split test --methods gacnet_pcn8 pointonly_pcn8 2>&1 | tail -8

echo "=== [5/8] train SnowflakeNet (50 ep) ==="
cd /root/SnowflakeNet/completion
$SNOW train.py --config configs/pcn8.yaml 2>&1 | tail -3

echo "=== [6/8] SnowflakeNet predict (view 0 only) + collect ==="
SN_CKPT=$(ls -t /root/autodl-tmp/snow_exp/pcn8/ckpt*.pth 2>/dev/null | head -1)
echo "snow ckpt: $SN_CKPT"
$SNOW predict_dump_snow.py --config configs/pcn8.yaml --ckpt "$SN_CKPT" \
    --src_root /root/autodl-tmp/PCN8_snow/test/partial --views 0 \
    --out /root/autodl-tmp/snow_pred_pcn8 2>&1 | tail -3
cd /root/image_guided_pc_completion
$PY tools/baselines/collect_predictions.py \
    --src /root/autodl-tmp/snow_pred_pcn8 --method snowflakenet_pcn8 \
    --split_file data/shapenet8/splits/test.txt --ext pcd --strict 2>&1 | tail -4

echo "=== [7/8] final eval (3 methods) ==="
$PY tools/eval_predictions.py --pred_root predictions --data_root data/shapenet8/pcd \
    --split test --methods gacnet_pcn8 pointonly_pcn8 snowflakenet_pcn8 2>&1 | tail -12

echo "=== [8/8] generate figures + tables ==="
$SNOW /root/make_pcn8_assets.py 2>&1 | tail -8

echo "ALL_DONE"
