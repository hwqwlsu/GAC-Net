#!/bin/bash
source /root/miniconda3/etc/profile.d/conda.sh
conda activate snowflake
export TORCH_CUDA_ARCH_LIST="9.0+PTX"
rm -rf /root/SnowflakeNet/models/pointnet2_ops_lib/build
cd /root/SnowflakeNet/models/pointnet2_ops_lib
python setup.py install > /root/build_pn2.log 2>&1
echo "PN2_RC=$?"
cd /root/SnowflakeNet/loss_functions/Chamfer3D
rm -rf build
python setup.py install > /root/build_cd.log 2>&1
echo "CD_RC=$?"
cd /root/SnowflakeNet/loss_functions/emd
rm -rf build
python setup.py install > /root/build_emd.log 2>&1
echo "EMD_RC=$?"
python -c "import pointnet2_ops; print('pn2 import ok')" 2>&1 | tail -1
echo BUILD_ALL_DONE
