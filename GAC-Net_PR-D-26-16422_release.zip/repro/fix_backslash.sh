#!/bin/bash
# 修正 Windows 反斜杠导致的文件名问题
cd /root/autodl-tmp/ShapeNetCore_zips
for f in *\\*.zip; do
    [ -e "$f" ] || continue
    new="${f//\\//}"
    mkdir -p "$(dirname "$new")"
    mv "$f" "$new"
    echo "renamed: $f -> $new"
done
ls -la
