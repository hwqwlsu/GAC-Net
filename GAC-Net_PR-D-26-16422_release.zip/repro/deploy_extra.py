# -*- coding: utf-8 -*-
"""一次性部署：把 A/B/C 扩展实验所需脚本写入服务器，校验语法，启动链式 watcher。"""
import os
import sys
import warnings

warnings.filterwarnings("ignore")
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

import paramiko

HOST, PORT, USER, PWD = "connect.westb.seetacloud.com", 23326, "root", "yuk4EGNx2TKK"
PROJ = "/root/image_guided_pc_completion"

FILES = {}

FILES["configs/pcn8_noanchor.json"] = '''{
  "experiment": "gacnet_pcn8_noanchor",
  "dataset": "shapenet55",
  "data_root": "data/shapenet8",
  "point_only": false,
  "view_id": 0,
  "pre_normalized": true,
  "n_partial": 2048,
  "n_complete": 16384,
  "image_size": 224,
  "model": {
    "dim": 256,
    "n_seed": 256,
    "up_factors": [8, 8],
    "pretrained_image": true,
    "num_heads": 4,
    "n_l1": 512,
    "k_group": 16,
    "geo_anchor": false
  },
  "loss": {"w_coarse": 1.0, "w_fine": 1.0, "w_view": 0.05},
  "epochs": 30,
  "batch_size": 8,
  "num_workers": 8,
  "lr": 0.0002,
  "weight_decay": 0.0001,
  "grad_clip": 1.0,
  "scheduler": "cosine",
  "warmup_epochs": 5,
  "amp": true,
  "seed": 42,
  "val_every": 10,
  "out_dir": "experiments/gacnet_pcn8_noanchor"
}
'''

FILES["configs/pcn8_nolview.json"] = '''{
  "experiment": "gacnet_pcn8_nolview",
  "dataset": "shapenet55",
  "data_root": "data/shapenet8",
  "point_only": false,
  "view_id": 0,
  "pre_normalized": true,
  "n_partial": 2048,
  "n_complete": 16384,
  "image_size": 224,
  "model": {
    "dim": 256,
    "n_seed": 256,
    "up_factors": [8, 8],
    "pretrained_image": true,
    "num_heads": 4,
    "n_l1": 512,
    "k_group": 16
  },
  "loss": {"w_coarse": 1.0, "w_fine": 1.0, "w_view": 0.0},
  "epochs": 30,
  "batch_size": 8,
  "num_workers": 8,
  "lr": 0.0002,
  "weight_decay": 0.0001,
  "grad_clip": 1.0,
  "scheduler": "cosine",
  "warmup_epochs": 5,
  "amp": true,
  "seed": 42,
  "val_every": 10,
  "out_dir": "experiments/gacnet_pcn8_nolview"
}
'''

FILES["tools/gen_shadow_degrade.py"] = '''# -*- coding: utf-8 -*-
"""生成 3 个图像退化影子数据集（blur2/noise05/gray）：
每目录 = test 的 renders 退化副本 + pcd/cams/splits/depth 符号链接。
"""
import os
import numpy as np
from PIL import Image, ImageFilter

ROOT = "/root/image_guided_pc_completion"
SRC = os.path.join(ROOT, "data", "shapenet8")
TAGS = ["blur2", "noise05", "gray"]

with open(os.path.join(SRC, "splits", "test.txt")) as f:
    rels = [ln.strip()[:-4] for ln in f if ln.strip()]

def out_root(tag):
    return os.path.join(ROOT, "data", "shapenet8_" + tag)

for tag in TAGS:
    d = out_root(tag)
    os.makedirs(d, exist_ok=True)
    for sub in ["pcd", "cams", "splits", "depth"]:
        tgt = os.path.join(d, sub)
        if not os.path.exists(tgt):
            os.symlink(os.path.join(SRC, sub), tgt)

n = 0
for i, rel in enumerate(rels):
    src = os.path.join(SRC, "renders", rel + ".png")
    if not os.path.exists(src):
        print("[missing]", rel)
        continue
    img = Image.open(src).convert("RGB")
    for tag in TAGS:
        dst = os.path.join(out_root(tag), "renders", rel + ".png")
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        if tag == "blur2":
            img.filter(ImageFilter.GaussianBlur(2)).save(dst)
        elif tag == "gray":
            img.convert("L").convert("RGB").save(dst)
        else:
            a = np.asarray(img, np.float32) + np.random.default_rng(i).normal(
                0, 12.75, (img.height, img.width, 3)).astype(np.float32)
            Image.fromarray(np.clip(a, 0, 255).astype(np.uint8)).save(dst)
    n += 1
print("[degrade] processed", n, "images x", len(TAGS), "degradations")
'''

FILES["tools/viz_stage.py"] = '''# -*- coding: utf-8 -*-
"""过程化重建可视化：partial(2048) -> coarse(256) -> stage1(2048) -> fine(16384) -> GT。"""
import os
import sys
import numpy as np
import torch
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from torch.utils.data import DataLoader

ROOT = "/root/image_guided_pc_completion"
sys.path.insert(0, ROOT)
from pcic.data import build_dataset  # noqa: E402
from pcic.models import GACNet  # noqa: E402

CKPT = os.path.join(ROOT, "experiments/gacnet_pcn8/best_model.pth")
WANT = {"02691156": "airplane", "03001627": "chair", "03636649": "lamp"}
dev = "cuda"

ck = torch.load(CKPT, map_location=dev, weights_only=False)
cfg = ck["config"]
ds = build_dataset(cfg, "test")
loader = DataLoader(ds, batch_size=1, shuffle=False, num_workers=2)
model = GACNet(**cfg["model"]).to(dev)
model.load_state_dict(ck["model"])
model.eval()
mid_holder = {}
model.decoder.split1.register_forward_hook(
    lambda m, i, o: mid_holder.__setitem__("mid", o[0].detach()))

def cid_of(rel):
    return rel[:-4] if rel.endswith(".npy") else rel

targets = {}
for i, rel in enumerate(ds.rels):
    syn = cid_of(rel).split("/")[0]
    if syn in WANT and syn not in targets:
        targets[syn] = i
    if len(targets) == len(WANT):
        break

batches = {}
for j, b in enumerate(loader):
    if j in targets.values():
        batches[j] = b
    if len(batches) == len(targets):
        break

rows = []
for syn, idx in targets.items():
    b = batches[idx]
    bb = {k: (v.to(dev) if torch.is_tensor(v) else v) for k, v in b.items()}
    with torch.no_grad():
        out = model(bb)
    cid = cid_of(ds.rels[idx])
    part = np.load(os.path.join(ROOT, "data/shapenet8/pcd/test/partial", cid + ".npy"))
    gt = np.load(os.path.join(ROOT, "data/shapenet8/pcd/test/complete",
                              cid.split("__v")[0] + ".npy"))
    rows.append((WANT[syn], part, out["coarse"][0].cpu().numpy(),
                 mid_holder["mid"][0].cpu().numpy(),
                 out["fine"][0].cpu().numpy(), gt))

cols = ["Input (2048)", "Coarse (256)", "Stage-1 (2048)", "Fine (16384)", "GT"]
fig = plt.figure(figsize=(15, 3 * len(rows)))
for r, row in enumerate(rows):
    for c, pts in enumerate(row[1:]):
        ax = fig.add_subplot(len(rows), 5, r * 5 + c + 1, projection="3d")
        s = pts[::max(1, len(pts) // 1200)]
        ax.scatter(s[:, 0], s[:, 2], -s[:, 1], s=1.2, c=s[:, 2],
                   cmap="viridis", linewidth=0)
        ax.set_axis_off()
        if r == 0:
            ax.set_title(cols[c], fontsize=10)
os.makedirs(os.path.join(ROOT, "paper_assets"), exist_ok=True)
plt.tight_layout()
plt.savefig(os.path.join(ROOT, "paper_assets", "fig_stagewise.png"), dpi=150)
print("[saved] fig_stagewise.png")
'''

FILES["tools/viz_bias.py"] = '''# -*- coding: utf-8 -*-
"""GACA 几何锚定偏置可视化：FPS 采样点投影回输入视角，画 bias 热场叠加。"""
import json
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from PIL import Image

ROOT = "/root/image_guided_pc_completion"
WANT = {"02691156": "airplane", "03001627": "chair", "03636649": "lamp"}

with open(os.path.join(ROOT, "data/shapenet8/splits/test.txt")) as f:
    rels = [ln.strip()[:-4] for ln in f if ln.strip()]
picks = {}
for rel in rels:
    syn = rel.split("/")[0]
    if syn in WANT and syn not in picks:
        picks[syn] = rel

def fps(pts, n):
    sel = [0]
    d = ((pts - pts[0]) ** 2).sum(1)
    for _ in range(n - 1):
        i = int(d.argmax())
        sel.append(i)
        d = np.minimum(d, ((pts - pts[i]) ** 2).sum(1))
    return pts[sel]

fig, axes = plt.subplots(2, len(picks), figsize=(4 * len(picks), 8))
for c, (syn, rel) in enumerate(picks.items()):
    part = np.load(os.path.join(ROOT, "data/shapenet8/pcd/test/partial", rel + ".npy"))
    img = np.asarray(Image.open(os.path.join(
        ROOT, "data/shapenet8/renders", rel + ".png")).convert("RGB"))
    cam = json.load(open(os.path.join(ROOT, "data/shapenet8/cams", rel + ".json")))
    K = np.array(cam["K"], np.float32)
    w2c = np.array(cam["w2c"], np.float32)
    pts = fps(part.astype(np.float32), 512)
    ph = np.c_[pts, np.ones(len(pts))] @ w2c.T
    uv = (K @ ph[:, :3].T).T
    pos = uv[:, 2] > 1e-6
    if pos.sum() < 10:
        pos = uv[:, 2] < -1e-6
    uv = uv[pos]
    H, W = img.shape[:2]
    u = uv[:, 0] / uv[:, 2]
    v = uv[:, 1] / uv[:, 2]
    us = u / (W - 1) * 2 - 1
    vs = v / (H - 1) * 2 - 1
    yy, xx = np.mgrid[0:H, 0:W]
    un = xx / (W - 1) * 2 - 1
    vn = yy / (H - 1) * 2 - 1
    field = np.full((H, W), np.inf, np.float32)
    for ui, vi in zip(us, vs):
        field = np.minimum(field, (un - ui) ** 2 + (vn - vi) ** 2)
    bias = np.exp(-field / (2 * 0.25 ** 2))
    axes[0, c].imshow(img)
    axes[0, c].set_title(WANT[syn], fontsize=10)
    axes[0, c].axis("off")
    axes[1, c].imshow(img)
    axes[1, c].imshow(bias, cmap="inferno", alpha=0.55 * (bias > 0.12))
    axes[1, c].axis("off")
axes[0, 0].set_ylabel("Input view")
axes[1, 0].set_ylabel("GACA bias")
plt.tight_layout()
plt.savefig(os.path.join(ROOT, "paper_assets", "fig_bias.png"), dpi=150)
print("[saved] fig_bias.png")
'''

FILES["tools/bench_efficiency.py"] = '''# -*- coding: utf-8 -*-
"""效率统计：params_M + 单样本延迟（GAC 系全量；SnowflakeNet 仅 params）。"""
import argparse
import json
import os
import sys
import time

import torch

ROOT = "/root/image_guided_pc_completion"
sys.path.insert(0, ROOT)
OUT = os.path.join(ROOT, "paper_assets")
os.makedirs(OUT, exist_ok=True)

ap = argparse.ArgumentParser()
ap.add_argument("--part", choices=["gac", "snow"], required=True)
args = ap.parse_args()

if args.part == "gac":
    from pcic.data import build_dataset
    from pcic.models import GACNet
    from torch.utils.data import DataLoader

    res = {}
    for exp in ["gacnet_pcn8", "gacnet_pcn8_pointonly",
                "gacnet_pcn8_noanchor", "gacnet_pcn8_nolview"]:
        p = os.path.join(ROOT, "experiments", exp, "best_model.pth")
        if not os.path.exists(p):
            continue
        ck = torch.load(p, map_location="cpu", weights_only=False)
        m = GACNet(**ck["config"]["model"])
        m.load_state_dict(ck["model"])
        res[exp] = {"params_M": round(sum(x.numel() for x in m.parameters()) / 1e6, 2)}
    exp = "gacnet_pcn8"
    ck = torch.load(os.path.join(ROOT, "experiments", exp, "best_model.pth"),
                    map_location="cuda", weights_only=False)
    m = GACNet(**ck["config"]["model"]).cuda()
    m.load_state_dict(ck["model"])
    m.eval()
    ds = build_dataset(ck["config"], "test")
    b = next(iter(DataLoader(ds, batch_size=1, shuffle=False, num_workers=2)))
    bb = {k: (v.cuda() if torch.is_tensor(v) else v) for k, v in b.items()}
    with torch.no_grad():
        for _ in range(10):
            m(bb)
        torch.cuda.synchronize()
        t0 = time.time()
        for _ in range(50):
            m(bb)
        torch.cuda.synchronize()
    res["latency_ms_b1"] = round((time.time() - t0) / 50 * 1000, 1)
    json.dump(res, open(os.path.join(OUT, "efficiency_gac.json"), "w"), indent=2)
    print("[saved] efficiency_gac.json", res)
else:
    ck = torch.load("/root/autodl-tmp/snow_exp/pcn8/ckpt-best.pth",
                    map_location="cpu", weights_only=False)
    sd = ck.get("state_dict", ck.get("model", ck))
    n = sum(v.numel() for v in sd.values() if hasattr(v, "numel"))
    json.dump({"params_M": round(n / 1e6, 2)},
              open(os.path.join(OUT, "efficiency_snow.json"), "w"), indent=2)
    print("[saved] efficiency_snow.json")
'''

FILES["tools/try_official_ckpt.py"] = '''# -*- coding: utf-8 -*-
"""Best-effort 官方权重探测：仅从各官方 repo 的 GitHub release 下载预训练权重。
找不到就跳过，绝不使用伪造或第三方魔改权重。"""
import json
import os
import subprocess

REPOS = ["yuxumin/PoinTr", "XhiDiao/GRNet", "yuxumin/SeedFormer", "NovPAI/AnchorFormer"]
OUT = "/root/autodl-tmp/official_ckpt"
os.makedirs(OUT, exist_ok=True)

def api(url):
    r = subprocess.run(["curl", "-sL", "--max-time", "30", url],
                       capture_output=True, text=True)
    try:
        return json.loads(r.stdout)
    except Exception:
        return None

found = []
for repo in REPOS:
    rels = api("https://api.github.com/repos/%s/releases" % repo)
    if not isinstance(rels, list):
        print("[skip]", repo)
        continue
    for rel in rels:
        for a in rel.get("assets", []):
            n = a["name"].lower()
            if n.endswith((".pth", ".ckpt", ".pt")) and a["size"] < 3e9:
                found.append((repo, a["name"], a["browser_download_url"]))
print("[found]", len(found), "candidate assets")
for repo, name, url in found:
    dst = os.path.join(OUT, repo.split("/")[1] + "__" + name)
    if os.path.exists(dst) and os.path.getsize(dst) > 1e6:
        print("[exists]", dst)
        continue
    print("[download]", name)
    subprocess.run(["curl", "-L", "--max-time", "1800", "-o", dst, url], check=False)
ok = [f for f in os.listdir(OUT) if os.path.getsize(os.path.join(OUT, f)) > 1e6]
print("[downloaded]", ok)
print("[B_DONE]")
'''

FILES["make_all_assets.py"] = '''# -*- coding: utf-8 -*-
"""PCN-8 + 扩展实验全部资产：表格 v2 + 4 张图（全部来自真实评估结果）。"""
import csv
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = "/root/image_guided_pc_completion"
OUT = os.path.join(ROOT, "paper_assets")
os.makedirs(OUT, exist_ok=True)
CATS = ["airplane", "cabinet", "car", "chair", "lamp", "sofa", "table", "watercraft"]
MAIN = [("snowflakenet_pcn8", "SnowflakeNet"),
        ("pointonly_pcn8", "Point-only (w/o image)"),
        ("gacnet_pcn8", "GAC-Net (ours)")]
COLORS = {"snowflakenet_pcn8": "#8C8C8C", "pointonly_pcn8": "#DD8452",
          "gacnet_pcn8": "#4C72B0", "noanchor_pcn8": "#55A868",
          "nolview_pcn8": "#C44E52"}
EXTRA_KEYS = ["noanchor_pcn8", "nolview_pcn8", "gacnet_pcn8_ds256",
              "gacnet_pcn8_ds512", "gacnet_pcn8_ds1024", "gacnet_pcn8_blur2",
              "gacnet_pcn8_noise05", "gacnet_pcn8_gray", "gacnet_pcn8_to_pix3d"]

def load(key):
    p = os.path.join(ROOT, "results", "prediction_metrics", key + ".json")
    if os.path.exists(p):
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    return None

def fmt(x, nd=1):
    return ("%." + str(nd) + "f") % x if isinstance(x, (int, float)) else "TBD"

def curves(exp):
    p = os.path.join(ROOT, "experiments", exp, "train_log.csv")
    ep, lo = [], []
    if not os.path.exists(p):
        return ep, lo
    with open(p, encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            try:
                ep.append(int(row["epoch"]))
                lo.append(float(row["loss"]))
            except (ValueError, KeyError):
                continue
    return ep, lo

R = {k: load(k) for k, _ in MAIN}
for k in EXTRA_KEYS:
    R[k] = load(k)

lines = ["# PCN-8 + extended results (auto-generated, do not edit numbers)\\n"]
lines.append("## Table 1. Completion on PCN-8 (CD-L1 x1e4, lower is better)\\n")
lines.append("| Method | " + " | ".join(c[:5] for c in CATS) + " | Avg. |")
lines.append("|---|" + "---|" * (len(CATS) + 1))
for key, label in MAIN:
    r = R.get(key)
    if not r:
        lines.append("| %s | " % label + "TBD | " * (len(CATS) + 1))
        continue
    vals = [fmt(r.get(c, {}).get("CD_L1_x1e4")) for c in CATS]
    lines.append("| %s | " % label + " | ".join(vals)
                 + " | %s |" % fmt(r["overall"]["CD_L1_x1e4"]))

lines.append("\\n## Table 2. CD-L2 x1e4 and F-Score (overall, macro)\\n")
lines.append("| Method | CD-L2 | F@1% | F@2% |")
lines.append("|---|---|---|---|")
for key, label in MAIN:
    r = R.get(key)
    if not r:
        lines.append("| %s | TBD | TBD | TBD |" % label)
        continue
    o = r["overall"]
    lines.append("| %s | %s | %s | %s |" % (label, fmt(o["CD_L2_x1e4"]),
                 fmt(o["Fscore@0.01"], 3), fmt(o["Fscore@0.02"], 3)))

lines.append("\\n## Table 4. Ablations on PCN-8 (overall)\\n")
lines.append("| Variant | CD-L1 | CD-L2 | F@1% |")
lines.append("|---|---|---|---|")
for key, label in [("gacnet_pcn8", "GAC-Net (full)"),
                   ("noanchor_pcn8", "w/o geometric anchor"),
                   ("nolview_pcn8", "w/o L_view"),
                   ("pointonly_pcn8", "w/o image branch")]:
    r = R.get(key)
    if not r:
        lines.append("| %s | TBD | TBD | TBD |" % label)
        continue
    o = r["overall"]
    lines.append("| %s | %s | %s | %s |" % (label, fmt(o["CD_L1_x1e4"]),
                 fmt(o["CD_L2_x1e4"]), fmt(o["Fscore@0.01"], 3)))

def cell(key):
    r = R.get(key)
    return fmt(r["overall"]["CD_L1_x1e4"]) if r else "TBD"

lines.append("\\n## Table R1. Input sparsity sweep (GAC-Net, CD-L1 x1e4)\\n")
lines.append("| N_partial | 256 | 512 | 1024 | 2048 |")
lines.append("|---|---|---|---|---|")
lines.append("| CD-L1 | " + " | ".join(cell(k) for k in
             ["gacnet_pcn8_ds256", "gacnet_pcn8_ds512", "gacnet_pcn8_ds1024",
              "gacnet_pcn8"]) + " |")

lines.append("\\n## Table R2. Image degradation sweep (GAC-Net, CD-L1 x1e4)\\n")
lines.append("| Condition | Clean | Blur s=2 | Noise 0.05 | Grayscale |")
lines.append("|---|---|---|---|---|")
lines.append("| CD-L1 | " + " | ".join(cell(k) for k in
             ["gacnet_pcn8", "gacnet_pcn8_blur2", "gacnet_pcn8_noise05",
              "gacnet_pcn8_gray"]) + " |")

lines.append("\\n## Table G1. Cross-dataset generalization (zero-shot)\\n")
lines.append("| Model | Train | Test | CD-L1 | CD-L2 | F@1% |")
lines.append("|---|---|---|---|---|---|")
r = R.get("gacnet_pcn8_to_pix3d")
if r:
    o = r["overall"]
    lines.append("| GAC-Net | PCN-8 (synthetic) | Pix3D (real) | %s | %s | %s |" % (
        fmt(o["CD_L1_x1e4"]), fmt(o["CD_L2_x1e4"]), fmt(o["Fscore@0.01"], 3)))
else:
    lines.append("| GAC-Net | PCN-8 (synthetic) | Pix3D (real) | TBD | TBD | TBD |")

with open(os.path.join(OUT, "tables.md"), "w", encoding="utf-8") as f:
    f.write("\\n".join(lines) + "\\n")
print("[saved] tables.md")

# Fig: CD-L1 bars (3 main methods)
avail = [(k, l) for k, l in MAIN if R.get(k)]
if avail:
    x = np.arange(len(CATS))
    w = 0.8 / max(len(avail), 1)
    fig, ax = plt.subplots(figsize=(10, 4.2))
    for i, (key, label) in enumerate(avail):
        vals = [R[key].get(c, {}).get("CD_L1_x1e4", np.nan) for c in CATS]
        ax.bar(x + (i - (len(avail) - 1) / 2) * w, vals, w * 0.92,
               label=label, color=COLORS[key], edgecolor="white")
    ax.set_xticks(x)
    ax.set_xticklabels(CATS, rotation=20, ha="right")
    ax.set_ylabel("CD-L1 x1e4 (lower is better)")
    ax.legend(frameon=False)
    ax.spines[["top", "right"]].set_visible(False)
    plt.tight_layout()
    plt.savefig(os.path.join(OUT, "fig_pcn8_cdl1_bars.png"), dpi=150)
    plt.close()
    print("[saved] fig_pcn8_cdl1_bars.png")

# Fig: training curves (4 series)
series = [("gacnet_pcn8", "GAC-Net (full)", "#4C72B0"),
          ("gacnet_pcn8_pointonly", "Point-only", "#DD8452"),
          ("gacnet_pcn8_noanchor", "w/o anchor", "#55A868"),
          ("gacnet_pcn8_nolview", "w/o L_view", "#C44E52")]
data = []
for exp, label, color in series:
    ep, lo = curves(exp)
    if ep:
        data.append((label, color, ep, lo))
if data:
    fig, ax = plt.subplots(figsize=(7, 4))
    for label, color, ep, lo in data:
        ax.plot(ep, lo, label=label, color=color)
    ax.set_xlabel("Epoch")
    ax.set_ylabel("Training loss (CD-L1)")
    ax.legend(frameon=False)
    ax.spines[["top", "right"]].set_visible(False)
    plt.tight_layout()
    plt.savefig(os.path.join(OUT, "fig_pcn8_curves.png"), dpi=150)
    plt.close()
    print("[saved] fig_pcn8_curves.png")

# Fig: robustness (sparsity + degradation)
def overall_cd(key):
    r = R.get(key)
    return r["overall"]["CD_L1_x1e4"] if r else None

sp = [overall_cd(k) for k in ["gacnet_pcn8_ds256", "gacnet_pcn8_ds512",
                              "gacnet_pcn8_ds1024", "gacnet_pcn8"]]
dg = [overall_cd(k) for k in ["gacnet_pcn8", "gacnet_pcn8_blur2",
                              "gacnet_pcn8_noise05", "gacnet_pcn8_gray"]]
if any(v is not None for v in sp + dg):
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(10, 3.8))
    pts = [(x, v) for x, v in zip([256, 512, 1024, 2048], sp) if v is not None]
    if pts:
        a1.plot([p[0] for p in pts], [p[1] for p in pts], "o-", color="#4C72B0")
        a1.set_xticks([256, 512, 1024, 2048])
        a1.set_xlabel("Input points")
        a1.set_ylabel("CD-L1 x1e4")
        a1.set_title("Sparsity sweep")
    pts2 = [(l, v) for l, v in zip(["clean", "blur", "noise", "gray"], dg)
            if v is not None]
    if pts2:
        a2.bar([p[0] for p in pts2], [p[1] for p in pts2], color="#4C72B0")
        a2.set_ylabel("CD-L1 x1e4")
        a2.set_title("Image degradation")
    for a in (a1, a2):
        a.spines[["top", "right"]].set_visible(False)
    plt.tight_layout()
    plt.savefig(os.path.join(OUT, "fig_robustness.png"), dpi=150)
    plt.close()
    print("[saved] fig_robustness.png")

# Fig: qualitative comparison (3 main methods)
def read_pts(path):
    if path.endswith(".npy"):
        return np.load(path).astype(np.float32)
    import open3d as o3d
    return np.asarray(o3d.io.read_point_cloud(path).points, np.float32)

gac = R.get("gacnet_pcn8")
if gac:
    with open(os.path.join(ROOT, "data", "shapenet8", "splits", "test.txt")) as f:
        ids = [ln.strip()[:-4] for ln in f if ln.strip().endswith("__v0.npy")]
    rng = np.random.RandomState(0)
    picks = rng.choice(len(ids), 3, replace=False)
    rows = [ids[i] for i in picks]
    ncol = 2 + len(avail)
    fig = plt.figure(figsize=(3 * ncol, 3.1 * len(rows)))
    for r0, cid in enumerate(rows):
        syn, mid = cid.split("/")
        col = 0
        panels = [("Input", os.path.join(ROOT, "data/shapenet8/pcd/test/partial",
                                         syn, mid + "__v0.npy")),
                  ("Ground truth", os.path.join(
                      ROOT, "data/shapenet8/pcd/test/complete", syn, mid + ".npy"))]
        for key, label in MAIN:
            p = os.path.join(ROOT, "predictions", key, syn, mid + "__v0.npy")
            if os.path.exists(p):
                panels.append((label.split(" (")[0], p))
        for label, path in panels:
            ax = fig.add_subplot(len(rows), ncol, r0 * ncol + col + 1,
                                 projection="3d")
            pts = read_pts(path)
            step = max(1, len(pts) // 1200)
            pts = pts[::step]
            ax.scatter(pts[:, 0], pts[:, 2], -pts[:, 1], s=1.2, c=pts[:, 2],
                       cmap="viridis", linewidth=0)
            ax.set_axis_off()
            if r0 == 0:
                ax.set_title(label, fontsize=10)
            col += 1
    plt.tight_layout()
    plt.savefig(os.path.join(OUT, "fig_pcn8_qualitative.png"), dpi=150)
    plt.close()
    print("[saved] fig_pcn8_qualitative.png")
print("ASSETS_DONE")
'''

FILES["/root/run_extra.sh"] = '''#!/bin/bash
# 扩展实验链：C 消融 -> A 泛化/鲁棒/可视化/效率 -> B 官方ckpt探测 -> 图表 v2
# 预测产物统一写数据盘 $PRED，软链回工程 predictions/ 供统一评估
cd /root/image_guided_pc_completion
PY=/root/miniconda3/bin/python
SNOW=/root/miniconda3/envs/snowflake/bin/python
PRED=/root/autodl-tmp/pc_predictions

echo "=== [1/9] train no_anchor (30ep) ==="
$PY train.py --config configs/pcn8_noanchor.json 2>&1 | tail -2
$PY predict.py --ckpt experiments/gacnet_pcn8_noanchor/best_model.pth --out $PRED/noanchor_pcn8 --split test 2>&1 | tail -1
ln -sfn $PRED/noanchor_pcn8 predictions/noanchor_pcn8
$PY tools/eval_predictions.py --pred_root predictions --data_root data/shapenet8/pcd --split test --methods noanchor_pcn8 2>&1 | tail -5

echo "=== [2/9] train no_lview (30ep) ==="
$PY train.py --config configs/pcn8_nolview.json 2>&1 | tail -2
$PY predict.py --ckpt experiments/gacnet_pcn8_nolview/best_model.pth --out $PRED/nolview_pcn8 --split test 2>&1 | tail -1
ln -sfn $PRED/nolview_pcn8 predictions/nolview_pcn8
$PY tools/eval_predictions.py --pred_root predictions --data_root data/shapenet8/pcd --split test --methods nolview_pcn8 2>&1 | tail -5

echo "=== [3/9] Pix3D zero-shot generalization ==="
$PY predict.py --ckpt experiments/gacnet_pcn8/best_model.pth --out $PRED/gacnet_pcn8_to_pix3d --split test --override '{"data_root":"data/pix3d_dev"}' 2>&1 | tail -1
ln -sfn $PRED/gacnet_pcn8_to_pix3d predictions/gacnet_pcn8_to_pix3d
$PY tools/eval_predictions.py --pred_root predictions --data_root data/pix3d_dev/pcd --split test --methods gacnet_pcn8_to_pix3d 2>&1 | tail -5

echo "=== [4/9] sparsity sweep ==="
for N in 256 512 1024; do
  $PY predict.py --ckpt experiments/gacnet_pcn8/best_model.pth --out $PRED/gacnet_pcn8_ds$N --split test --override "{\\"n_partial\\": $N}" 2>&1 | tail -1
  ln -sfn $PRED/gacnet_pcn8_ds$N predictions/gacnet_pcn8_ds$N
  $PY tools/eval_predictions.py --pred_root predictions --data_root data/shapenet8/pcd --split test --methods gacnet_pcn8_ds$N 2>&1 | tail -4
done

echo "=== [5/9] image degradation sweep ==="
$PY tools/gen_shadow_degrade.py 2>&1 | tail -2
for D in blur2 noise05 gray; do
  $PY predict.py --ckpt experiments/gacnet_pcn8/best_model.pth --out $PRED/gacnet_pcn8_$D --split test --override "{\\"data_root\\":\\"data/shapenet8_$D\\"}" 2>&1 | tail -1
  ln -sfn $PRED/gacnet_pcn8_$D predictions/gacnet_pcn8_$D
  $PY tools/eval_predictions.py --pred_root predictions --data_root data/shapenet8/pcd --split test --methods gacnet_pcn8_$D 2>&1 | tail -4
done

echo "=== [6/9] stagewise + bias visualizations ==="
$PY tools/viz_stage.py 2>&1 | tail -2
$PY tools/viz_bias.py 2>&1 | tail -2

echo "=== [7/9] efficiency ==="
$PY tools/bench_efficiency.py --part gac 2>&1 | tail -2
$SNOW tools/bench_efficiency.py --part snow 2>&1 | tail -2

echo "=== [8/9] official ckpt probe (best-effort) ==="
source /etc/network_turbo 2>/dev/null || true
$PY tools/try_official_ckpt.py 2>&1 | tail -8 || true

echo "=== [9/9] generate all assets ==="
$SNOW /root/image_guided_pc_completion/make_all_assets.py 2>&1 | tail -12
echo "EXTRA_DONE"
'''

FILES["/root/chain_extra.sh"] = '''#!/bin/bash
# 等 run_after_gacnet.sh 全部完成（chain.log 出现 ALL_DONE）后执行扩展实验
while ! grep -q "ALL_DONE" /root/chain.log 2>/dev/null; do sleep 180; done
bash /root/run_extra.sh > /root/chain_extra.log 2>&1
echo "WATCHER_EXIT $?" >> /root/chain_extra.log
'''


def main():
    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    c.connect(HOST, port=PORT, username=USER, password=PWD, timeout=20)
    s = c.open_sftp()

    written = []
    import tempfile
    tmpdir = tempfile.mkdtemp(prefix="deploy_extra_")
    for i, (rel, content) in enumerate(FILES.items()):
        remote = rel if rel.startswith("/") else PROJ + "/" + rel
        d = os.path.dirname(remote)
        parts, cur = d.strip("/").split("/"), ""
        for p in parts:
            cur += "/" + p
            try:
                s.stat(cur)
            except IOError:
                s.mkdir(cur)
        local = os.path.join(tmpdir, "f%03d.bin" % i)
        with open(local, "w", encoding="utf-8", newline="\n") as f:
            f.write(content)
        s.put(local, remote)
        written.append(remote)
    s.close()

    # 语法校验 + 启动 watcher
    checks = []
    for rel in FILES:
        remote = rel if rel.startswith("/") else PROJ + "/" + rel
        if remote.endswith(".json"):
            checks.append("python3 -c \"import json;json.load(open('%s'))\"" % remote)
        elif remote.endswith(".py"):
            checks.append("python3 -m py_compile %s" % remote)
        elif remote.endswith(".sh"):
            checks.append("bash -n %s" % remote)
    cmd = "; ".join("cd %s && %s" % (PROJ, ck) for ck in checks
                    if not ck.startswith("bash"))
    cmd += "; bash -n /root/run_extra.sh; bash -n /root/chain_extra.sh"
    _, out, err = c.exec_command(cmd, timeout=120)
    rc1 = out.channel.recv_exit_status()

    start = ("pgrep -f chain_extra.sh >/dev/null || "
             "(setsid nohup bash /root/chain_extra.sh >/dev/null 2>&1 &); "
             "sleep 1; pgrep -f chain_extra.sh | head -2")
    _, out2, err2 = c.exec_command(start, timeout=30)
    watcher = out2.read().decode().strip()
    c.close()

    print("[written]", len(written), "files")
    for w in written:
        print("  ", w)
    print("[syntax_check_exit]", rc1)
    if err.strip():
        print("[check_stderr]", err[-800:])
    print("[watcher_pids]", watcher)


if __name__ == "__main__":
    main()
