#!/bin/bash
apt-get install -y -qq aria2 > /dev/null 2>&1
aria2c --version | head -1
curl -sL "https://hyper.ai/cn/datasets/16769" -o /tmp/hyperai.html
wc -c /tmp/hyperai.html
grep -oE 'https?://[^"'"'"' ]+\.torrent[^"'"'"' ]*' /tmp/hyperai.html | head -5
grep -oE 'magnet:\?[^"'"'"' ]+' /tmp/hyperai.html | head -2
grep -oiE 'href="[^"]*(torrent|download)[^"]*"' /tmp/hyperai.html | head -8
