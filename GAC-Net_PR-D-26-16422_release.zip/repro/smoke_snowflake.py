# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/root/SnowflakeNet/completion")
sys.path.insert(0, "/root/SnowflakeNet")
import inspect
import torch
from models.model_completion import SnowflakeNet

sig = inspect.signature(SnowflakeNet.__init__)
print("init params:", list(sig.parameters))
m = SnowflakeNet(dim_feat=512, num_p0=512, radius=1, up_factors=[1, 2, 2]).cuda()
x = torch.rand(2, 2048, 3).cuda()
out = m(x)
print("fwd ok:", [tuple(t.shape) for t in out] if isinstance(out, (tuple, list)) else out.shape)
