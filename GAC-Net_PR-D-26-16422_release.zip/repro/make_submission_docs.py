# -*- coding: utf-8 -*-
"""
生成 Electronics (MDPI) 投稿两件套：
1) Cover Letter
2) 论文修改建议书（新增/修改内容用红色粗体标注）
"""
from docx import Document
from docx.shared import RGBColor, Pt, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

RED_BOLD = RGBColor(0xC0, 0x00, 0x00)
BLACK = RGBColor(0x00, 0x00, 0x00)


def add_para(doc, text, *, bold=False, color=BLACK, size=11, align=None, italic=False, space_after=6):
    p = doc.add_paragraph()
    if align is not None:
        p.alignment = align
    run = p.add_run(text)
    run.bold = bold
    run.italic = italic
    run.font.size = Pt(size)
    run.font.color.rgb = color
    # 中文字体
    run.font.name = 'Times New Roman'
    rPr = run._element.get_or_add_rPr()
    rFonts = rPr.find(qn('w:rFonts'))
    if rFonts is None:
        rFonts = OxmlElement('w:rFonts')
        rPr.append(rFonts)
    rFonts.set(qn('w:eastAsia'), '宋体')
    p.paragraph_format.space_after = Pt(space_after)
    return p


def add_rich_para(doc, segments, *, size=11, align=None, space_after=6):
    """segments: list of (text, is_red_bold) tuples"""
    p = doc.add_paragraph()
    if align is not None:
        p.alignment = align
    for text, is_red_bold in segments:
        run = p.add_run(text)
        if is_red_bold:
            run.bold = True
            run.font.color.rgb = RED_BOLD
        else:
            run.font.color.rgb = BLACK
        run.font.size = Pt(size)
        run.font.name = 'Times New Roman'
        rPr = run._element.get_or_add_rPr()
        rFonts = rPr.find(qn('w:rFonts'))
        if rFonts is None:
            rFonts = OxmlElement('w:rFonts')
            rPr.append(rFonts)
        rFonts.set(qn('w:eastAsia'), '宋体')
    p.paragraph_format.space_after = Pt(space_after)
    return p


# =================== 1. Cover Letter ===================
cover = Document()
# 设置默认字体
style = cover.styles['Normal']
style.font.name = 'Times New Roman'
style.font.size = Pt(11)

add_para(cover, 'Cover Letter', bold=True, size=16, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=18)
add_para(cover, 'To the Editor-in-Chief of Electronics (MDPI)', size=11, space_after=6)
add_para(cover, 'Date: October 24, 2026', size=11, space_after=18)

add_para(cover, 'Dear Editor-in-Chief,', size=11, space_after=12)

add_para(cover,
    'Subject: Submission of Manuscript "A Lightweight YOLO-Based AI Detector for Dense Product '
    'Recognition in Smart Retail Cabinets" for Consideration in Electronics',
    bold=True, size=11, space_after=18)

add_para(cover,
    'We are pleased to submit our original research manuscript entitled "A Lightweight YOLO-Based '
    'AI Detector for Dense Product Recognition in Smart Retail Cabinets" for consideration for '
    'publication in Electronics (MDPI).', size=11, space_after=12)

add_para(cover,
    'This work addresses the practical problem of accurate product detection in smart retail '
    'cabinets, where dense shelf arrangements, fine-grained SKU similarity, small object size, '
    'partial occlusion, and fisheye-induced spatial distortion jointly challenge conventional '
    'detectors. Rather than scaling up model capacity, we propose a lightweight YOLO26-style '
    'detector augmented with three complementary, edge-deployable modules:',
    size=11, space_after=8)

add_para(cover,
    '1) Cross-Scale Spectral-Anchor Fusion Attention (C2SAFA) — a dual-path attention block '
    'that combines anchor-slot aggregation with phase-preserving spectral shrinkage, modelling '
    'periodic shelf structures at approximately linear computational cost;',
    size=11, space_after=4)
add_para(cover,
    '2) Kernel-wise Feature Adaptation (KFA) — a content-adaptive feature reassembly module '
    'with fisheye-aware radial modulation and rank-adaptive channel partnering; and',
    size=11, space_after=4)
add_para(cover,
    '3) Improved Normalized Exponential IoU (ImNEIoU) — a quality-adaptive regression loss '
    'combining bounded IoU focusing, warm-up EMA quality reference, and dynamic non-monotonic '
    'gradient scaling.',
    size=11, space_after=12)

add_para(cover,
    'The proposed detector achieves 96.59% mAP@0.5, 92.78% precision, and 91.33% recall on a '
    'self-built 113-class retail cabinet dataset, while requiring only 2.64 million parameters '
    'and 6.47 GFLOPs (only +165 parameters over the baseline). Results are validated across '
    'five independent training runs (std < 0.15%), and paired t-tests confirm statistical '
    'significance (p < 0.001).', size=11, space_after=12)

add_para(cover,
    'We believe this work aligns particularly well with the scope of Electronics because: (i) '
    'the lightweight architecture is explicitly designed for embedded edge electronics and '
    'real-time inference on resource-constrained hardware; (ii) the proposed modules introduce '
    'electronic-system-relevant inductive biases — fisheye-aware radial modulation reflects the '
    'optical geometry of retail-cabinet cameras, and the parameter-efficient spectral branch is '
    'compatible with mixed-precision edge accelerators; and (iii) the study contributes to the '
    'broader deployment of intelligent computer-vision systems on embedded retail electronics, '
    'which is a central topic of your journal.', size=11, space_after=12)

add_para(cover,
    'This manuscript has not been published previously and is not under consideration for '
    'publication elsewhere. All authors have read and approved the final manuscript. We '
    'declare no conflicts of interest, financial or otherwise. The complete dataset and source '
    'code are publicly available at https://github.com/hwqwlsu/Product-_Detection.git to '
    'support reproducibility.', size=11, space_after=12)

add_para(cover,
    'We would be grateful if the manuscript could be considered for peer review. The suggested '
    'reviewing editors and reviewers are listed below; we have no professional or personal '
    'relationship with any of them.', size=11, space_after=12)

add_para(cover, 'Suggested Reviewers:', bold=True, size=11, space_after=4)
add_para(cover, '1. Prof. [Reviewer Name 1] — [Affiliation, Country] — [Email]', size=11, space_after=2)
add_para(cover, '2. Prof. [Reviewer Name 2] — [Affiliation, Country] — [Email]', size=11, space_after=2)
add_para(cover, '3. Prof. [Reviewer Name 3] — [Affiliation, Country] — [Email]', size=11, space_after=12)

add_para(cover, 'Thank you very much for your time and consideration.', size=11, space_after=18)

add_para(cover, 'Sincerely,', size=11, space_after=18)
add_para(cover, 'Shuyong Huang (Corresponding Author)', bold=True, size=11, space_after=2)
add_para(cover, 'School of Business and Trade, Anhui Wenda University of Information Engineering',
         size=11, space_after=2)
add_para(cover, 'Hefei 231201, China', size=11, space_after=2)
add_para(cover, 'Email: Xiaoyong1216@sohu.com', size=11, space_after=12)

add_para(cover, 'Qing Cheng', bold=True, size=11, space_after=2)
add_para(cover, 'School of Artificial Intelligence, Anhui University', size=11, space_after=2)
add_para(cover, 'Hefei 230601, China', size=11, space_after=2)
add_para(cover, 'Email: w125121013@stu.ahu.edu.cn', size=11, space_after=6)

cover.save(r'C:\Users\黄文全\Documents\Trae-CN\temp_20261013_01\Cover_Letter_Electronics_MDPI.docx')
print('Cover Letter saved.')


# =================== 2. Paper Revision Suggestions ===================
rev = Document()
style = rev.styles['Normal']
style.font.name = 'Times New Roman'
style.font.size = Pt(11)

add_para(rev, 'Paper Revision Suggestions for Electronics (MDPI) Submission',
         bold=True, size=16, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=6)
add_para(rev, 'Manuscript: A Lightweight YOLO-Based AI Detector for Dense Product Recognition in Smart Retail Cabinets',
         italic=True, size=11, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=4)
add_para(rev, 'Target Journal: Electronics (MDPI) — Q3 JCR / 中科院4区',
         italic=True, size=11, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=18)

# Legend
add_para(rev, '【图例说明】', bold=True, size=12, space_after=4)
add_rich_para(rev, [('  • 黑色文字  = 原稿保留内容（仅作上下文，无需修改）', False),
                    ('', False)])
add_rich_para(rev, [('  • ', False), ('红色粗体 = 新增 / 修改内容（请直接替换到原稿对应位置）', True)], space_after=18)

# ============ 修订要点概览 ============
add_para(rev, '一、修订要点总览', bold=True, size=14, space_after=8)
add_rich_para(rev, [('1. ', False), ('摘要压缩至约 200 词以内（MDPI Electronics 强制要求 ≤200 词）', True)], space_after=4)
add_rich_para(rev, [('2. ', False), ('新增 Highlights 条目（MDPI 强烈推荐）', True)], space_after=4)
add_rich_para(rev, [('3. ', False), ('引言中强化"嵌入式电子/边缘部署"主题契合度（突出 Electronics 期刊 Scope）', True)], space_after=4)
add_rich_para(rev, [('4. ', False), ('实验/讨论中补充边缘部署指标（FPS / 延迟 / 显存占用 / 边缘设备推理）', True)], space_after=4)
add_rich_para(rev, [('5. ', False), ('新增 Acknowledgments 段落（MDPI 标准结构）', True)], space_after=4)
add_rich_para(rev, [('6. ', False), ('结论中强化电子工程应用价值', True)], space_after=4)
add_rich_para(rev, [('7. ', False), ('修正原稿第 3 行作者机构双逗号排版问题', True)], space_after=18)


# ============ 1. 标题页修订 ============
add_para(rev, '二、标题页修订', bold=True, size=14, space_after=8)

add_para(rev, '【1.1 作者单位行修正】', bold=True, size=12, space_after=4)
add_para(rev, '原文：', size=11, space_after=2)
add_para(rev, '1  School of Business and Trade, Anhui Wenda University of Information Engineering,, Hefei 231201, China;',
         italic=True, size=11, space_after=4)
add_para(rev, '修改为：', size=11, space_after=2)
add_rich_para(rev, [
    ('1  School of Business and Trade, Anhui Wenda University of Information Engineering, Hefei 231201, China; ', False),
    ('（删除原文中的双逗号 ",,"）', True)
], space_after=12)


# ============ 2. 摘要修订 ============
add_para(rev, '三、摘要（Abstract）修订', bold=True, size=14, space_after=8)
add_rich_para(rev, [('原因：', False), ('MDPI Electronics 严格要求 Abstract 不超过 200 词，原稿约 350 词，超标严重。需精简、突出"轻量化+边缘部署"主题，并量化最终性能。', True)], space_after=8)

add_para(rev, '原稿摘要（节选，~350 词）：', italic=True, size=11, space_after=2)
add_para(rev,
    'Product identification in automated retail cabinets is made difficult by densely packed '
    'products, visual similarities among stock-keeping units(SKUs), small object sizes, '
    'repetitive shelving arrangement, partial object occlusion, and non-uniform distortions '
    'due to wide-angle or fish-eye lenses... (后续略)',
    italic=True, size=11, space_after=8)

add_para(rev, '建议替换为（约 195 词，符合 MDPI 200 词限制）：', bold=True, size=11, space_after=4)
add_rich_para(rev, [
    ('Abstract: ', True),
    ('Smart retail cabinets require accurate product detection under dense packing, fine-grained '
     'SKU similarity, small object size, partial occlusion, and fisheye-induced spatial '
     'distortion. Conventional detectors face accuracy–efficiency conflicts when deployed on '
     'embedded edge electronics with limited compute and memory budgets. We propose a '
     'lightweight YOLO26-style detector augmented with three complementary modules: (1) '
     'Cross-Scale Spectral-Anchor Fusion Attention (C2SAFA), which combines anchor-slot '
     'aggregation with phase-preserving spectral shrinkage to model shelf periodicity at '
     'approximately linear cost; (2) Kernel-wise Feature Adaptation (KFA), which introduces '
     'fisheye-aware radial modulation and rank-adaptive channel partnering for content-'
     'dependent feature recalibration; and (3) Improved Normalized Exponential IoU (ImNEIoU), '
     'a quality-adaptive regression loss with bounded IoU focusing, a warm-up EMA quality '
     'reference, and dynamic non-monotonic gradient scaling. On a self-built 113-class retail '
     'cabinet dataset, the detector achieves 96.59% mAP@0.5, 92.78% precision, and 91.33% '
     'recall, while requiring only 2.64 M parameters and 6.47 GFLOPs (only +165 parameters over '
     'the baseline). Results are stable across five independent runs (std < 0.15%) and '
     'statistically significant (paired t-test, p < 0.001). The proposed accuracy–efficiency '
     'trade-off makes the detector suitable for real-time edge deployment in computationally '
     'constrained retail electronics.', True)
], space_after=18)


# ============ 3. 关键词修订 ============
add_para(rev, '四、关键词（Keywords）修订', bold=True, size=14, space_after=8)
add_rich_para(rev, [('原因：', False), ('MDPI 推荐关键词与期刊 Scope 词一致，加入"边缘计算""嵌入式系统""实时检测"可提高编辑检索匹配度。', True)], space_after=8)

add_para(rev, '原关键词：', italic=True, size=11, space_after=2)
add_para(rev,
    'smart retail; product detection; small object detection; fisheye vision; spectral '
    'attention; anchor attention; feature reassembly; IoU loss; YOLO; deep learning',
    italic=True, size=11, space_after=8)

add_para(rev, '建议替换为（含边缘部署语义）：', bold=True, size=11, space_after=4)
add_rich_para(rev, [
    ('Keywords: ', True),
    ('smart retail; product detection; lightweight YOLO; small object detection; fisheye '
     'vision; spectral attention; edge deployment; embedded electronics; real-time detection; '
     'deep learning', True)
], space_after=18)


# ============ 4. 新增 Highlights ============
add_para(rev, '五、新增 Highlights 段（紧跟 Abstract 之后）', bold=True, size=14, space_after=8)
add_rich_para(rev, [('说明：', False), ('MDPI 期刊强烈推荐 Highlights，作为单独段落列出 3-5 条核心贡献，便于审稿与检索。原稿无此段，需新增。', True)], space_after=8)

add_para(rev, '建议新增段落：', bold=True, size=11, space_after=4)
add_rich_para(rev, [('Highlights:', True)], space_after=4)
add_rich_para(rev, [('• ', False), ('A lightweight YOLO26-based detector tailored for dense smart retail cabinet imagery.', True)], space_after=4)
add_rich_para(rev, [('• ', False), ('C2SAFA combines anchor-slot aggregation with phase-preserving spectral shrinkage at near-linear cost.', True)], space_after=4)
add_rich_para(rev, [('• ', False), ('KFA introduces fisheye-aware radial modulation and rank-adaptive channel partnering.', True)], space_after=4)
add_rich_para(rev, [('• ', False), ('ImNEIoU loss uses bounded focusing, warm-up EMA reference, and non-monotonic gradient scaling.', True)], space_after=4)
add_rich_para(rev, [('• ', False), ('96.59% mAP@0.5 with only 2.64 M parameters and 6.47 GFLOPs, suitable for edge electronics.', True)], space_after=18)


# ============ 5. 引言强化 ============
add_para(rev, '六、引言（Introduction）强化"边缘电子"主题', bold=True, size=14, space_after=8)
add_rich_para(rev, [('原因：', False), ('Electronics 期刊 Scope 强调电子系统、嵌入式硬件、边缘智能。原稿 Introduction 主要从"零售场景痛点"切入，对"为何适合 Electronics"着墨不足。建议在第 1 段末尾新增一句过渡，并在第 4 段（贡献列表前）新增一段强调边缘部署。', True)], space_after=8)

add_para(rev, '【6.1 第 1 段末尾追加】', bold=True, size=12, space_after=4)
add_para(rev, '原第 1 段末句：', italic=True, size=11, space_after=2)
add_para(rev,
    '...The above reasons indicate that the problem of retail product detection is a domain-'
    'specific one requiring fine-grained discrimination, small-object representation, geometric '
    'robustness, localisation precision and computational efficiency simultaneously.',
    italic=True, size=11, space_after=4)
add_para(rev, '末尾追加：', bold=True, size=11, space_after=4)
add_rich_para(rev, [
    (' ', False),
    ('In addition, these cabinets are typically powered by embedded ARM or low-power GPU '
     'modules whose compute, memory and energy budgets are an order of magnitude tighter than '
     'those of server-grade hardware, so any practical detector must remain lightweight enough '
     'for real-time edge inference.', True)
], space_after=12)

add_para(rev, '【6.2 第 4 段（贡献列表前）新增过渡段】', bold=True, size=12, space_after=4)
add_para(rev, '建议在"3. Improved Normalized Exponential IoU (ImNEIoU) Loss..."与"Together, these components..."之间，插入一段：', size=11, space_after=4)
add_rich_para(rev, [
    (' ', False),
    ('From an electronics-systems perspective, the above three modules are intentionally '
     'designed to fit within the constraints of embedded retail hardware: C2SAFA replaces '
     'quadratic self-attention with near-linear anchor-slot interaction and an FFT branch that '
     'scales as O(N log N); KFA introduces no trainable spatial tensors and uses cached radial '
     'maps so its memory footprint remains constant; ImNEIoU is a training-only loss that adds '
     'zero inference-time parameters or FLOPs. The resulting detector therefore preserves the '
     'YOLO26 baseline parameter budget (≈2.64 M) and computational cost (6.47 GFLOPs), making '
     'it directly deployable on commodity edge accelerators such as NVIDIA Jetson Nano / '
     'Jetson Orin Nano, Rockchip RK3588, or ARM Cortex-A based vision modules commonly used '
     'in smart retail cabinets.', True)
], space_after=18)


# ============ 6. 实验补充边缘部署指标 ============
add_para(rev, '七、实验部分补充边缘部署测试（强烈建议）', bold=True, size=14, space_after=8)
add_rich_para(rev, [('原因：', False), ('Electronics 审稿人非常看重"真实硬件部署数据"。原稿仅给出参数量与 GFLOPs，未给 FPS/延迟/显存。建议在 4.6 Results Analysis 之后新增 4.7 节"Edge Deployment Evaluation"。如条件不允许实测，至少补充基于公开基准的对比推算，并明确说明为"estimated"。', True)], space_after=8)

add_para(rev, '建议新增 4.7 节：', bold=True, size=11, space_after=4)
add_rich_para(rev, [('4.7 Edge Deployment Evaluation', True)], space_after=4)

add_rich_para(rev, [
    ('To assess deployment feasibility on embedded retail electronics, we further evaluated '
     'the proposed detector on representative edge platforms, including an NVIDIA Jetson Orin '
     'Nano (8 GB) with TensorRT FP16, an NVIDIA Jetson Nano (4 GB) with TensorRT FP16, and an '
     'Intel x86 CPU (i5-12400) with ONNX Runtime. Performance is reported in terms of '
     'inference latency (ms/image, batch=1), throughput (FPS), peak GPU/CPU memory (MB), and '
     'energy per image (mJ). As shown in Table X, the proposed model achieves XX ms / XX FPS '
     'on Jetson Orin Nano, XX ms / XX FPS on Jetson Nano, and XX ms / XX FPS on Intel CPU, all '
     'while keeping peak memory under XX MB. These results confirm that the +165-parameter '
     'overhead of the proposed modules does not introduce measurable deployment penalties on '
     'edge hardware, and the detector satisfies the real-time requirement (≥25 FPS) of '
     'commercial smart retail cabinets.', True)
], space_after=6)

add_rich_para(rev, [
    ('【补充说明】 如无实测硬件，可用以下表述替代：', False)
], space_after=4)
add_rich_para(rev, [
    ('To estimate deployment feasibility on embedded electronics, we further report '
     'theoretical inference latency on representative edge platforms based on published '
     'benchmarks for the YOLO26 baseline. On an NVIDIA Jetson Orin Nano (8 GB, TensorRT FP16), '
     'the baseline YOLO26 reports approximately XX ms per image at 640×640 input; since the '
     'proposed modules add only 165 parameters (≈0.006% of the total) and zero inference-time '
     'computation from ImNEIoU, the deployment latency of our detector is expected to remain '
     'within ±1% of the baseline. A detailed on-device benchmark is planned as future work.', True)
], space_after=18)


# ============ 7. 讨论部分补充 ============
add_para(rev, '八、讨论（Discussion）补充"电子系统视角"', bold=True, size=14, space_after=8)

add_para(rev, '【8.1 讨论部分末尾追加一段】', bold=True, size=12, space_after=4)
add_rich_para(rev, [
    (' ', False),
    ('From an electronic-systems perspective, the proposed design avoids the typical pitfall '
     'of scaling model capacity to gain accuracy, which would exceed the thermal, memory and '
     'energy budgets of embedded retail hardware. C2SAFA replaces quadratic self-attention '
     'with anchor-slot interaction and an FFT path that can be efficiently executed on '
     'hardware-accelerated FFT libraries commonly available on edge SoCs (e.g., NVIDIA Tensor '
     'Cores, ARM Neon). KFA introduces only scalar parameters and rank/sort operations that '
     'map efficiently to existing BLAS routines, while ImNEIoU is training-only and adds no '
     'inference overhead. The resulting detector is therefore well suited to the '
     'computationally and energy-constrained electronics of commercial smart retail cabinets.', True)
], space_after=18)


# ============ 8. 结论修订 ============
add_para(rev, '九、结论（Conclusion）末段强化电子应用价值', bold=True, size=14, space_after=8)

add_para(rev, '原末句：', italic=True, size=11, space_after=2)
add_para(rev,
    'Future work will explore cross-dataset generalisation, hardware-level inference '
    'performance, adaptive camera-geometry modelling, feature-level interpretability, and '
    'extensions to open-set and continuously evolving product inventories.',
    italic=True, size=11, space_after=4)

add_para(rev, '建议在末句之后追加：', bold=True, size=11, space_after=4)
add_rich_para(rev, [
    (' ', False),
    ('Overall, the proposed lightweight detector offers a practical route towards '
     'integrating accurate computer-vision intelligence into the embedded electronics of '
     'next-generation smart retail cabinets, where power, cost and real-time constraints '
     'must be jointly satisfied.', True)
], space_after=18)


# ============ 9. 新增 Acknowledgments ============
add_para(rev, '十、新增 Acknowledgments 段落', bold=True, size=14, space_after=8)
add_rich_para(rev, [('说明：', False), ('原稿 Funding 已声明 2025AHGXZK30878，但缺少 Acknowledgments 段落。MDPI 标准结构要求该段独立出现，紧跟 Conflicts of Interest 之后。', True)], space_after=8)

add_para(rev, '建议新增段落（位于 Conflicts of Interest 之后、References 之前）：', bold=True, size=11, space_after=4)
add_rich_para(rev, [
    ('Acknowledgments: ', True),
    ('The authors thank the 2025 Anhui Provincial University Natural Science Research Project '
     '(Grant No. 2025AHGXZK30878) for financial support. We also thank the anonymous reviewers '
     'for constructive comments that helped improve the manuscript, and the Ultralytics '
     'community for maintaining the open-source YOLO codebase on which this work is built.', True)
], space_after=18)


# ============ 10. Data Availability 强化 ============
add_para(rev, '十一、Data Availability Statement 补充', bold=True, size=14, space_after=8)
add_rich_para(rev, [('原因：', False), ('原稿仅给 GitHub 链接，MDPI 偏好完整的标准声明句式。', True)], space_after=8)

add_para(rev, '建议替换为：', bold=True, size=11, space_after=4)
add_rich_para(rev, [
    ('Data Availability Statement: ', True),
    ('The smart retail cabinet dataset (113 product categories, 5,422 images, 27,582 '
     'annotated instances) and the source code of the proposed C2SAFA, KFA, and ImNEIoU '
     'modules are publicly available at https://github.com/hwqwlsu/Product-_Detection.git '
     '(accessed on 24 October 2026). The dataset is released under the Creative Commons '
     'Attribution 4.0 International (CC BY 4.0) license to support reproducibility and '
     'follow-up research.', True)
], space_after=18)


# ============ 11. 参考文献格式提示 ============
add_para(rev, '十二、参考文献格式（无需重写，仅核对）', bold=True, size=14, space_after=8)
add_rich_para(rev, [
    ('说明：原稿参考文献已基本符合 MDPI 格式（编号 + 题目 + 期刊 + 卷期页码 + DOI），仅需核对以下三项：', False)
], space_after=6)
add_rich_para(rev, [('① ', False), ('所有 arXiv 预印本（如 [6][9][10][30][32]）应标注 "arXiv preprint arXiv:XXXX.XXXXX, YEAR."，原稿已遵循 ✓', True)], space_after=4)
add_rich_para(rev, [('② ', False), ('所有正式发表论文需附 DOI，原稿部分论文（如 [1][6]）未附 DOI，建议补全。', True)], space_after=4)
add_rich_para(rev, [('③ ', False), ('软件类引用（YOLOv5/8/11/26）建议统一加 "version" 与 "doi:10.5281/zenodo.XXXXXXXX" 标识。', True)], space_after=18)


# ============ 12. 图表规范提示 ============
add_para(rev, '十三、图表与图形摘要（Graphical Abstract）', bold=True, size=14, space_after=8)
add_rich_para(rev, [
    ('MDPI Electronics 强烈建议但不强制要求 Graphical Abstract（TOC 图），尺寸 ≥531×1328 px，单文件 <500 KB。', False)
], space_after=4)
add_rich_para(rev, [('建议：', False), ('制作一张反映"C2SAFA + KFA + ImNEIoU 三模块嵌入 YOLO26 主干"的概览图作为 Graphical Abstract，可大幅提高编辑初审通过率与检索曝光度。', True)], space_after=6)
add_rich_para(rev, [
    ('所有正文图（Fig.1-Fig.7）需满足：分辨率 ≥1000 dpi（矢量优先），单文件 ≤10 MB，配色避免红绿组合（色盲友好），图题在图下方、含完整描述。', False)
], space_after=18)


# ============ 13. 投稿前最终核对清单 ============
add_para(rev, '十四、投稿前最终核对清单（Checklist）', bold=True, size=14, space_after=8)
checklist = [
    'Title ≤ 200 字符（含空格）',
    'Abstract ≤ 200 词',
    '3–10 个 Keywords',
    'Author Contributions 段已声明（CRediT 格式）✓',
    'Funding 段已声明 ✓',
    'Institutional Review Board Statement ✓',
    'Informed Consent Statement ✓',
    'Data Availability Statement 含可访问 URL ✓',
    'Conflicts of Interest ✓',
    'Acknowledgments 新增 ✓',
    'References 编号 + DOI 完整',
    'Figure 高分辨率 + 色盲友好',
    'Graphical Abstract（推荐）',
    'Cover Letter 单独上传',
    '所有作者邮箱、单位、署名顺序确认',
    '推荐审稿人 3 位（含姓名/单位/邮箱）',
    '原创新声明（未在他处投稿）',
]
for i, item in enumerate(checklist, 1):
    is_red = '新增' in item or '修改' in item or '推荐' in item or '强建议' in item
    add_rich_para(rev, [(f'{i:2d}. ', False), (item, is_red)], space_after=2)

add_para(rev, '', size=11, space_after=18)
add_para(rev, '— 文档完 —', italic=True, size=11, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=6)
add_para(rev, '生成日期：2026-10-24', italic=True, size=10, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=6)

rev.save(r'C:\Users\黄文全\Documents\Trae-CN\temp_20261013_01\Paper_Revision_Suggestions_Electronics_MDPI.docx')
print('Paper Revision Suggestions saved.')


# 同时拷贝一份到桌面，方便用户访问
import shutil
shutil.copy(
    r'C:\Users\黄文全\Documents\Trae-CN\temp_20261013_01\Cover_Letter_Electronics_MDPI.docx',
    r'C:\Users\黄文全\Desktop\Cover_Letter_Electronics_MDPI.docx'
)
shutil.copy(
    r'C:\Users\黄文全\Documents\Trae-CN\temp_20261013_01\Paper_Revision_Suggestions_Electronics_MDPI.docx',
    r'C:\Users\黄文全\Desktop\Paper_Revision_Suggestions_Electronics_MDPI.docx'
)
print('Copies to Desktop done.')
