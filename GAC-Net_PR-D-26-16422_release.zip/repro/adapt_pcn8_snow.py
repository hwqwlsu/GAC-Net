# -*- coding: utf-8 -*-
"""PCN-8 版：把 export_pcn 产物适配成 SnowflakeNet 布局 + 生成类别文件。"""
import json, os, re, shutil

SRC = "/root/autodl-tmp/PCN8"
DST = "/root/autodl-tmp/PCN8_snow"
CAT_OUT = "/root/SnowflakeNet/completion/category_files/PCN8.json"

cats = {}
for split in ["train", "val", "test"]:
    for kind in ["partial", "complete"]:
        base = os.path.join(SRC, split, kind)
        if not os.path.isdir(base):
            continue
        for syn in sorted(os.listdir(base)):
            synpath = os.path.join(base, syn)
            if not os.path.isdir(synpath):
                continue
            for f in sorted(os.listdir(synpath)):
                if not f.endswith(".pcd"):
                    continue
                stem = f[:-4]
                m = re.match(r"(.+)__v(\d+)$", stem)
                model, view = (m.group(1), int(m.group(2))) if m else (stem, 0)
                if kind == "partial":
                    d = os.path.join(DST, split, kind, syn, model)
                    os.makedirs(d, exist_ok=True)
                    dst = os.path.join(d, f"{view:02d}.pcd")
                else:
                    d = os.path.join(DST, split, kind, syn)
                    os.makedirs(d, exist_ok=True)
                    dst = os.path.join(d, model + ".pcd")
                if not os.path.exists(dst):
                    shutil.copy2(os.path.join(synpath, f), dst)
                e = cats.setdefault(syn, {"train": set(), "val": set(), "test": set()})
                e[split].add(model)

syn2name = {
    "02691156": "airplane", "02933112": "cabinet", "02958343": "car",
    "03001627": "chair", "03636649": "lamp", "04256520": "sofa",
    "04379243": "table", "04530566": "watercraft",
}
cat_json = []
for syn, e in sorted(cats.items()):
    cat_json.append({
        "taxonomy_id": syn,
        "taxonomy_name": syn2name.get(syn, syn),
        "train": sorted(e["train"]), "val": sorted(e["val"]),
        "test": sorted(e["test"]),
    })
with open(CAT_OUT, "w") as f:
    json.dump(cat_json, f, indent=2)

for split in ["train", "val", "test"]:
    n = 0
    pdir = os.path.join(DST, split, "partial")
    if os.path.isdir(pdir):
        for syn in os.listdir(pdir):
            for model in os.listdir(os.path.join(pdir, syn)):
                n += len(os.listdir(os.path.join(pdir, syn, model)))
    print(split, "partial files:", n)
print("cat json ->", CAT_OUT, "categories:", len(cat_json))
print("ADAPT_PCN8_DONE")
