# -*- coding: utf-8 -*-
"""把 export_pcn 产物适配成 SnowflakeNet 期望的布局 + 生成类别文件。
SnowflakeNet: <root>/<split>/partial/<syn>/<model>/<view:02d>.pcd
              <root>/<split>/complete/<syn>/<model>.pcd
train/val 只有 v0 -> 复制成 00；test 有 v0..v7 -> 00..07。"""
import json
import os
import re
import shutil

SRC = "/root/autodl-tmp/PCN"
DST = "/root/autodl-tmp/PCN_snow"
CAT_OUT = "/root/SnowflakeNet/completion/category_files/Pix3D.json"

cats = {}
for split in ["train", "val", "test"]:
    for kind in ["partial", "complete"]:
        base = os.path.join(SRC, split, kind)
        if not os.path.isdir(base):
            continue
        for syn in sorted(os.listdir(base)):
            for f in sorted(os.listdir(os.path.join(base, syn))):
                if not f.endswith(".pcd"):
                    continue
                stem = f[:-4]
                m = re.match(r"(.+)__v(\d+)$", stem)
                model, view = (m.group(1), int(m.group(2))) if m else (stem, 0)
                if kind == "partial":
                    d = os.path.join(DST, split, kind, syn, model)
                    os.makedirs(d, exist_ok=True)
                    dst = os.path.join(d, f"{view:02d}.pcd")
                else:
                    d = os.path.join(DST, split, kind, syn)
                    os.makedirs(d, exist_ok=True)
                    dst = os.path.join(d, model + ".pcd")
                if not os.path.exists(dst):
                    shutil.copy2(os.path.join(base, syn, f), dst)
                e = cats.setdefault(syn, {"train": set(), "val": set(), "test": set()})
                e[split].add(model)

cat_json = []
syn2name = {"03001627": "chair", "04379243": "table", "04256520": "sofa"}
for syn, e in sorted(cats.items()):
    cat_json.append({
        "taxonomy_id": syn,
        "taxonomy_name": syn2name.get(syn, syn),
        "train": sorted(e["train"]), "val": sorted(e["val"]),
        "test": sorted(e["test"]),
    })
with open(CAT_OUT, "w") as f:
    json.dump(cat_json, f, indent=2)

for split in ["train", "val", "test"]:
    n = 0
    pdir = os.path.join(DST, split, "partial")
    for syn in os.listdir(pdir):
        for model in os.listdir(os.path.join(pdir, syn)):
            n += len(os.listdir(os.path.join(pdir, syn, model)))
    print(split, "partial files:", n)
print("cat json ->", CAT_OUT)
print("ADAPT_DONE")
