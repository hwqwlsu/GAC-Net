wc -l /root/image_guided_pc_completion/data/shapenet8/splits/*.txt
echo "=== per-category train ==="
for s in 02691156 02933112 02958343 03001627 03636649 04256520 04379243 04530566; do
  n=$(grep -c $s /root/image_guided_pc_completion/data/shapenet8/splits/train.txt)
  echo "$s train: $n"
done
echo "=== disk ==="
df -h /root/autodl-tmp | tail -1
