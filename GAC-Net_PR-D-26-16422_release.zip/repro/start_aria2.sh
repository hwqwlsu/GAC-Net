#!/bin/bash
cd /root/autodl-tmp
TRACKERS=$(tr '\n' ',' < /root/trackers.txt | sed 's/,,*/,/g')
setsid aria2c /root/shapenetcore.torrent \
  --select-file=5 \
  --enable-dht=true --dht-listen-port=6881 --listen-port=6882 \
  --bt-tracker="$TRACKERS" \
  --bt-tracker-connect-timeout=10 --bt-tracker-timeout=10 \
  --max-connection-per-server=8 --split=8 --seed-time=0 \
  --summary-interval=30 --file-allocation=none \
  > /root/aria2_sn.log 2>&1 < /dev/null &
sleep 5
pgrep -f "aria2c /root/shapenetcore" | wc -l
