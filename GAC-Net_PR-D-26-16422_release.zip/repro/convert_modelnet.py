# -*- coding: utf-8 -*-
"""服务器端：ModelNet40 OFF -> ShapeNet v2 风格 OBJ 布局（chair/table/sofa）。"""
import os
import zipfile
import trimesh

ZIP = "/root/autodl-tmp/ModelNet40.zip"
OUT = "/root/autodl-tmp/mn_meshes"
CATS = {"chair": "03001627", "table": "04379243", "sofa": "04256520"}

zf = zipfile.ZipFile(ZIP)
names = [n for n in zf.namelist()
         if n.endswith(".off") and n.split("/")[1] in CATS]
print("off files:", len(names))

n_ok = n_fail = 0
for n in names:
    _, cat, split, fname = n.split("/")
    mid = fname.replace(".off", "") + "_" + split
    dst_dir = os.path.join(OUT, CATS[cat], mid, "models")
    dst = os.path.join(dst_dir, "model_normalized.obj")
    if os.path.exists(dst):
        n_ok += 1
        continue
    try:
        m = trimesh.load(zf.open(n), file_type="off",
                         force="mesh", process=False)
        if len(m.faces) == 0:
            raise ValueError("no faces")
        os.makedirs(dst_dir, exist_ok=True)
        m.export(dst)
        n_ok += 1
    except Exception as e:
        n_fail += 1
        if n_fail <= 5:
            print("FAIL", n, repr(e)[:100])
print(f"converted ok={n_ok} fail={n_fail}")
for cat, syn in CATS.items():
    p = os.path.join(OUT, syn)
    print(syn, cat, len(os.listdir(p)) if os.path.isdir(p) else 0)
print("CONVERT_DONE")
