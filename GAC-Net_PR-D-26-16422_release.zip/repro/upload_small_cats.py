# -*- coding: utf-8 -*-
"""并行上传单个小类别，快速解锁 ShapeNet 渲染验证。"""
import os, paramiko
HOST, PORT, USER, PWD = "connect.westb.seetacloud.com", 23326, "root", "yuk4EGNx2TKK"
SRC = r"G:\Shapenetcore数据集"
DST = "/root/autodl-tmp/ShapeNetCore_zips"
TARGETS = ["03636649.zip", "03001627.zip"]  # lamp (small), chair
c = paramiko.Transport((HOST, PORT)); c.connect(username=USER, password=PWD)
sftp = paramiko.SFTPClient.from_transport(c)
try: sftp.mkdir(DST)
except IOError: pass
for f in TARGETS:
    lpath = os.path.join(SRC, f); rpath = os.path.join(DST, f)
    lsize = os.path.getsize(lpath)
    try: rsize = sftp.stat(rpath).st_size
    except IOError: rsize = -1
    if rsize == lsize:
        print("skip", f); continue
    print("upload", f, f"{lsize/1e6:.0f}MB", flush=True)
    sftp.put(lpath, rpath)
    print("OK", f, flush=True)
print("PARALLEL_DONE")
