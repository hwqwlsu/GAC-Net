cd /root/image_guided_pc_completion
rm -rf experiments/gacnet_pcn8
setsid /root/miniconda3/bin/python train.py --config configs/pcn8_full.json > /root/train_gacnet_pcn8.log 2>&1 < /dev/null &
echo "TRAIN_50EP_STARTED"
setsid bash /root/wait_and_chain.sh > /root/chain.log 2>&1 < /dev/null &
echo "WATCHER_STARTED"
