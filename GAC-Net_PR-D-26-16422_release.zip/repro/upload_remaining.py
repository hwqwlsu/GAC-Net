import os, sys, time, paramiko

HOST="connect.westb.seetacloud.com"; PORT=23326; USER="root"; PWD="yuk4EGNx2TKK"
SRC=r"G:\Shapenetcore数据集"
CATS = ["04256520", "04379243", "04530566"]  # sofa, table, watercraft

def main():
    t = paramiko.Transport((HOST, PORT)); t.connect(username=USER, password=PWD)
    sftp = paramiko.SFTPClient.from_transport(t)
    ssh = paramiko.SSHClient(); ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(HOST, port=PORT, username=USER, password=PWD)
    ssh.exec_command("mkdir -p /root/autodl-tmp/ShapeNetCore_zips")
    total = 0
    for i, syn in enumerate(CATS, 1):
        src = os.path.join(SRC, syn + ".zip")
        if not os.path.exists(src):
            print(f"[skip] {syn}.zip not found"); continue
        sz = os.path.getsize(src)
        t0 = time.time()
        print(f"[{i}/{len(CATS)}] upload {syn}.zip ({sz/1e6:.0f} MB) ...", flush=True)
        sftp.put(src, f"/root/autodl-tmp/ShapeNetCore_zips/{syn}.zip")
        dt = time.time() - t0; total += sz
        print(f"    OK  total {total/1e9:.2f} GB  {sz/1e6/dt:.1f} MB/s", flush=True)
    sftp.close(); ssh.close()
    print("UPLOAD_REMAINING_DONE")

if __name__ == "__main__":
    main()
