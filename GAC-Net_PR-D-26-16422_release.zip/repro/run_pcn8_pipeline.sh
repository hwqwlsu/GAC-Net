#!/bin/bash
# PCN-8 全流程：导出 PCN 布局 -> 适配 SnowflakeNet -> 启动 GAC-Net 训练
set -e
cd /root/image_guided_pc_completion

echo "=== [1/3] export PCN layout from data/shapenet8 ==="
/root/miniconda3/bin/python tools/baselines/export_pcn.py \
    --root data/shapenet8 --out /root/autodl-tmp/PCN8 2>&1 | tail -5

echo "=== [2/3] adapt PCN -> SnowflakeNet layout ==="
/root/miniconda3/envs/snowflake/bin/python /root/adapt_pcn8_snow.py 2>&1 | tail -5

echo "=== [3/3] start GAC-Net training (300 epochs, background) ==="
setsid /root/miniconda3/bin/python train.py --config configs/pcn8_full.json \
    > /root/train_gacnet_pcn8.log 2>&1 < /dev/null &
echo "GAC-Net training started, PID $!"
echo "PIPELINE_DONE"
