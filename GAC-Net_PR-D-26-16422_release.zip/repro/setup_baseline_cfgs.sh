#!/usr/bin/env bash
# 预置两个基线仓库的配置文件（与 run_*.sh 运行时 heredoc 完全一致，用于 CPU 冒烟测试；
# 运行时 run 脚本会重写相同内容，幂等）
set -e
DS_CFG='NAME: PCN
CATEGORY_FILE_PATH: data/PCN/PCN.json
N_POINTS: 16384
N_RENDERINGS: 8
PARTIAL_POINTS_PATH: data/PCN/%s/partial/%s/%s/%02d.pcd
COMPLETE_POINTS_PATH: data/PCN/%s/complete/%s/%s.pcd
CARS: FALSE'

for REPO in /root/PoinTr /root/AnchorFormer; do
  mkdir -p "$REPO/data" "$REPO/cfgs/dataset_configs" "$REPO/cfgs/PCN_models"
  ln -sfn /root/autodl-tmp/PCN8_snow "$REPO/data/PCN"
  echo "$DS_CFG" > "$REPO/cfgs/dataset_configs/PCN_pcn8.yaml"
done

cat > /root/PoinTr/cfgs/PCN_models/PoinTr_pcn8.yaml <<'EOF'
optimizer : {
  type: AdamW,
  kwargs: {
  lr : 0.0005,
  weight_decay : 0.0005
}}
scheduler: {
  type: LambdaLR,
  kwargs: {
  decay_step: 21,
  lr_decay: 0.9,
  lowest_decay: 0.02
}}
bnmscheduler: {
  type: Lambda,
  kwargs: {
  decay_step: 21,
  bn_decay: 0.5,
  bn_momentum: 0.9,
  lowest_decay: 0.01
}}
dataset : {
  train : { _base_: cfgs/dataset_configs/PCN_pcn8.yaml,
            others: {subset: 'train'}},
  val : { _base_: cfgs/dataset_configs/PCN_pcn8.yaml,
            others: {subset: 'val'}},
  test : { _base_: cfgs/dataset_configs/PCN_pcn8.yaml,
            others: {subset: 'test'}}}
model : {
  NAME: PoinTr, num_pred: 14336, num_query: 224, knn_layer: 1, trans_dim: 384}

total_bs : 48
step_per_update : 1
max_epoch : 50
consider_metric: CDL1
EOF

cat > /root/AnchorFormer/cfgs/PCN_models/AnchorFormer_pcn8.yaml <<'EOF'
optimizer : {
  type: AdamW,
  kwargs: {
  lr : 0.0002,
  weight_decay : 0.0005
}}
scheduler: {
  type: WarmUpCosLR,
  kwargs: {
  warmup_epoch: 5,
  max_epoch: 50,
  lr_max: 0.0002,
  lr_min: 0.00001
}}
dataset : {
  train : { _base_: cfgs/dataset_configs/PCN_pcn8.yaml,
            others: {subset: 'train'}},
  val : { _base_: cfgs/dataset_configs/PCN_pcn8.yaml,
            others: {subset: 'val'}},
  test : { _base_: cfgs/dataset_configs/PCN_pcn8.yaml,
            others: {subset: 'test'}}}
model : {
  NAME: AnchorFormer, num_pred: 16384, num_query: 256, knn_layer: 0,
  trans_dim: 384, num_encoder_blk: 8, num_decoder_blk: 6,
  sparse_expansion_lambda: 0.5, dense_expansion_lambda: 1.2}
loss : {
  sparse_loss_weight: 1.0,
  dense_loss_weight: 1.0,
  sparse_penalty_weight: 0.1,
  dense_penalty_weight: 0.05
}
total_bs : 32
step_per_update : 1
max_epoch : 50
consider_metric: CDL1
EOF

echo "CFG_READY"
