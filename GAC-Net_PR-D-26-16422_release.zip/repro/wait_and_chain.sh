#!/bin/bash
# 等待 GAC-Net 训练完成，然后自动运行后续全流程
# 用法：setsid bash /root/wait_and_chain.sh > /root/chain.log 2>&1 < /dev/null &
set -e
cd /root/image_guided_pc_completion

echo "=== waiting for GAC-Net training to finish ==="
while true; do
  # 检查训练进程是否还在
  if ! pgrep -f "train.py --config configs/pcn8_full" > /dev/null; then
    echo "GAC-Net process finished at $(date)"
    break
  fi
  # 检查是否达到 100 epoch
  if [ -f experiments/gacnet_pcn8/train_log.csv ]; then
    n=$(tail -1 experiments/gacnet_pcn8/train_log.csv | cut -d, -f1)
    if [ "$n" = "50" ]; then
      echo "GAC-Net reached epoch 50 at $(date)"
      break
    fi
  fi
  sleep 120
done

echo "=== launching post-training pipeline ==="
bash /root/run_after_gacnet.sh
echo "CHAIN_DONE"
