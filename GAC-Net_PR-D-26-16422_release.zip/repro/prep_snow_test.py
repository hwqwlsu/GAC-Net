# -*- coding: utf-8 -*-
"""SnowflakeNet test 加载用平铺路径 partial/<syn>/<model>.pcd（由 00.pcd 复制）。
顺便打印一个 pcd 文件头确认格式。"""
import os, shutil

DST = "/root/autodl-tmp/PCN_snow"
n = 0
for syn in sorted(os.listdir(os.path.join(DST, "test", "partial"))):
    pdir = os.path.join(DST, "test", "partial", syn)
    for model in sorted(os.listdir(pdir)):
        src = os.path.join(pdir, model, "00.pcd")
        dst = os.path.join(pdir, model + ".pcd")
        if os.path.exists(src) and not os.path.exists(dst):
            shutil.copy2(src, dst)
            n += 1
print("flat test partials created:", n)

sample = None
p0 = os.path.join(DST, "test", "partial")
for syn in sorted(os.listdir(p0)):
    for f in sorted(os.listdir(os.path.join(p0, syn))):
        if f.endswith(".pcd"):
            sample = os.path.join(p0, syn, f)
            break
    if sample:
        break
with open(sample, "rb") as f:
    head = f.read(300)
print("sample:", sample)
print(head[:300])
print("PREP_DONE")
