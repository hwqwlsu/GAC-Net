"""给 SnowflakeNet 的 PCNDataLoader 打补丁：test 划分的 partial 路径改为
带视角索引的模板并固定 index=0（对应本工程的 v0 渲染），与 train/val 路径结构一致。"""
import os, shutil, sys

PATH = "/root/SnowflakeNet/completion/core/datasets/pcn.py"

OLD = """                    gt_path = cfg.dataset.complete_points_path % (subset, dc['taxonomy_id'], s)
                    file_list.append({'taxonomy_id': dc['taxonomy_id'],
                    'model_id': s,
                    'partial_cloud_path': gt_path.replace('complete', 'partial'),
                    'gtcloud_path': gt_path})"""

NEW = """                    gt_path = cfg.dataset.complete_points_path % (subset, dc['taxonomy_id'], s)
                    file_list.append({'taxonomy_id': dc['taxonomy_id'],
                    'model_id': s,
                    'partial_cloud_path': cfg.dataset.partial_points_path % (subset, dc['taxonomy_id'], s, 0),
                    'gtcloud_path': gt_path})"""

src = open(PATH, encoding="utf-8").read()

if NEW in src:
    print("已打过补丁，无需重复")
    sys.exit(0)

if OLD not in src:
    print("未找到目标代码段，中止")
    sys.exit(1)

shutil.copy(PATH, PATH + ".bak")
open(PATH, "w", encoding="utf-8").write(src.replace(OLD, NEW, 1))
print("补丁已应用；备份 ->", PATH + ".bak")
print("--- 修改后片段 ---")
txt = open(PATH, encoding="utf-8").read().splitlines()
for i, line in enumerate(txt, 1):
    if 85 <= i <= 95:
        print("%4d| %s" % (i, line))
