"""view-consistency loss 是否有害？—— 从已收敛的 full checkpoint 出发做受控微调对照。

两臂除 loss.w_view 外完全一致（同 checkpoint、同 seed、同数据顺序、同固定学习率、
同 epoch 数），各自逐 epoch 记录验证集 CD-L1/L2 与各损失分量。

判据：
  - 若 w_view=0 臂的 val CD-L1 明显下降（如 105 -> 85 量级），而 w_view=0.05 臂基本不动，
    则 view loss 确实在阻碍 CD 目标收敛；
  - 若两臂都基本不动，则 view loss 不是主因，问题在图像分支或训练预算。
"""
import argparse, json, os, sys, time

import torch
from torch.utils.data import DataLoader

sys.path.insert(0, "/root/image_guided_pc_completion")
os.chdir("/root/image_guided_pc_completion")

from pcic.data import build_dataset
from pcic.models import GACNet
from pcic.losses import completion_loss
from pcic.metrics import chamfer_metrics
from pcic.utils import seed_everything, load_config


def move(batch, device):
    return {k: (v.to(device) if torch.is_tensor(v) else v) for k, v in batch.items()}


@torch.no_grad()
def validate(model, loader, device):
    model.eval()
    cd1 = cd2 = 0.0
    n = 0
    for batch in loader:
        batch = move(batch, device)
        out = model(batch)
        a, b = chamfer_metrics(out["fine"], batch["complete"])
        bs = batch["complete"].shape[0]
        cd1 += a * bs
        cd2 += b * bs
        n += bs
    return cd1 / n, cd2 / n


def run_arm(cfg, ckpt, train_loader, val_loader, device, tag, w_view, epochs, lr):
    seed_everything(cfg["seed"])
    model = GACNet(**cfg["model"]).to(device)
    model.load_state_dict(torch.load(ckpt, map_location=device)["model"])

    loss_cfg = dict(cfg["loss"])
    loss_cfg["w_view"] = w_view
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.0)

    print("\n########## ARM %s (w_view=%s, lr=%g, %d epochs) ##########" % (tag, w_view, lr, epochs))
    c1, c2 = validate(model, val_loader, device)
    print("  [ep0 baseline] CD-L1=%.2f CD-L2=%.3f" % (c1 * 1e4, c2 * 1e4))
    hist = [{"epoch": 0, "cd_l1": c1 * 1e4, "cd_l2": c2 * 1e4}]

    for ep in range(1, epochs + 1):
        model.train()
        t0 = time.time()
        acc = {"loss_coarse": 0.0, "loss_fine": 0.0, "loss_view": 0.0, "loss_total": 0.0}
        steps = 0
        for batch in train_loader:
            batch = move(batch, device)
            opt.zero_grad(set_to_none=True)
            out = model(batch)
            loss, logs = completion_loss(out, batch, loss_cfg)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), cfg["grad_clip"])
            opt.step()
            for k in acc:
                if k in logs:
                    acc[k] += float(logs[k])
            steps += 1
        for k in acc:
            acc[k] /= max(steps, 1)
        c1, c2 = validate(model, val_loader, device)
        dt = time.time() - t0
        print("  [ep%d] L_coarse=%.5f L_fine=%.5f L_view=%.5f total=%.5f | "
              "CD-L1=%.2f CD-L2=%.3f | %.0fs" % (
                  ep, acc["loss_coarse"], acc["loss_fine"], acc["loss_view"],
                  acc["loss_total"], c1 * 1e4, c2 * 1e4, dt))
        hist.append({"epoch": ep, "cd_l1": c1 * 1e4, "cd_l2": c2 * 1e4, "loss": acc})
        sys.stdout.flush()
    return hist


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/pcn8_full.json")
    ap.add_argument("--ckpt", default="experiments/gacnet_pcn8/best_model.pth")
    ap.add_argument("--epochs", type=int, default=3)
    ap.add_argument("--lr", type=float, default=1e-4)
    ap.add_argument("--out", default="paper_assets/view_loss_probe.json")
    args = ap.parse_args()

    cfg = load_config(args.config)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    val_split = "test" if cfg["dataset"] == "synthetic" else "val"
    print("[cfg] dataset=%s val_split=%s n_partial=%s epochs=%s loss=%s"
          % (cfg["dataset"], val_split, cfg["n_partial"], cfg["epochs"], cfg["loss"]))

    train_set = build_dataset(cfg, "train")
    val_set = build_dataset(cfg, val_split)
    print("[data] train=%d val=%d" % (len(train_set), len(val_set)))
    train_loader = DataLoader(train_set, batch_size=cfg["batch_size"], shuffle=True,
                              num_workers=cfg["num_workers"], drop_last=True, pin_memory=True)
    val_loader = DataLoader(val_set, batch_size=cfg["batch_size"], shuffle=False,
                            num_workers=cfg["num_workers"], pin_memory=True)

    result = {}
    for tag, wv in [("keep_view_0.05", 0.05), ("drop_view_0.0", 0.0)]:
        result[tag] = run_arm(cfg, args.ckpt, train_loader, val_loader, device,
                              tag, wv, args.epochs, args.lr)

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    json.dump(result, open(args.out, "w"), indent=2)
    print("\n[probe saved]", args.out)

    print("\n================ 汇总（val CD-L1 x1e4） ================")
    print("%-18s %s" % ("arm", "  ".join("ep%d" % e for e in range(args.epochs + 1))))
    for tag, hist in result.items():
        print("%-18s %s" % (tag, "  ".join("%6.2f" % h["cd_l1"] for h in hist)))


if __name__ == "__main__":
    main()
