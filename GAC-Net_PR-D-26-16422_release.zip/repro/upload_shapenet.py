# -*- coding: utf-8 -*-
"""断点续传上传 ShapeNetCore 按 synset 拆分的 zip 到 AutoDL /root/autodl-tmp/ShapeNetCore_zips/。
已存在且大小一致的跳过；不一致则覆盖重传。"""
import os, sys, time
import paramiko

HOST, PORT, USER, PWD = "connect.westb.seetacloud.com", 23326, "root", "yuk4EGNx2TKK"
SRC = r"G:\Shapenetcore数据集"
DST = "/root/autodl-tmp/ShapeNetCore_zips"
# PCN-8 优先，其余按序
PCN8 = ["02691156","02933112","02958343","03001627","03636649","04256520","04379243","04530566"]

def main():
    files = sorted(os.listdir(SRC))
    files = [f for f in files if f.endswith(".zip")]
    ordered = [f for f in files if f[:-4] in PCN8] + [f for f in files if f[:-4] not in PCN8]
    c = paramiko.Transport((HOST, PORT))
    c.connect(username=USER, password=PWD)
    sftp = paramiko.SFTPClient.from_transport(c)
    try:
        sftp.mkdir(DST)
    except IOError:
        pass
    total = sum(os.path.getsize(os.path.join(SRC, f)) for f in ordered)
    done = 0
    t0 = time.time()
    for i, f in enumerate(ordered):
        lpath = os.path.join(SRC, f)
        rpath = os.path.join(DST, f)
        lsize = os.path.getsize(lpath)
        try:
            rsize = sftp.stat(rpath).st_size
        except IOError:
            rsize = -1
        if rsize == lsize:
            print(f"[{i+1}/{len(ordered)}] skip {f} ({lsize/1e6:.0f} MB)")
            done += lsize
            continue
        print(f"[{i+1}/{len(ordered)}] upload {f} ({lsize/1e6:.0f} MB) ...", flush=True)
        sftp.put(lpath, rpath)
        rsize = sftp.stat(rpath).st_size
        assert rsize == lsize, f"size mismatch {f}: {rsize}!={lsize}"
        done += lsize
        el = time.time() - t0
        rate = done / 1e6 / max(el, 1)
        eta = (total - done) / 1e6 / max(rate, 0.01)
        print(f"    OK  total {done/1e9:.2f}/{total/1e9:.2f} GB  {rate:.1f} MB/s  eta {eta/60:.0f} min")
    print("ALL_DONE")

if __name__ == "__main__":
    main()
