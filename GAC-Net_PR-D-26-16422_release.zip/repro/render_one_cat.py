# -*- coding: utf-8 -*-
"""解压单个 ShapeNet synset zip 并渲染。
用法: python render_one_cat.py <syn> [--limit N]
- 解压 /root/autodl-tmp/ShapeNetCore_zips/<syn>.zip -> /root/autodl-tmp/ShapeNetCore/<syn>/
- 调用 tools/render_shapenet.py 渲染到 data/shapenet8
- 渲染后删除 zip 与解压网格，仅保留渲染产物，节省磁盘"""
import os, sys, subprocess, shutil, zipfile

SYN = sys.argv[1]
LIMIT = int(sys.argv[3]) if len(sys.argv) > 3 and sys.argv[2] == "--limit" else 0
ZIP = f"/root/autodl-tmp/ShapeNetCore_zips/{SYN}.zip"
EXTRACT = "/root/autodl-tmp/ShapeNetCore"
OUT = "/root/image_guided_pc_completion/data/shapenet8"

print(f"=== extract {SYN} ===", flush=True)
with zipfile.ZipFile(ZIP) as z:
    z.extractall(EXTRACT)
# ShapeNet zip 结构可能是 <syn>/<model>/models/model_normalized.obj 或带前缀
syn_dir = os.path.join(EXTRACT, SYN)
if not os.path.isdir(syn_dir):
    for d in os.listdir(EXTRACT):
        full = os.path.join(EXTRACT, d)
        if os.path.isdir(full) and (os.path.isdir(os.path.join(full, SYN)) or d == SYN):
            syn_dir = os.path.join(full, SYN) if d != SYN else full
            break
print("syn_dir:", syn_dir, "exists:", os.path.isdir(syn_dir), flush=True)
nm = len(os.listdir(syn_dir)) if os.path.isdir(syn_dir) else 0
print("models found:", nm, flush=True)

cmd = ["/root/miniconda3/bin/python", "tools/render_shapenet.py",
       "--models_dir", EXTRACT, "--out", OUT,
       "--categories", SYN,
       "--views_train", "1", "--views_val", "1", "--views_test", "8"]
if LIMIT: cmd += ["--limit", str(LIMIT)]
print("render cmd:", " ".join(cmd), flush=True)
env = os.environ.copy()
env["PYOPENGL_PLATFORM"] = "egl"
r = subprocess.run(cmd, cwd="/root/image_guided_pc_completion", env=env,
                   capture_output=True, text=True)
print("render rc:", r.returncode, flush=True)
print(r.stdout[-2000:], flush=True)
if r.returncode != 0:
    print("STDERR:", r.stderr[-2000:], flush=True)
    sys.exit(1)

# 清理：删除解压网格与 zip
shutil.rmtree(os.path.join(EXTRACT, SYN), ignore_errors=True)
try: os.remove(ZIP)
except OSError: pass
print(f"=== DONE render {SYN}; cleaned mesh+zip ===", flush=True)
