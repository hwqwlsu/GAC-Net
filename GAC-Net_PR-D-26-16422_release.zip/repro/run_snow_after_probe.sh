#!/bin/bash
# 探针结束后自动接续：SnowflakeNet 基线（50ep，用 val 选模型）-> 预测 v0 -> 收集 -> 统一评估
cd /root/image_guided_pc_completion
PY=/root/miniconda3/bin/python
SNOW=/root/miniconda3/envs/snowflake/bin/python
LOG=/root/snow_chain.log

echo "=== [0/5] 等待 view-loss 探针结束 ===" | tee -a $LOG
while [ ! -f /root/probe_view.log ] || ! grep -q "probe saved" /root/probe_view.log; do
  sleep 60
done
echo "probe finished at $(date)" | tee -a $LOG
tail -12 /root/probe_view.log | tee -a $LOG

echo "=== [1/5] 生成 v0-only 划分文件 ===" | tee -a $LOG
grep "__v0.npy" data/shapenet8/splits/test.txt > data/shapenet8/splits/test_v0.txt
wc -l data/shapenet8/splits/test_v0.txt | tee -a $LOG

echo "=== [2/5] SnowflakeNet 训练 50ep（val 选模型，避免用测试集选模型） ===" | tee -a $LOG
cd /root/SnowflakeNet/completion
sed 's/^  split: test/  split: val/' configs/pcn8.yaml > configs/pcn8_val.yaml
grep -A1 "^test:" configs/pcn8_val.yaml | tee -a $LOG
$SNOW train.py --config configs/pcn8_val.yaml > /root/snow_train.log 2>&1
echo "snow train exit=$?" | tee -a $LOG
tail -6 /root/snow_train.log | tee -a $LOG

CKPT=$(find /root/autodl-tmp/snow_exp/pcn8 -name 'ckpt-best.pth' 2>/dev/null | head -1)
echo "ckpt=$CKPT" | tee -a $LOG
if [ -z "$CKPT" ]; then echo "SNOW_CHAIN_FAILED: no ckpt" | tee -a $LOG; exit 1; fi

echo "=== [3/5] 预测 test 视角0 ===" | tee -a $LOG
$SNOW predict_dump_snow.py --config configs/pcn8_val.yaml --ckpt "$CKPT" \
  --src_root /root/autodl-tmp/PCN8_snow/test/partial --views 0 \
  --out /root/autodl-tmp/snow_pred_pcn8 > /root/snow_predict.log 2>&1
echo "predict exit=$?" | tee -a $LOG
tail -3 /root/snow_predict.log | tee -a $LOG

echo "=== [4/5] 收集预测 ===" | tee -a $LOG
cd /root/image_guided_pc_completion
$PY tools/baselines/collect_predictions.py --src /root/autodl-tmp/snow_pred_pcn8 \
  --method snowflakenet_pcn8 --split_file data/shapenet8/splits/test_v0.txt --ext pcd \
  2>&1 | tail -5 | tee -a $LOG

echo "=== [5/5] 统一评估 ===" | tee -a $LOG
$PY tools/eval_predictions.py --pred_root predictions --data_root data/shapenet8 \
  --split test --methods snowflakenet_pcn8 2>&1 | tail -10 | tee -a $LOG

rm -rf /root/autodl-tmp/snow_pred_pcn8
echo "SNOW_CHAIN_DONE $(date)" | tee -a $LOG
